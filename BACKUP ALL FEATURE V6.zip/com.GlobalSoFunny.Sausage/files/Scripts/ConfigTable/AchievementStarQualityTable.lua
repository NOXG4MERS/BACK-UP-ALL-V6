local AchievementStarQualityTable = class({}, Assets.req("Scripts.ConfigTable.Base.AchievementStarQualityTableBase"))
-- 通过 Id 得到内容
function AchievementStarQualityTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function AchievementStarQualityTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function AchievementStarQualityTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function AchievementStarQualityTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function AchievementStarQualityTable:getQuality(argNum)
    local id = self:GetIdByFieldIndex(self.star, argNum)
    if id then
        return self:GetSingleValue(id, self.quality_id) - 1
    end
    return 0
end

return AchievementStarQualityTable
