local AchievementStarTable = class({}, Assets.req("Scripts.ConfigTable.Base.AchievementStarTableBase"))
-- 通过 Id 得到内容
function AchievementStarTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function AchievementStarTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function AchievementStarTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function AchievementStarTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function AchievementStarTable:getAchievementStarItem(achievementStarID)
    return {
        AchievementStarID = self:GetSingleValue(achievementStarID, self.id),
        AchievementID = self:GetSingleValue(achievementStarID, self.achievement_id),
        Star = self:GetSingleValue(achievementStarID, self.star),
        Score = self:GetSingleValue(achievementStarID, self.score),
        Value = self:GetSingleValue(achievementStarID, self.value)
    }
end

function AchievementStarTable:getAchievementStarList(achievementId)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.achievement_id, achievementId)
    if ids then
        for i = 1, #ids do
            list[#list + 1] = self:getAchievementStarItem(ids[i])
        end
    end
    return list
end

function AchievementStarTable:getStar(achievementId, value)
    for k, v in pairs(self.List0) do
        if v[self.achievement_id] == achievementId and value <= v[self.value] then
            return v[self.star]
        end
    end
    return 0
end

function AchievementStarTable:getValue(achievementId, star)
    for k, v in pairs(self.List0) do
        if v[self.achievement_id] == achievementId and star == v[self.star] then
            return v[self.value]
        end
    end
    return 0
end

function AchievementStarTable:getAchievementIdByStarId(achievementStarID)
    return self:GetSingleValue(achievementStarID, self.achievement_id)
end

function AchievementStarTable:getMinStar(achievementID)
    local tempStar = 9999
    for k, v in pairs(self.List0) do
        if v[self.achievement_id] == achievementID and v[self.star] < tempStar then
            tempStar = v[self.star]
        end
    end
    if tempStar == 9999 then
        tempStar = 1
    end
    return tempStar
end

return AchievementStarTable
