local AchievementTable = class({}, Assets.req("Scripts.ConfigTable.Base.AchievementTableBase"))
-- 通过 Id 得到内容
function AchievementTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function AchievementTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function AchievementTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function AchievementTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function AchievementTable:getItemData(id)
    local data = self:GetValueById(id)
    return {
        ID = data[self.id],
        Name = data[self.name],
        Sign = data[self.sign],
        DescRiption = data[self.description],
        FinishType = data[self.finish_type],
        Sort = data[self.sort],
        GameMod = data[self.game_mod],
        GroupMod = data[self.group_mod],
        Arg1 = data[self.arg1],
        Arg2 = data[self.arg2],
        Arg3 = data[self.arg3],
        Desc1 = data[self.desc1],
        Desc2 = data[self.desc2],
        Desc3 = data[self.desc3],
        Content = data[self.content],
        IsUse = data[self.is_use],
        IsExtinct = data[self.is_extinct] == 1
    }
end

local fscopeAllAchievement = {}
function AchievementTable:getAllAchievement()
    if next(fscopeAllAchievement) ~= nil then
        return fscopeAllAchievement
    end

    local list = {}

    for i = 1, #self.Keys do
        local data = self:GetValueById(self.Keys[i])
        if data[self.is_use] > 0 then
            list[#list + 1] = self:getItemData(self.Keys[i])
        end
    end

    fscopeAllAchievement = list
    return fscopeAllAchievement
end

function AchievementTable:getItemByAchievementId(achievementId)
    return self:getItemData(achievementId)
end

function AchievementTable:getSignById(achievementId)
    return self:GetSingleValue(achievementId, self.sign)
end

function AchievementTable:getNameById(achievementId)
    return self:GetSingleValue(achievementId, self.name)
end

function AchievementTable:getDesc(achievementId)
    return self:GetSingleValue(achievementId, self.description)
end

return AchievementTable
