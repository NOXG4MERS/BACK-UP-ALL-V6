local ActiveRewardTable = class({}, Assets.req("Scripts.ConfigTable.Base.ActiveRewardTableBase"))
-- 通过 Id 得到内容
function ActiveRewardTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ActiveRewardTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ActiveRewardTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ActiveRewardTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function ActiveRewardTable:getRewardData()
    local list = {}
    for k, v in pairs(self.List0) do
        local gameMod = v[self.game_mod]
        if not list[gameMod] then
            list[gameMod] = {}
        end

        local donutReward = v[self.donut_reward]
        if donutReward > 0 then
            local groupMod = v[self.group_mod]
            local tempGroupInfo = {
                startRank = v[self.sort_start],
                endRank = v[self.sort_end],
                groupMod = groupMod
            }

            local tempList = list[gameMod]
            local tempIsHave = false
            for i = 1, #tempList do
                if tempList[i].donutReward == donutReward then
                    tempIsHave = true
                    table.insert(tempList[i], tempGroupInfo)
                end
            end

            if not tempIsHave then
                tempList[#tempList + 1] = {
                    donutReward = donutReward,
                    tempGroupInfo
                }
            end
        end
    end

    if next(list) ~= nil then
        for k, v in pairs(list) do
            table.sort(
                v,
                function(a, b)
                    return a.donutReward > b.donutReward
                end
            )
        end
    end

    return list
end

return ActiveRewardTable
