local ActivityRewardPoolTable = class({}, Assets.req("Scripts.ConfigTable.Base.ActivityRewardPoolTableBase"))
-- 通过 Id 得到内容
function ActivityRewardPoolTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ActivityRewardPoolTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ActivityRewardPoolTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ActivityRewardPoolTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

--得到宝箱物品数据
function ActivityRewardPoolTable:GetItemList()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = v[self.id],
            activityId = v[self.activity_id],
            poolType = v[self.pool_type],
            awardItemId = v[self.award_item_id],
            awardItemNum = v[self.award_item_num],
            rewardPoolId = v[self.reward_pool_id],
            maxTimes = v[self.max_times],
            isShow = v[self.is_show]
        }
    end
    return list
end

--获取图片资源标识
function ActivityRewardPoolTable:GetShowSign(argItemId, argNumber)
    local sign = nil
    for k, v in pairs(self.List0) do
        if argItemId == v[self.get_item_id] and argNumber == v[self.item_num] then
            return v[self.show_sign]
        end
    end
    return sign
end

return ActivityRewardPoolTable
