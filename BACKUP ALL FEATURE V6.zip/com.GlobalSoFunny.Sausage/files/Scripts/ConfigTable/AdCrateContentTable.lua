local AdCrateContentTable = class({}, Assets.req("Scripts.ConfigTable.Base.AdCrateContentTableBase"))
-- 通过 Id 得到内容
function AdCrateContentTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function AdCrateContentTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function AdCrateContentTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function AdCrateContentTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

--得到宝箱物品数据
function AdCrateContentTable:getItemList()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            itemId = v[self.get_item_id],
            num = v[self.item_num],
            seasonType = v[self.season_type],
            sign = v[self.item_quality_id],
            showIndex = v[self.is_show],
            showAll = v[self.overview_show]
        }
    end
    return list
end

--获取图片资源标识
function AdCrateContentTable:getShowSign(argItemId, argNumber)
    local sign = nil
    for k, v in pairs(self.List0) do
        if argItemId == v[self.get_item_id] and argNumber == v[self.item_num] then
            return v[self.show_sign]
        end
    end
    return sign
end

function AdCrateContentTable:GetQualityId(argItemId, argNumber)
    for k, v in pairs(self.List0) do
        if argItemId == v[self.get_item_id] and argNumber == v[self.item_num] then
            return v[self.item_quality_id]
        end
    end
    return nil
end

return AdCrateContentTable
