local BackpackSkinTable = class({}, Assets.req("Scripts.ConfigTable.Base.BackpackSkinTableBase"))
-- 通过 Id 得到内容
function BackpackSkinTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function BackpackSkinTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function BackpackSkinTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function BackpackSkinTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

--获取所有的背包ID
function BackpackSkinTable:getAllBagItemIDList()
    local list = {}
    for k, v in pairs(self.List0) do
        local isBool = true
        local id = v[self.backpack_skin_id]
        for i = 1, #list do
            if list[i] == id then
                isBool = false
            end
        end
        if isBool then
            table.insert(list, id)
        end
    end
    return list
end

--获取物品背包ID对应的所有等级背包的ID
function BackpackSkinTable:getBagLevelList(argItemId)
    local list = {}
    list = self:GetIdsByFieldIndex(self.backpack_skin_id, argItemId)
    table.sort(
        list,
        function(a, b)
            return a < b
        end
    )
    return list
end

--通过等级背包ID取得加载模型的名称
function BackpackSkinTable:getBagSign(argItemBagId)
    return self:GetSingleValue(argItemBagId, self.backpack_skin_def_one)
end

--通过背包的皮肤ID获取物品背包
function BackpackSkinTable:getItemID(argbagItemId)
    return self:GetSingleValue(argbagItemId, self.backpack_skin_id)
end

--获取背包的Index（战场需要）
function BackpackSkinTable:getBagIndex(argItemId)
    local id = self:GetIdByFieldIndex(self.backpack_skin_id, argItemId)
    if id then
        return self:GetSingleValue(id, self.index)
    end
end

--通过背包展示ID获得这个战场展示背包等级
function BackpackSkinTable:getBagLevel(argbagItemId)
    local bagId = -1
    local bagLevel = self:GetSingleValue(argbagItemId, self.backpack_grade)
    if bagLevel == "0" then
        bagId = 203
    elseif bagLevel == "1" then
        bagId = 204
    elseif bagLevel == "2" then
        bagId = 205
    end
    return bagId
end

--获取背包的Index（战场需要）
function BackpackSkinTable:getBagSkinSignBy(artSkinIndex, argLevel)
    for k, v in pairs(self.List0) do
        if v[self.backpack_grade] == argLevel and artSkinIndex == v[self.index] then
            return v[self.backpack_skin_def_one]
        end
    end
end

function BackpackSkinTable:getAllSkinInfo()
    local list = {}
    for k, v in pairs(self.List0) do
        local grade = v[self.backpack_grade]
        local itemId = 203
        if grade == "1" then
            itemId = 204
        elseif grade == "2" then
            itemId = 205
        elseif grade == "3" then
            itemId = 592
        end
        list[#list + 1] = {itemId = itemId, skinId = v[self.backpack_skin_id], skinSign = v[self.backpack_skin_def_one]}
    end
    return list
end

return BackpackSkinTable
