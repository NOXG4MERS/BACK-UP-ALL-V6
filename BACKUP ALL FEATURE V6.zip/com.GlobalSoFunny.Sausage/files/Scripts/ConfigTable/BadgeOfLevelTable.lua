local BadgeOfLevelTable = class({}, Assets.req("Scripts.ConfigTable.Base.BadgeOfLevelTableBase"))
-- 通过 Id 得到内容
function BadgeOfLevelTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function BadgeOfLevelTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function BadgeOfLevelTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function BadgeOfLevelTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function BadgeOfLevelTable:getSignAndQuality(argNum)
    for k, v in pairs(self.List0) do
        if argNum >= v[self.level_start] and argNum <= v[self.level_end] then
            return v[self.badge_sign], v[self.quality_id] - 1
        end
    end
end

function BadgeOfLevelTable:getDesc(argNum)
    for k, v in pairs(self.List0) do
        if argNum >= v[self.level_start] and argNum <= v[self.level_end] then
            return v[self.discription]
        end
    end
end

return BadgeOfLevelTable
