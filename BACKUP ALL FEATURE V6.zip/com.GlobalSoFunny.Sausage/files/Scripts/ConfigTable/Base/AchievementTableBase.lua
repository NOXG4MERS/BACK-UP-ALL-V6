local List0 = {
	[1] = {1,"西天取经","XiTianQuJing","经典四人组队穿不同的西游角色完整套装获得第一名<x>次",0,0,"最铁的友谊，就是一起取过经！","{\"mapmod\":0,\"groupmod\":4,\"gamemod\":1,\"coord\":0,\"at\":0,\"r\":1,\"isfriend\":0,\"suit\":1,\"total_hurt\":0,\"group_info\":0,\"war_equip\":0,\"grade\":0,\"ndtl\":0}",1,1,0},
	[2] = {2,"输出狂魔","ShuChuKuangMo","完成<x>次经典模式单局对敌造成500点伤害",0,0,"一枪在手，天下我有，最强输出就是我！","{\"groupmod\":0,\"gamemod\":1,\"at\":0,\"r\":0,\"isfriend\":0,\"suit\":0,\"total_hurt\":500,\"group_info\":0,\"war_equip\":0}",2,1,0},
	[3] = {3,"身经百战","ShenJingBaiZhan","经典模式累计参与比赛总场次达到<x>次",0,0,"我已经身经百战，没有我不熟悉的地图","{\"groupmod\":0,\"gamemod\":1,\"at\":0,\"r\":0,\"isfriend\":0,\"suit\":0,\"total_hurt\":0,\"group_info\":0,\"war_equip\":0}",167772161,1,0},
	[4] = {4,"打鸟专家","DaNiaoZhuanJia","经典模式累计淘汰<x>个飞高高的敌人",0,0,"飞的再高，也躲不过我的枪口！","{\"groupmod\":0,\"gamemod\":1,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":1}",3,1,0},
	[5] = {5,"我是飞行员","WoShiFeiXingYuan","经典模式累计飞高高距离达到<x>米",0,0,"我要飞的更高，飞的更高~~","{\"groupmod\":0,\"gamemod\":1,\"movetype\":4,\"wd\":0}",167772163,1,0},
	[6] = {6,"载具猎手","ZaiJuLieShou","经典模式引爆载具淘汰<x>人",0,0,"在我面前开车，就是这个后果。","{\"groupmod\":0,\"gamemod\":1,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":1,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":0}",4,1,0},
	[7] = {7,"鹰眼","YingYan","经典模式300m外淘汰<x>人",0,0,"不管你距离我多远，我都能看到你！","{\"groupmod\":0,\"gamemod\":1,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":300,\"kill_group\":0,\"in_sky\":0}",5,1,0},
	[8] = {8,"单枪灭队","DanQiangMieDui","经典四人模式独自消灭一整队敌人<x>次",0,0,"一人就是一支军队，就是这么强！","{\"groupmod\":4,\"gamemod\":1,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":1,\"in_sky\":0}",6,1,0},
	[9] = {9,"全员获胜","QuanYuanHuoSheng","经典四人模式满员存活获得第一名<x>次",0,0,"一个都不能少！","{\"groupmod\":4,\"gamemod\":1,\"at\":0,\"r\":0,\"isfriend\":0,\"suit\":0,\"total_hurt\":0,\"group_info\":1,\"war_equip\":0}",7,1,0},
	[10] = {10,"全村的希望","QuanCunDeXiWang","经典四人模式队伍只剩自己时获得第一名<x>次",0,0,"全村的希望，不能让队友失望。","{\"groupmod\":4,\"gamemod\":1,\"at\":0,\"r\":0,\"isfriend\":0,\"suit\":0,\"total_hurt\":0,\"group_info\":2,\"war_equip\":0}",7,1,0},
	[11] = {11,"一丝不挂","YiSiBuGua","经典模式不装备头盔、防弹衣及背包获得第一名<x>次",0,0,"我是最风骚的派对之王！","{\"groupmod\":0,\"gamemod\":1,\"at\":0,\"r\":1,\"isfriend\":0,\"suit\":0,\"total_hurt\":0,\"group_info\":0,\"war_equip\":1}",8,1,0},
	[33554432] = {33554432,"立地成佛","LuoDiChengHe","经典模式5分钟内被淘汰局数达到<x>局",0,1,"落地就要刚，狂躁，太狂躁了！","{\"groupmod\":0,\"gamemod\":1,\"at\":300,\"r\":0,\"isfriend\":0}",167772172,1,0},
	[33554433] = {33554433,"派对之王","ChiJiXiaoDui","经典模式获得第一名<x>次",0,2,"这是属于我的荣耀时刻！","{\"groupmod\":0,\"gamemod\":1,\"at\":0,\"r\":1,\"isfriend\":0,\"suit\":0,\"total_hurt\":0,\"group_info\":0,\"war_equip\":0}",167772162,1,0},
	[33554434] = {33554434,"奔跑吧！少年","BenPaoShaoNian","经典模式累计徒步移动距离达到<x>米",0,101,"天生马拉松选手！沿路都是风景","{\"groupmod\":0,\"gamemod\":1,\"movetype\":1,\"wd\":0}",167772163,1,0},
	[33554435] = {33554435,"职业突击手","TuJiDaShen","经典模式使用突击步枪淘汰敌人达到<x>人",0,102,"迅捷如风，随后枪出如龙！","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":1,\"coord\":0,\"weapon_type\":19,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":0,\"on_ball\":0}",167772164,1,0},
	[33554436] = {33554436,"喷射战士","JinZhanDaShen","经典模式使用霰弹枪淘汰敌人达到<x>人",0,103,"你会爱上喷射后的浓烈火药味","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":1,\"coord\":0,\"weapon_type\":20,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":0,\"on_ball\":0}",167772164,1,0},
	[33554437] = {33554437,"茁壮成长","YiLuXiangBang","赛季等级达到<x>级",1,201,"成长，就是从一个香肠宝宝开始..","{}",167772171,1,0},
	[33554438] = {33554438,"并肩前行","BingJianQianXing","经典四排进前10名<x>次",0,3,"先定一个小目标，一起进前10名！","{\"groupmod\":4,\"gamemod\":1,\"at\":0,\"r\":10,\"isfriend\":0,\"suit\":0,\"total_hurt\":0,\"group_info\":0,\"war_equip\":0}",167772162,0,0},
	[33554439] = {33554439,"救死扶伤","JiuSiFuShang","经典模式救援<x>次队友",0,104,"救人全靠吼！加油！加油！加油！","{\"groupmod\":0,\"gamemod\":1}",167772170,1,0},
	[33554440] = {33554440,"有仇必报","YaZiBiBao","经典模式累计淘汰<x>名曾把你或队友击倒的敌人",0,105,"我这人有个好毛病，就是记仇","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":1,\"coord\":0,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":1,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":0,\"on_ball\":0}",167772166,1,0},
	[33554441] = {33554441,"信仰射手","FeiZhouDaShi","经典模式使用信仰射击淘汰敌人达到<x>次",0,106,"射击不一定靠技术，还需要信仰","{\"groupmod\":0,\"gamemod\":1,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":1,\"inwater\":0,\"bullet\":0}",167772168,1,0},
	[33554442] = {33554442,"职业狙击手","JuShenWuDi","经典模式使用狙击枪淘汰敌人达到<x>人",0,107,"开启倍镜后，总是冷静到令人窒息","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":1,\"coord\":0,\"weapon_type\":21,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":0,\"on_ball\":0}",167772164,1,0},
	[33554443] = {33554443,"爆炸狂人","ShouLiuDaShi","经典模式使用手雷淘汰敌人达到<x>人",0,108,"艺术就是爆炸！","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":1,\"coord\":0,\"weapon_type\":31,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":0,\"on_ball\":0}",167772164,1,0},
	[33554444] = {33554444,"暴击大师","YiJiBaoTou","经典模式累计暴击淘汰敌人达到<x>人",0,109,"小心你的脑袋，已经被我盯上了","{\"groupmod\":0,\"gamemod\":1,\"weapon_type\":0,\"weapon\":0,\"kbh\":1,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0}",167772167,1,0},
	[33554445] = {33554445,"舔包达人","TianBaoDaRen","经典任意模式累计搜索<x>个稻草人盒子",0,110,"你的就是我的，我的还是我的！","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":1,\"boxt\":0}",167772169,1,0},
	[33554446] = {33554446,"追梦达人","ZhuiMengDaRen","经典任意模式累计搜索<x>次空投箱子",0,111,"哎呦，怎么又一个空投砸我身上啊！","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":1,\"boxt\":1}",167772169,1,0},
	[33554447] = {33554447,"无所遁形","WuSuoDunXing","经典任意模式累计淘汰<x>个在游泳的敌人",0,112,"别以为你潜水了，我就找不到你！天真！","{\"groupmod\":0,\"gamemod\":1,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":1,\"bullet\":0}",167772165,0,0},
	[33554448] = {33554448,"开箱达人","KaiXiangDaRen","累计开箱<x>次",0,202,"开的不是箱，开的是幸福满满","{}",167772171,1,0},
	[33554449] = {33554449,"荣耀之路","RongYaoZhiLu","段位积分达到<x>分",1,203,"荣耀之路肯定有，就看怎么走。","{}",167772171,1,0},
	[33554450] = {33554450,"时尚达人","ShiShangDaRen","拥有<x>件永久装扮",1,301,"买买买，开心就好。","{}",167772171,1,0},
	[33554451] = {33554451,"社交达人","SheJiaoDaRen","拥有<x>个游戏好友",1,401,"有朋自远方来，不亦乐乎！","{}",167772171,1,0},
	[33554452] = {33554452,"好基友","HaoJiYou","经典模式累计与好友组队完成比赛<x>次",0,402,"手拉手，一起走！","{\"groupmod\":4,\"gamemod\":1,\"at\":120,\"r\":0,\"isfriend\":1,\"suit\":0,\"total_hurt\":0,\"group_info\":0,\"war_equip\":0}",167772160,1,0},
	[33554453] = {33554453,"万人迷","WanRenMi","累计拥有粉丝关注<x>人",1,403,"走到哪，总能散发出迷人的气息！","{}",167772171,1,0},
	[33554454] = {33554454,"任务达人","RenWuDaRen","累计完成任务<x>次",0,999,"我喜欢做任务，更喜欢甜甜圈！","{}",167772171,1,1},
	[33554455] = {33554455,"坚持不懈","JianChiBuXie","累计登陆<x>天",0,998,"热爱，就是每天坚持上来打卡！","{}",167772171,1,0},
}

local Keys = {1,2,3,4,5,6,7,8,9,10,11,33554432,33554433,33554434,33554435,33554436,33554437,33554438,33554439,33554440,33554441,33554442,33554443,33554444,33554445,33554446,33554447,33554448,33554449,33554450,33554451,33554452,33554453,33554454,33554455,}



local AchievementTableBase = {

    -- 记录数
	COUNT = 36,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	description = 4,
	finish_type = 5,
	sort = 6,
	content = 7,
	json_data = 8,
	achievement_type_id = 9,
	is_use = 10,
	is_extinct = 11,

    -- 标识常量
	["XiTianQuJing"] = "XiTianQuJing",
	["ShuChuKuangMo"] = "ShuChuKuangMo",
	["ShenJingBaiZhan"] = "ShenJingBaiZhan",
	["DaNiaoZhuanJia"] = "DaNiaoZhuanJia",
	["WoShiFeiXingYuan"] = "WoShiFeiXingYuan",
	["ZaiJuLieShou"] = "ZaiJuLieShou",
	["YingYan"] = "YingYan",
	["DanQiangMieDui"] = "DanQiangMieDui",
	["QuanYuanHuoSheng"] = "QuanYuanHuoSheng",
	["QuanCunDeXiWang"] = "QuanCunDeXiWang",
	["YiSiBuGua"] = "YiSiBuGua",
	["LuoDiChengHe"] = "LuoDiChengHe",
	["ChiJiXiaoDui"] = "ChiJiXiaoDui",
	["BenPaoShaoNian"] = "BenPaoShaoNian",
	["TuJiDaShen"] = "TuJiDaShen",
	["JinZhanDaShen"] = "JinZhanDaShen",
	["YiLuXiangBang"] = "YiLuXiangBang",
	["BingJianQianXing"] = "BingJianQianXing",
	["JiuSiFuShang"] = "JiuSiFuShang",
	["YaZiBiBao"] = "YaZiBiBao",
	["FeiZhouDaShi"] = "FeiZhouDaShi",
	["JuShenWuDi"] = "JuShenWuDi",
	["ShouLiuDaShi"] = "ShouLiuDaShi",
	["YiJiBaoTou"] = "YiJiBaoTou",
	["TianBaoDaRen"] = "TianBaoDaRen",
	["ZhuiMengDaRen"] = "ZhuiMengDaRen",
	["WuSuoDunXing"] = "WuSuoDunXing",
	["KaiXiangDaRen"] = "KaiXiangDaRen",
	["RongYaoZhiLu"] = "RongYaoZhiLu",
	["ShiShangDaRen"] = "ShiShangDaRen",
	["SheJiaoDaRen"] = "SheJiaoDaRen",
	["HaoJiYou"] = "HaoJiYou",
	["WanRenMi"] = "WanRenMi",
	["RenWuDaRen"] = "RenWuDaRen",
	["JianChiBuXie"] = "JianChiBuXie",
}

local languageColumns = {2, 4, 7}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return AchievementTableBase