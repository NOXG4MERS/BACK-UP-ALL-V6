local List0 = {
	[1] = {1,"游戏结束-套装","GameOverSuit",2},
	[2] = {2,"游戏结束-伤害量","GameOverHurt",2},
	[3] = {3,"击杀-打鸟","KillBird",8},
	[4] = {4,"击杀-引爆载具","KillVehicle",8},
	[5] = {5,"击杀-距离","KillDistance",8},
	[6] = {6,"击杀-整队","KillGroup",8},
	[7] = {7,"游戏结束-队伍情况","GameOverGroupInfo",2},
	[8] = {8,"游戏结束-战场装备","GameOverWarEquip",2},
	[167772160] = {167772160,"游戏结束-好友","GameOverFriend",2},
	[167772161] = {167772161,"游戏结束-生存","GameOverAlive",2},
	[167772162] = {167772162,"游戏结束-排名","GameOverRankings",2},
	[167772163] = {167772163,"移动","Move",5},
	[167772164] = {167772164,"击杀-武器类","KillWeaponType",8},
	[167772165] = {167772165,"击杀-游泳","KillSwim",8},
	[167772166] = {167772166,"击杀-反杀","KillBack",8},
	[167772167] = {167772167,"击杀-爆头","KillHead",8},
	[167772168] = {167772168,"击杀-姿势","KillPosture",8},
	[167772169] = {167772169,"舔包","GetItem",10},
	[167772170] = {167772170,"救人","PickUP",1},
	[167772171] = {167772171,"非事件触发成就","NoEvent",0},
	[167772172] = {167772172,"死亡","Dead",9},
}

local Keys = {1,2,3,4,5,6,7,8,167772160,167772161,167772162,167772163,167772164,167772165,167772166,167772167,167772168,167772169,167772170,167772171,167772172,}



local AchievementTypeTableBase = {

    -- 记录数
	COUNT = 22,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	war_event_id = 4,

    -- 标识常量
	["GameOverSuit"] = "GameOverSuit",
	["GameOverHurt"] = "GameOverHurt",
	["KillBird"] = "KillBird",
	["KillVehicle"] = "KillVehicle",
	["KillDistance"] = "KillDistance",
	["KillGroup"] = "KillGroup",
	["GameOverGroupInfo"] = "GameOverGroupInfo",
	["GameOverWarEquip"] = "GameOverWarEquip",
	["GameOverFriend"] = "GameOverFriend",
	["GameOverAlive"] = "GameOverAlive",
	["GameOverRankings"] = "GameOverRankings",
	["Move"] = "Move",
	["KillWeaponType"] = "KillWeaponType",
	["KillSwim"] = "KillSwim",
	["KillBack"] = "KillBack",
	["KillHead"] = "KillHead",
	["KillPosture"] = "KillPosture",
	["GetItem"] = "GetItem",
	["PickUP"] = "PickUP",
	["NoEvent"] = "NoEvent",
	["Dead"] = "Dead",
}

local languageColumns = {2}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return AchievementTypeTableBase