local List0 = {
	[905969664] = {905969664,905969664,1,133,180},
}

local Keys = {905969664,}



local ActivityShopContentTableBase = {

    -- 记录数
	COUNT = 2,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	activity_shop_id = 2,
	show_order = 3,
	item_id = 4,
	num = 5,

    -- 标识常量
}



return ActivityShopContentTableBase