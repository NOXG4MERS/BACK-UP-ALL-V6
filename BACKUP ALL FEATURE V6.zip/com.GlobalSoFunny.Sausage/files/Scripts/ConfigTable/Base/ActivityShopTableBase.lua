local List0 = {
	[905969664] = {905969664,"回流特惠糖果礼包",1,"com.xd.sausage.TeHuiTangGuo","","",""},
}

local Keys = {905969664,}



local ActivityShopTableBase = {

    -- 记录数
	COUNT = 2,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	show_order = 3,
	product_id = 4,
	pic_sign = 5,
	bg_sign = 6,
	discount_sign = 7,

    -- 标识常量
}

local languageColumns = {2}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return ActivityShopTableBase