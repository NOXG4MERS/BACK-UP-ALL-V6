local List0 = {
	[1] = {1,"SG","SEA",60,60,5},
	[2] = {2,"MY","SEA",60,60,5},
	[3] = {3,"ID","SEA",60,60,5},
}

local Keys = {1,2,3,}



local AreaMatchTableBase = {

    -- 记录数
	COUNT = 4,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	area = 2,
	next_area = 3,
	wait_teammate_timeout = 4,
	team_wait_timeout = 5,
	classic_wait_timeout = 6,

    -- 标识常量
}



return AreaMatchTableBase