local List0 = {
	[1] = {1,1,9,"BadgeOfLevel1",1,"当前等级徽章"},
	[2] = {2,10,19,"BadgeOfLevel10",1,"当前等级徽章"},
	[3] = {3,20,29,"BadgeOfLevel20",1,"当前等级徽章"},
	[4] = {4,30,39,"BadgeOfLevel30",2,"当前等级徽章"},
	[5] = {5,40,49,"BadgeOfLevel40",2,"当前等级徽章"},
	[6] = {6,50,59,"BadgeOfLevel50",2,"当前等级徽章"},
	[7] = {7,60,69,"BadgeOfLevel60",3,"当前等级徽章"},
	[8] = {8,70,79,"BadgeOfLevel70",3,"当前等级徽章"},
	[9] = {9,80,89,"BadgeOfLevel80",4,"当前等级徽章"},
	[10] = {10,90,99,"BadgeOfLevel90",4,"当前等级徽章"},
	[11] = {11,100,275,"BadgeOfLevelMax",5,"当前等级徽章"},
}

local Keys = {1,2,3,4,5,6,7,8,9,10,11,}



local BadgeOfLevelTableBase = {

    -- 记录数
	COUNT = 12,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	level_start = 2,
	level_end = 3,
	badge_sign = 4,
	quality_id = 5,
	discription = 6,

    -- 标识常量
}

local languageColumns = {6}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return BadgeOfLevelTableBase