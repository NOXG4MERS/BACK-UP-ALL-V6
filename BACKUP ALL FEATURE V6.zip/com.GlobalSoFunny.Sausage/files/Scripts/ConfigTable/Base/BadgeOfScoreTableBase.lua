local List0 = {
	[1] = {1,0,1499,"青铜","BadgeOfQingTong",1,"青铜段位徽章，达到1500分可解锁白银段位徽章"},
	[2] = {2,1500,1999,"白银","BadgeOfBaiYin",2,"白银段位徽章，达到2000分可解锁黄金段位徽章"},
	[3] = {3,2000,2499,"黄金","BadgeOfHuangJing",3,"黄金段位徽章，达到2500分可解锁铂金段位徽章"},
	[4] = {4,2500,2999,"铂金","BadgeOfBoJing",3,"铂金段位徽章，达到3000分可解锁钻石段位徽章"},
	[5] = {5,3000,3499,"钻石","BadgeOfZuanShi",4,"钻石段位徽章，达到3500分可解锁大师段位徽章"},
	[6] = {6,3500,3999,"大师","BadgeOfDaShi",4,"大师段位徽章，达到4000分可解锁巅峰段位徽章"},
	[7] = {7,4000,2000000000,"巅峰","BadgeOfDianFeng",5,"达到巅峰段位后，段位积分每提升100可激活1星"},
}

local Keys = {1,2,3,4,5,6,7,}



local BadgeOfScoreTableBase = {

    -- 记录数
	COUNT = 8,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	score_start = 2,
	score_end = 3,
	name = 4,
	badge_sign = 5,
	quality_id = 6,
	discription = 7,

    -- 标识常量
}

local languageColumns = {4, 7}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return BadgeOfScoreTableBase