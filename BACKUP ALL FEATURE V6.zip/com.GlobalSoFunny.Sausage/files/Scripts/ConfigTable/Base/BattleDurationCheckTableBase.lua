local List0 = {
	[335544320] = {335544320,2,1,1,1,1,30},
	[335544321] = {335544321,1,1,1,1,1,30},
	[335544322] = {335544322,4,1,1,1,1,30},
	[335544323] = {335544323,3,1,1,1,1,30},
}

local Keys = {335544320,335544321,335544322,335544323,}



local BattleDurationCheckTableBase = {

    -- 记录数
	COUNT = 5,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	game_mod = 2,
	abnormal_enable = 3,
	medium_abnormal_enable = 4,
	high_abnormal_enable = 5,
	crit_abnormal_enable = 6,
	check_duration = 7,

    -- 标识常量
}



return BattleDurationCheckTableBase