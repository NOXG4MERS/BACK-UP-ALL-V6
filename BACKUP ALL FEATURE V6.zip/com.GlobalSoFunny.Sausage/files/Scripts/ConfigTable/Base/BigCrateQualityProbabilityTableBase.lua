local List0 = {
	[1] = {1,2,483},
	[2] = {2,3,342},
	[3] = {3,4,125},
	[4] = {4,5,50},
}

local Keys = {1,2,3,4,}



local BigCrateQualityProbabilityTableBase = {

    -- 记录数
	COUNT = 5,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	quality_id = 2,
	probability = 3,

    -- 标识常量
}



return BigCrateQualityProbabilityTableBase