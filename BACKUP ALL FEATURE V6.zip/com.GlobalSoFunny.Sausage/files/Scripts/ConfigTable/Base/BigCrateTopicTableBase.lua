local List0 = {
	[1] = {1,"基础商品内容","topic1","",1},
	[2] = {2,"S1皮皮马戏团内容","topic2","S1",2},
	[335544320] = {335544320,"元气摇滚团","topic3","",1},
	[838860800] = {838860800,"S5YYY星人","topic6","S5",2},
	[1040187392] = {1040187392,"基础商品内容（海外）","topic1","",1},
	[2080374784] = {2080374784,"S3勇者斗恶龙","topic5","",2},
	[2113929216] = {2113929216,"S6众神降临","topic7","S6",2},
	[2113929217] = {2113929217,"活动奖励物返场1","topic8","",2},
}

local Keys = {1,2,335544320,838860800,1040187392,2080374784,2113929216,2113929217,}

local List1 = { 
	[1] =  {1},
	[2] =  {2},
	[335544320] =  {335544320},
	[838860800] =  {838860800},
	[1040187392] =  {1040187392},
	[2080374784] =  {2080374784},
	[2113929216] =  {2113929216},
	[2113929217] =  {2113929217},
}


local BigCrateTopicTableBase = {

    -- 记录数
	COUNT = 9,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,

	List1 = List1,


    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	show_sign = 4,
	crate_topic_type = 5,

    -- 标识常量
	["topic1"] = "topic1",
	["topic2"] = "topic2",
	["topic3"] = "topic3",
	["topic6"] = "topic6",
	["topic1"] = "topic1",
	["topic5"] = "topic5",
	["topic7"] = "topic7",
	["topic8"] = "topic8",
}

local languageColumns = {2}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return BigCrateTopicTableBase