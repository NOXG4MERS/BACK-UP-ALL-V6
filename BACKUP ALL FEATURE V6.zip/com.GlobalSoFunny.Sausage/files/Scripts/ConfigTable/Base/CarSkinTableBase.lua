local List0 = {
	[704643072] = {704643072,704643100,704643097,1,704643073,0,0},
	[704643073] = {704643073,704643100,872415359,0,704643073,1,0},
	[2080374784] = {2080374784,704643100,2080374862,0,704643073,2,0},
}

local Keys = {704643072,704643073,2080374784,}



local CarSkinTableBase = {

    -- 记录数
	COUNT = 4,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	car_item_id = 2,
	skin_item_id = 3,
	is_default_skin = 4,
	red_point = 5,
	index = 6,
	theme = 7,

    -- 标识常量
}



return CarSkinTableBase