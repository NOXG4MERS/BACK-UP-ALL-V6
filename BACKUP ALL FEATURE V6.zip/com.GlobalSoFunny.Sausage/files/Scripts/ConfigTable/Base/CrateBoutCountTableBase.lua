local List0 = {
	[335544320] = {335544320,1,40},
	[335544321] = {335544321,2,80},
	[335544322] = {335544322,3,120},
}

local Keys = {335544320,335544321,335544322,}



local CrateBoutCountTableBase = {

    -- 记录数
	COUNT = 4,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	bout = 2,
	max_num = 3,

    -- 标识常量
}



return CrateBoutCountTableBase