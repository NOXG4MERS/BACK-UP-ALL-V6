local List0 = {
	[234881024] = {234881024,1,7500,4000},
	[234881025] = {234881025,2,1999,4000},
	[234881026] = {234881026,3,400,1640},
	[234881027] = {234881027,4,100,330},
	[234881028] = {234881028,5,1,30},
}

local Keys = {234881024,234881025,234881026,234881027,234881028,}



local CrateQualityProbabilityTableBase = {

    -- 记录数
	COUNT = 6,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	quality_id = 2,
	probability = 3,
	pay_probability = 4,

    -- 标识常量
}



return CrateQualityProbabilityTableBase