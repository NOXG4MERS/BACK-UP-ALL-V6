local List0 = {
	[570425345] = {570425345,1,"彩虹岛-狙击对决","{\"myBasics\":{\"GameSelectionID\":805306370,\"gameMod\":1,\"groupMod\":4,\"isInvitionFriend\":1,\"maxMemberCount\":100},\"myProgramme\":[[570425408,0],[570425409,0],[738197506,0],[738197507,0],[570425412,3],[570425413,3],[570425414,6],[570425415,3],[738197512,0],[570425417,3],[570425418,3],[570425419,3],[570425551,0],[1207959568,0],[570425553,0],[570425426,6],[570425427,3],[570425365,0],[570425366,0],[570425367,0],[570425368,0],[570425369,0],[570425370,0],[570425371,0],[570425373,0],[570425374,0],[570425375,0],[570425376,0],[1207959573,0],[570425378,0],[570425379,0],[1207959571,0],[1207959569,0],[1207959570,0],[570425563,0],[570425561,0],[570425559,0],[570425555,0],[570425542,0],[570425452,0],[570425541,0],[570425539,0],[570425537,0],[570425535,0],[570425410,6],[738197508,0],[1207959554,0],[1207959555,3],[570425461,0],[1207959553,3],[570425527,0],[738197504,0],[738197505,0],[570425530,0],[738197509,0],[738197511,0],[570425533,0],[570425406,0],[570425407,0]]}"},
}

local Keys = {570425345,}



local CustomRoomPreinstallConfTableBase = {

    -- 记录数
	COUNT = 2,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	show_order = 2,
	name = 3,
	conf = 4,

    -- 标识常量
}

local languageColumns = {3}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return CustomRoomPreinstallConfTableBase