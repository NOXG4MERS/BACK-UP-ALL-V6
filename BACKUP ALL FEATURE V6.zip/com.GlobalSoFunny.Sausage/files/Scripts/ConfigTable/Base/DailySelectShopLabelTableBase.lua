local List0 = {
	[469762048] = {469762048,"新手非R","XinShouFeiR",0,0,"新手非R",5},
	[469762049] = {469762049,"老手非R","LaoShouFeiR",10,0,"老手非R",9},
	[469762050] = {469762050,"新手小R","XinShouXiaoR",0,1,"新手小R",6},
	[469762051] = {469762051,"新手中R","XinShouZhongR",0,31,"新手中R",7},
	[469762052] = {469762052,"新手大R","XinShouDaR",0,329,"新手大R",8},
	[469762053] = {469762053,"老手小R","LaoShouXiaoR",10,1,"老手小R",10},
	[469762054] = {469762054,"老手中R","LaoShouZhongR",10,31,"老手中R",11},
	[469762055] = {469762055,"老手大R","LaoShouDaR",10,329,"老手大R",12},
	[469762056] = {469762056,"新手第一天","XinShouDiYiTian",1,0,"新手第一天",1},
	[469762057] = {469762057,"新手第二天","XinShouDiErTian",2,0,"新手第二天",2},
	[469762058] = {469762058,"新手第三天","XinShouDiSanTian",3,0,"新手第三天",3},
	[469762059] = {469762059,"新手第四天","XinShouDiSiTian",4,4,"新手第四天",4},
	[469762060] = {469762060,"备用","BeiYong",0,0,"备用",0},
}

local Keys = {469762048,469762049,469762050,469762051,469762052,469762053,469762054,469762055,469762056,469762057,469762058,469762059,469762060,}



local DailySelectShopLabelTableBase = {

    -- 记录数
	COUNT = 14,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	arg1 = 4,
	arg2 = 5,
	desc = 6,
	select_order = 7,

    -- 标识常量
	["XinShouFeiR"] = "XinShouFeiR",
	["LaoShouFeiR"] = "LaoShouFeiR",
	["XinShouXiaoR"] = "XinShouXiaoR",
	["XinShouZhongR"] = "XinShouZhongR",
	["XinShouDaR"] = "XinShouDaR",
	["LaoShouXiaoR"] = "LaoShouXiaoR",
	["LaoShouZhongR"] = "LaoShouZhongR",
	["LaoShouDaR"] = "LaoShouDaR",
	["XinShouDiYiTian"] = "XinShouDiYiTian",
	["XinShouDiErTian"] = "XinShouDiErTian",
	["XinShouDiSanTian"] = "XinShouDiSanTian",
	["XinShouDiSiTian"] = "XinShouDiSiTian",
	["BeiYong"] = "BeiYong",
}

local languageColumns = {2, 6}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return DailySelectShopLabelTableBase