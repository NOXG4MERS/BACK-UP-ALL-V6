local List0 = {
	[469762048] = {469762048,469762055,1,133,600},
	[469762049] = {469762049,469762056,1,133,50},
}

local Keys = {469762048,469762049,}



local DailySelectShopManualContentTableBase = {

    -- 记录数
	COUNT = 3,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	daily_select_shop_manual_id = 2,
	show_order = 3,
	item_id = 4,
	num = 5,

    -- 标识常量
}



return DailySelectShopManualContentTableBase