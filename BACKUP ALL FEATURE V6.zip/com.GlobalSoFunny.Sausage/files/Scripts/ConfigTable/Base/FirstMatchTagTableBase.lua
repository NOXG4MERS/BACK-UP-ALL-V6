local List0 = {
	[1] = {1,"SuiXinSuoYu","随心所欲",2,0,"Icon_Tag_Random"},
	[2] = {2,"ReDianGangQiang","热点刚枪",1,1,"Icon_Tag_Fighter"},
	[3] = {3,"YeDianFaYu","野点发育",1,2,"Icon_Tag_Growth"},
}

local Keys = {1,2,3,}



local FirstMatchTagTableBase = {

    -- 记录数
	COUNT = 4,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	sign = 2,
	description = 3,
	next_match_tag_id = 4,
	show_pos = 5,
	resource_sign = 6,

    -- 标识常量
	["SuiXinSuoYu"] = "SuiXinSuoYu",
	["ReDianGangQiang"] = "ReDianGangQiang",
	["YeDianFaYu"] = "YeDianFaYu",
}

local languageColumns = {3}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return FirstMatchTagTableBase