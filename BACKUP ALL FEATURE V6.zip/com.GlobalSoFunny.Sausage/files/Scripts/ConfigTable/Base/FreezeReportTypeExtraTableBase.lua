local List0 = {
	[838860800] = {838860800,1,5,8,2,0},
	[872415232] = {872415232,2,5,8,2,87600},
}

local Keys = {838860800,872415232,}



local FreezeReportTypeExtraTableBase = {

    -- 记录数
	COUNT = 3,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	extra_type = 2,
	punish_level = 3,
	mark_punish_level = 4,
	mark_num_punish = 5,
	punish_period = 6,

    -- 标识常量
}



return FreezeReportTypeExtraTableBase