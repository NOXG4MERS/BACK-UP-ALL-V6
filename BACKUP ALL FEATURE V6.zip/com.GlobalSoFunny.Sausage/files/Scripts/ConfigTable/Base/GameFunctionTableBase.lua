local List0 = {
	[1] = {1,"聊天功能",0,0,"FuncChat",60,0,0},
	[3] = {3,"萌新登录",0,0,"MengXinDengLu",1,0,0},
	[4] = {4,"活动系统",0,0,"Activity",1,0,0},
	[5] = {5,"新内容公告",0,0,"NewContent",1,0,0},
}

local Keys = {1,3,4,5,}



local GameFunctionTableBase = {

    -- 记录数
	COUNT = 5,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	func_type = 3,
	ext_param = 4,
	sign = 5,
	value = 6,
	has_action = 7,
	red_point = 8,

    -- 标识常量
	["FuncChat"] = "FuncChat",
	["MengXinDengLu"] = "MengXinDengLu",
	["Activity"] = "Activity",
	["NewContent"] = "NewContent",
}



return GameFunctionTableBase