local List0 = {
	[1] = {1,5,"8v8跳伞狙击-彩虹岛",";;率先到达40淘汰;季票勋章;",16,0,"Entrance_8V8Sniper_ui","Entrance_8V8Sniper",2,0,0,"8v8跳伞狙击-彩虹岛",0,4,0,""},
	[436207616] = {436207616,5,"快速空投机甲-彩虹岛",";;进入前三;季票勋章;",22,0,"Entrance_MachineLaTale_ui","LimitedTime_MachineLaTale",1,0,0,"空投机甲-彩虹岛",1,4,1,""},
	[570425344] = {570425344,8,"能源工厂",";;率先收集60颗星星;季票勋章;",0,0,"Entrance_RainbowFight_ui","Custroom_RainbowFight",0,1,0,"",0,0,0,""},
	[570425345] = {570425345,9,"午夜擂台",";;率先获得3回合胜利;季票勋章;",0,0,"Entrance_Battle2V2_ui","Custroom_Battle2V2",0,1,0,"",0,0,0,""},
	[603979776] = {603979776,7,"疯狂马戏团",";;总积分高的一方获胜;季票勋章;",0,0,"Entrance_CircusTroupe_ui","Custroom_CircusTroupe",0,1,0,"",0,0,0,""},
	[603979777] = {603979777,5,"身份卡乱斗-彩虹岛","28人;1x1km;进入前三;季票勋章;",24,0,"Entrance_IDCardMode_ui","LimitedTime_IDCard",1,0,0,"身份卡乱斗-彩虹岛",1,4,1,""},
	[671088640] = {671088640,5,"1v1枪战对决-午夜擂台",";;率先获得3回合胜利;季票勋章;",26,0,"Entrance_Battle2V2_ui","LimitedTime_Battle1V1",2,0,0,"1v1枪战对决-午夜擂台",0,1,0,""},
	[671088641] = {671088641,5,"2v2枪战对决-午夜擂台",";;率先获得3回合胜利;季票勋章;",23,0,"Entrance_Battle2V2_ui","LimitedTime_Battle2V2",2,0,0,"2v2枪战对决-午夜擂台",0,2,0,""},
	[671088642] = {671088642,5,"4v4枪战对决-午夜擂台",";;率先获得3回合胜利;季票勋章;",0,1,"Entrance_Battle4V4_ui","LimitedTime_Battle4V4",2,0,0,"4v4枪战对决-午夜擂台",0,4,0,""},
	[704643072] = {704643072,1,"随机地图",";;进入前三;段位积分 季票勋章;",0,0,"Entrance_ClassRandomMap_ui","Classic_Random",6,0,0,"经典模式-随机地图",1,4,1,""},
	[704643073] = {704643073,1,"战斗岛","100人;8x8km;进入前三;段位积分 季票勋章;",1,0,"Entrance_ClassiBattle_ui","Classic_BattleLsland",6,0,0,"经典模式-战斗岛",1,4,1,""},
	[704643074] = {704643074,1,"彩虹岛","100人;4x4km;进入前三;段位积分 季票勋章;",2,0,"Entrance_ClassiRainbow_ui","Classic_LaTale",6,0,0,"经典模式-彩虹岛",1,4,1,""},
	[704643076] = {704643076,5,"快速派对-战斗岛","28人;1x1km;进入前三;季票勋章;",1,0,"Entrance_BattleIsland_ui","FastParty_BattleLsland",1,0,1,"快速派对-战斗岛",1,4,1,""},
	[704643077] = {704643077,5,"快速派对-彩虹岛","28人;1x1km;进入前三;季票勋章;",2,0,"Entrance_LaTale_ui","FastParty_LaTale",1,0,1,"快速派对-彩虹岛",1,4,1,""},
	[704643079] = {704643079,5,"团队激斗-竞技中心","16人;150x150m;率先达到80淘汰;季票勋章;",3,0,"Entrance_SportsCenter_ui","TeamFighting_SportsCenter",2,0,2,"团队激斗-竞技中心",0,8,0,""},
	[704643080] = {704643080,5,"团队激斗-5号广场","16人;150x150m;率先达到80淘汰;季票勋章;",4,0,"Entrance_Plaza5_ui","TeamFighting_Plaza5",2,0,2,"团队激斗-5号广场",0,8,0,""},
	[704643081] = {704643081,5,"团队激斗-风车街道","16人;150x150m;率先达到80淘汰;季票勋章;",5,0,"Entrance_WindmillPlaza_ui","TeamFighting_WindmillPlaza",2,0,2,"团队激斗-风车街道",0,8,0,""},
	[704643082] = {704643082,5,"团队激斗-温泉山庄","16人;150x150m;率先达到80淘汰;季票勋章;",6,0,"Entrance_SpringSpaHotel_ui","TeamFighting_SpringSpaHotel",2,0,2,"团队激斗-温泉山庄",0,8,0,""},
	[704643083] = {704643083,5,"团队激斗-怒海争锋","16人;150x150m;率先达到80淘汰;季票勋章;",7,0,"Entrance_FierceBattle_ui","TeamFighting_FierceBattle",2,0,0,"团队激斗-怒海争锋",0,8,0,""},
	[704643084] = {704643084,5,"狙击对决","16人;150x150m;率先达到60淘汰;季票勋章;",20,0,"Entrance_TeamtRandomMap_ui","SniperFight_Random",2,0,0,"",0,8,0,""},
	[704643088] = {704643088,5,"躲猫猫-疯狂马戏团",";;总积分高的一方获胜;季票勋章;",11,0,"Entrance_CircusTroupe_ui","LimitedTime_CircusTroupe",2,0,0,"躲猫猫-疯狂马戏团",0,6,0,""},
	[704643089] = {704643089,5,"火力全开-停电工坊",";;率先到达80淘汰;季票勋章;",12,0,"Entrance_FirepowerDuel_ui","LimitedTime_FirepowerDuel",2,0,0,"火力全开-停电工坊",0,8,0,""},
	[704643090] = {704643090,5,"实验室激斗",";;率先到达80淘汰;季票勋章;",25,0,"Entrance_GrenadeDuel_ui","LimitedTime_GrenadeDuel",2,0,0,"",0,8,0,""},
	[704643091] = {704643091,5,"快速霰弹枪战-战斗岛",";;进入前三;季票勋章;",13,0,"Entrance_ShotgunDuel_ui","LimitedTime_ShotgunDuel",1,0,0,"霰弹枪战-战斗岛",1,4,1,""},
	[704643092] = {704643092,5,"12V12团队战-彩虹岛",";;率先到达80淘汰;季票勋章;",14,0,"Entrance_LegionWarfare_ui","LimitedTime_LegionWarfare",2,0,0,"12V12团队战-彩虹岛",0,4,0,""},
	[704643094] = {704643094,5,"快速空投机甲-战斗岛",";;进入前三;季票勋章;",21,0,"Entrance_Machine_ui","LimitedTime_Machine",1,0,0,"空投机甲-战斗岛",1,4,1,""},
	[704643095] = {704643095,6,"私人训练场",";;一个没有危险的私人练习空间;;",0,0,"Entrance_PrivateTraining_ui","Train_PrivateTraining",3,0,0,"",0,0,0,""},
	[704643096] = {704643096,6,"多人游乐场",";;可以组队和其它玩家聚在一起游玩的空间;;",1,0,"Entrance_SausageClub_ui","Train_SausageClub",5,0,0,"训练靶场-多人游乐场",0,4,0,""},
	[704643097] = {704643097,6,"自定义房间",";;创建属于你自己的游戏模式;;",2,0,"Entrance_CustomRoom_ui","Train_CustomRoom",4,0,0,"",0,0,0,""},
	[704643098] = {704643098,5,"星星争夺-能源工厂",";;率先收集60颗星星;季票勋章;",17,0,"Entrance_RainbowFight_ui","LimitedTime_RainbowFight",2,0,0,"星星争夺-能源工厂",0,6,0,""},
	[805306368] = {805306368,1,"随机地图",";;进入前三;段位积分 季票勋章;",0,0,"Entrance_ClassRandomMap_ui","Custroom_Classic_Random",6,1,0,"",0,0,0,""},
	[805306369] = {805306369,1,"战斗岛","100人;8x8km;进入前三;段位积分 季票勋章;",1,0,"Entrance_ClassiBattle_ui","Custroom_Classic_BattleLsland",6,1,0,"",0,0,0,""},
	[805306370] = {805306370,1,"彩虹岛","100人;4x4km;进入前三;段位积分 季票勋章;",2,0,"Entrance_ClassiRainbow_ui","Custroom_Classic_LaTale",6,1,0,"",0,0,0,""},
	[805306371] = {805306371,2,"随机地图",";;进入前三;季票勋章;",0,0,"Entrance_FastRandomMap_ui","Custroom_FastParty_Random",1,1,0,"",0,0,0,""},
	[805306372] = {805306372,2,"战斗岛","28人;1x1km;进入前三;季票勋章;",1,0,"Entrance_BattleIsland_ui","Custroom_FastParty_BattleLsland",1,1,0,"",0,0,0,""},
	[805306373] = {805306373,2,"彩虹岛","28人;1x1km;进入前三;季票勋章;",2,0,"Entrance_LaTale_ui","Custroom_FastParty_LaTale",1,1,0,"",0,0,0,""},
	[805306374] = {805306374,3,"随机地图",";;率先达到80淘汰;季票勋章;",0,0,"Entrance_TeamtRandomMap_ui","Custroom_TeamFighting_Random",2,1,0,"",0,0,0,""},
	[805306375] = {805306375,3,"竞技中心","16人;150x150m;率先达到80淘汰;季票勋章;",1,0,"Entrance_SportsCenter_ui","Custroom_TeamFighting_SportsCenter",2,1,0,"",0,0,0,""},
	[805306376] = {805306376,3,"5号广场","16人;150x150m;率先达到80淘汰;季票勋章;",2,0,"Entrance_Plaza5_ui","Custroom_TeamFighting_Plaza5",2,1,0,"",0,0,0,""},
	[805306377] = {805306377,3,"风车街道","16人;150x150m;率先达到80淘汰;季票勋章;",3,0,"Entrance_WindmillPlaza_ui","Custroom_TeamFighting_WindmillPlaza",2,1,0,"",0,0,0,""},
	[805306378] = {805306378,3,"温泉山庄","16人;150x150m;率先达到80淘汰;季票勋章;",4,0,"Entrance_SpringSpaHotel_ui","Custroom_TeamFighting_SpringSpaHotel",2,1,0,"",0,0,0,""},
	[805306379] = {805306379,3,"怒海争锋","16人;150x150m;率先达到80淘汰;季票勋章;",5,0,"Entrance_FierceBattle_ui","Custroom_TeamFighting_FierceBattle",2,1,0,"",0,0,0,""},
	[805306380] = {805306380,4,"随机地图","16人;150x150m;率先达到60淘汰;季票勋章;",0,0,"Entrance_TeamtRandomMap_ui","Custroom_SniperFight_Random",2,1,0,"",0,0,0,""},
	[805306381] = {805306381,4,"停水泳池","16人;150x150m;率先达到60淘汰;季票勋章;",1,0,"Entrance_Sniping_ui","Custroom_SniperFight_Sniping",2,1,0,"",0,0,0,""},
	[805306382] = {805306382,4,"停赛球场","16人;150x150m;率先达到60淘汰;季票勋章;",2,0,"Entrance_Sniping2_ui","Custroom_SniperFight_Sniping2",2,1,0,"",0,0,0,""},
	[805306383] = {805306383,4,"停电工坊","16人;150x150m;率先达到60淘汰;季票勋章;",3,0,"Entrance_Sniping3_ui","Custroom_SniperFight_Sniping3",2,1,0,"",0,0,0,""},
	[838860800] = {838860800,5,"奔跑吧！",";;多轮淘汰赛中获得前三;季票勋章;",0,0,"Entrance_Knockout_ui","Custroom_LimitedTime_Parkour_0",0,1,0,"",0,0,0,""},
	[939524096] = {939524096,5,"奔跑吧！肠肠！",";;多轮淘汰赛中获得前三;季票勋章;",15,0,"Entrance_Knockout_ui","LimitedTime_Parkour_0",2,0,0,"奔跑吧！肠肠！",0,4,0,""},
	[1006632960] = {1006632960,1,"原味派对-彩虹岛","100人;4x4km;进入前三;段位积分 季票勋章;",3,0,"Entrance_OriginalClassic_ui","LimitedTime_OriginalClassic",1,0,0,"原味派对-彩虹岛",1,4,1,""},
	[1006632961] = {1006632961,5,"狙击对决-停水泳池","16人;150x150m;率先达到60淘汰;季票勋章;",8,0,"Entrance_Sniping_ui","SniperFight_Sniping",2,0,0,"狙击对决-停水泳池",0,8,0,""},
	[1006632962] = {1006632962,5,"狙击对决-停赛球场","16人;150x150m;率先达到60淘汰;季票勋章;",9,0,"Entrance_Sniping2_ui","SniperFight_Sniping2",2,0,0,"狙击对决-停赛球场",0,8,0,""},
	[1006632963] = {1006632963,5,"狙击对决-停电工坊","16人;150x150m;率先达到60淘汰;季票勋章;",10,0,"Entrance_Sniping3_ui","SniperFight_Sniping3",2,0,0,"狙击对决-停电工坊",0,8,0,""},
}

local Keys = {1,436207616,570425344,570425345,603979776,603979777,671088640,671088641,671088642,704643072,704643073,704643074,704643076,704643077,704643079,704643080,704643081,704643082,704643083,704643084,704643088,704643089,704643090,704643091,704643092,704643094,704643095,704643096,704643097,704643098,805306368,805306369,805306370,805306371,805306372,805306373,805306374,805306375,805306376,805306377,805306378,805306379,805306380,805306381,805306382,805306383,838860800,939524096,1006632960,1006632961,1006632962,1006632963,}



local GameSelectionTableBase = {

    -- 记录数
	COUNT = 53,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	show_mode = 2,
	enter_description = 3,
	show_description = 4,
	pos = 5,
	is_red = 6,
	resources = 7,
	sign = 8,
	show_group_mode = 9,
	is_custom_room_use = 10,
	sort_number = 11,
	fast_description = 12,
	client_save = 13,
	default_group_mode = 14,
	change_group_mode = 15,
	hot_resources = 16,

    -- 标识常量
	["Entrance_8V8Sniper"] = "Entrance_8V8Sniper",
	["LimitedTime_MachineLaTale"] = "LimitedTime_MachineLaTale",
	["Custroom_RainbowFight"] = "Custroom_RainbowFight",
	["Custroom_Battle2V2"] = "Custroom_Battle2V2",
	["Custroom_CircusTroupe"] = "Custroom_CircusTroupe",
	["LimitedTime_IDCard"] = "LimitedTime_IDCard",
	["LimitedTime_Battle1V1"] = "LimitedTime_Battle1V1",
	["LimitedTime_Battle2V2"] = "LimitedTime_Battle2V2",
	["LimitedTime_Battle4V4"] = "LimitedTime_Battle4V4",
	["Classic_Random"] = "Classic_Random",
	["Classic_BattleLsland"] = "Classic_BattleLsland",
	["Classic_LaTale"] = "Classic_LaTale",
	["FastParty_BattleLsland"] = "FastParty_BattleLsland",
	["FastParty_LaTale"] = "FastParty_LaTale",
	["TeamFighting_SportsCenter"] = "TeamFighting_SportsCenter",
	["TeamFighting_Plaza5"] = "TeamFighting_Plaza5",
	["TeamFighting_WindmillPlaza"] = "TeamFighting_WindmillPlaza",
	["TeamFighting_SpringSpaHotel"] = "TeamFighting_SpringSpaHotel",
	["TeamFighting_FierceBattle"] = "TeamFighting_FierceBattle",
	["SniperFight_Random"] = "SniperFight_Random",
	["LimitedTime_CircusTroupe"] = "LimitedTime_CircusTroupe",
	["LimitedTime_FirepowerDuel"] = "LimitedTime_FirepowerDuel",
	["LimitedTime_GrenadeDuel"] = "LimitedTime_GrenadeDuel",
	["LimitedTime_ShotgunDuel"] = "LimitedTime_ShotgunDuel",
	["LimitedTime_LegionWarfare"] = "LimitedTime_LegionWarfare",
	["LimitedTime_Machine"] = "LimitedTime_Machine",
	["Train_PrivateTraining"] = "Train_PrivateTraining",
	["Train_SausageClub"] = "Train_SausageClub",
	["Train_CustomRoom"] = "Train_CustomRoom",
	["LimitedTime_RainbowFight"] = "LimitedTime_RainbowFight",
	["Custroom_Classic_Random"] = "Custroom_Classic_Random",
	["Custroom_Classic_BattleLsland"] = "Custroom_Classic_BattleLsland",
	["Custroom_Classic_LaTale"] = "Custroom_Classic_LaTale",
	["Custroom_FastParty_Random"] = "Custroom_FastParty_Random",
	["Custroom_FastParty_BattleLsland"] = "Custroom_FastParty_BattleLsland",
	["Custroom_FastParty_LaTale"] = "Custroom_FastParty_LaTale",
	["Custroom_TeamFighting_Random"] = "Custroom_TeamFighting_Random",
	["Custroom_TeamFighting_SportsCenter"] = "Custroom_TeamFighting_SportsCenter",
	["Custroom_TeamFighting_Plaza5"] = "Custroom_TeamFighting_Plaza5",
	["Custroom_TeamFighting_WindmillPlaza"] = "Custroom_TeamFighting_WindmillPlaza",
	["Custroom_TeamFighting_SpringSpaHotel"] = "Custroom_TeamFighting_SpringSpaHotel",
	["Custroom_TeamFighting_FierceBattle"] = "Custroom_TeamFighting_FierceBattle",
	["Custroom_SniperFight_Random"] = "Custroom_SniperFight_Random",
	["Custroom_SniperFight_Sniping"] = "Custroom_SniperFight_Sniping",
	["Custroom_SniperFight_Sniping2"] = "Custroom_SniperFight_Sniping2",
	["Custroom_SniperFight_Sniping3"] = "Custroom_SniperFight_Sniping3",
	["Custroom_LimitedTime_Parkour_0"] = "Custroom_LimitedTime_Parkour_0",
	["LimitedTime_Parkour_0"] = "LimitedTime_Parkour_0",
	["LimitedTime_OriginalClassic"] = "LimitedTime_OriginalClassic",
	["SniperFight_Sniping"] = "SniperFight_Sniping",
	["SniperFight_Sniping2"] = "SniperFight_Sniping2",
	["SniperFight_Sniping3"] = "SniperFight_Sniping3",
}

local languageColumns = {3, 4, 12}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return GameSelectionTableBase