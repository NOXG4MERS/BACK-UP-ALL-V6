local List0 = {
}

local Keys = {}



local GunDeriveTableBase = {

    -- 记录数
	COUNT = 1,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	origin_gun_item_id = 2,
	derive_gun_item_id = 3,

    -- 标识常量
}



return GunDeriveTableBase