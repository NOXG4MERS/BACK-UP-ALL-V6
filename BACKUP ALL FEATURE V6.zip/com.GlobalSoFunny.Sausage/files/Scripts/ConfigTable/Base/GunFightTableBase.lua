local List0 = {
	[1] = {1,1,2700,0,60},
	[2] = {2,2,3700,1,20},
	[738197504] = {738197504,3,4700,1,20},
	[738197505] = {738197505,4,100000,1,20},
}

local Keys = {1,2,738197504,738197505,}



local GunFightTableBase = {

    -- 记录数
	COUNT = 5,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	level = 2,
	max_score = 3,
	is_down = 4,
	waiting_time = 5,

    -- 标识常量
}



return GunFightTableBase