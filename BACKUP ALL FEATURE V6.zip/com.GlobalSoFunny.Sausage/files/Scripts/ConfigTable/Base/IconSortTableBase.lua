local List0 = {
	[1] = {1,363,10,10,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait10.png"},
	[2] = {2,364,11,15,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait11.png"},
	[3] = {3,365,12,20,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait12.png"},
	[4] = {4,366,13,25,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait13.png"},
	[5] = {5,367,14,30,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait14.png"},
	[6] = {6,368,15,35,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait15.png"},
	[7] = {7,294,106,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait100.png"},
	[8] = {8,291,107,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait101.png"},
	[9] = {9,357,108,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait102.png"},
	[10] = {10,358,109,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait103.png"},
	[11] = {11,359,110,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait104.png"},
	[12] = {12,360,111,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait105.png"},
	[13] = {13,361,112,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait106.png"},
	[14] = {14,362,113,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait107.png"},
	[33554432] = {33554432,33554433,1,1,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait1.png"},
	[33554433] = {33554433,33554434,8,8,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait2.png"},
	[33554434] = {33554434,33554435,5,5,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait3.png"},
	[33554435] = {33554435,33554436,9,9,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait4.png"},
	[33554436] = {33554436,33554437,6,6,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait5.png"},
	[33554437] = {33554437,33554438,4,4,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait6.png"},
	[33554438] = {33554438,33554439,3,3,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait7.png"},
	[33554439] = {33554439,33554440,7,7,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait8.png"},
	[33554440] = {33554440,33554441,2,2,1,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait9.png"},
	[234881024] = {234881024,234881264,114,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait112.png"},
	[234881025] = {234881025,234881263,115,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait113.png"},
	[234881026] = {234881026,234881262,116,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait114.png"},
	[234881027] = {234881027,234881261,117,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait115.png"},
	[234881028] = {234881028,234881265,118,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait116.png"},
	[234881029] = {234881029,234881266,119,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait117.png"},
	[335544320] = {335544320,663,100,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait111.png"},
	[335544321] = {335544321,662,101,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait110.png"},
	[335544322] = {335544322,661,102,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait109.png"},
	[335544323] = {335544323,660,103,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait108.png"},
	[335544324] = {335544324,658,104,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait16.png"},
	[335544325] = {335544325,659,105,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait17.png"},
	[335544326] = {335544326,738197677,152,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait157.png"},
	[335544327] = {335544327,738197678,153,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait156.png"},
	[335544328] = {335544328,738197679,154,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait153.png"},
	[335544329] = {335544329,738197680,155,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait155.png"},
	[335544330] = {335544330,738197681,156,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait154.png"},
	[335544331] = {335544331,738197682,157,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait158.png"},
	[335544332] = {335544332,738197683,158,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait159.png"},
	[335544333] = {335544333,2080374870,159,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait152.png"},
	[738197504] = {738197504,603979891,124,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait118.png"},
	[738197505] = {738197505,603979890,125,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait119.png"},
	[738197506] = {738197506,603979888,121,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait120.png"},
	[738197507] = {738197507,603979887,122,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait121.png"},
	[738197508] = {738197508,603979886,123,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait122.png"},
	[738197509] = {738197509,603979889,120,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait124.png"},
	[738197510] = {738197510,570425402,99,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait125.png"},
	[738197511] = {738197511,469762141,128,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait126.png"},
	[738197512] = {738197512,469762140,127,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait127.png"},
	[738197513] = {738197513,469762142,129,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait128.png"},
	[738197514] = {738197514,469762143,126,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait129.png"},
	[738197515] = {738197515,469762145,130,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait130.png"},
	[738197516] = {738197516,469762144,131,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait131.png"},
	[738197517] = {738197517,503316579,137,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait132.png"},
	[738197518] = {738197518,503316572,136,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait133.png"},
	[738197519] = {738197519,503316537,134,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait134.png"},
	[738197520] = {738197520,503316551,133,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait135.png"},
	[738197521] = {738197521,503316523,135,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait136.png"},
	[738197522] = {738197522,503316563,132,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait137.png"},
	[738197523] = {738197523,872415334,142,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait138.png"},
	[738197524] = {738197524,872415335,138,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait139.png"},
	[738197525] = {738197525,872415336,141,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait140.png"},
	[738197526] = {738197526,872415337,140,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait141.png"},
	[738197527] = {738197527,872415338,139,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait142.png"},
	[738197528] = {738197528,872415339,143,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait143.png"},
	[738197529] = {738197529,1040187503,151,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait144.png"},
	[738197530] = {738197530,1040187502,150,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait145.png"},
	[738197531] = {738197531,1040187498,147,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait146.png"},
	[738197532] = {738197532,1040187500,146,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait147.png"},
	[738197533] = {738197533,1040187499,145,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait148.png"},
	[738197534] = {738197534,1040187501,144,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait149.png"},
	[738197535] = {738197535,1040187497,148,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait150.png"},
	[738197536] = {738197536,1040187518,149,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait151.png"},
	[905969664] = {905969664,905969762,151,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait151.png"},
	[905969665] = {905969665,905969767,150,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait151.png"},
	[905969666] = {905969666,905969763,152,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait151.png"},
	[905969667] = {905969667,905969764,153,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait151.png"},
	[905969668] = {905969668,905969765,154,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait151.png"},
	[905969669] = {905969669,905969766,155,0,0,"https://n17x06.xdcdn.net/sausage_avatar/v3/portrait151.png"},
}

local Keys = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,33554432,33554433,33554434,33554435,33554436,33554437,33554438,33554439,33554440,234881024,234881025,234881026,234881027,234881028,234881029,335544320,335544321,335544322,335544323,335544324,335544325,335544326,335544327,335544328,335544329,335544330,335544331,335544332,335544333,738197504,738197505,738197506,738197507,738197508,738197509,738197510,738197511,738197512,738197513,738197514,738197515,738197516,738197517,738197518,738197519,738197520,738197521,738197522,738197523,738197524,738197525,738197526,738197527,738197528,738197529,738197530,738197531,738197532,738197533,738197534,738197535,738197536,905969664,905969665,905969666,905969667,905969668,905969669,}



local IconSortTableBase = {

    -- 记录数
	COUNT = 83,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	item_id = 2,
	item_sort = 3,
	level = 4,
	is_level_unlock = 5,
	avatar_url = 6,

    -- 标识常量
}



return IconSortTableBase