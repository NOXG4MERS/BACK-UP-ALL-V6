local List0 = {
	[1442840576] = {1442840576,1442840577,1},
	[1442840577] = {1442840577,1442840578,3},
	[1442840578] = {1442840578,1442840579,2},
	[1442840579] = {1442840579,1442840580,4},
	[1442840580] = {1442840580,1442840581,0},
}

local Keys = {1442840576,1442840577,1442840578,1442840579,1442840580,}



local ItemFriendSpecialEffectTableBase = {

    -- 记录数
	COUNT = 6,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	item_id = 2,
	relation_type = 3,

    -- 标识常量
}



return ItemFriendSpecialEffectTableBase