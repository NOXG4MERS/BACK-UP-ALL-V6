local List0 = {
	[1] = {1,"白","White","普通"},
	[2] = {2,"绿","Green","高级"},
	[3] = {3,"蓝","Blue","稀有"},
	[4] = {4,"紫","Purple","史诗"},
	[5] = {5,"橙","Orange","传说"},
	[6] = {6,"红","Red","未使用"},
	[234881024] = {234881024,"无品质","NonQuality","无品质"},
}

local Keys = {1,2,3,4,5,6,234881024,}



local ItemQualityTableBase = {

    -- 记录数
	COUNT = 8,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	alias_name = 4,

    -- 标识常量
	["White"] = "White",
	["Green"] = "Green",
	["Blue"] = "Blue",
	["Purple"] = "Purple",
	["Orange"] = "Orange",
	["Red"] = "Red",
	["NonQuality"] = "NonQuality",
}

local languageColumns = {2, 4}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return ItemQualityTableBase