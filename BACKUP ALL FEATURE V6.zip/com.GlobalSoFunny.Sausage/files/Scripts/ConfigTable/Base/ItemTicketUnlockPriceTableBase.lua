local List0 = {
	[1] = {1,1,1,12},
	[2] = {2,1,2,25},
	[3] = {3,1,3,120},
	[4] = {4,1,4,400},
	[5] = {5,1,5,1200},
}

local Keys = {1,2,3,4,5,}



local ItemTicketUnlockPriceTableBase = {

    -- 记录数
	COUNT = 6,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	ticket_unlock_type = 2,
	quality_id = 3,
	need_ticket = 4,

    -- 标识常量
}



return ItemTicketUnlockPriceTableBase