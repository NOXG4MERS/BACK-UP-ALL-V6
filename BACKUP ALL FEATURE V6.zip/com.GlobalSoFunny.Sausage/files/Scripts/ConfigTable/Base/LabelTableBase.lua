local List0 = {
	[402653184] = {402653184,"2020战报开启玩家","YearlyReport",1,"2020战报开启玩家"},
	[503316480] = {503316480,"非R","FeiR",2,"非R"},
	[503316481] = {503316481,"小R","XiaoR",2,"小R"},
	[503316482] = {503316482,"中R","ZhongR",2,"中R"},
	[503316483] = {503316483,"大R","DaR",2,"大R"},
	[637534208] = {637534208,"苹果推荐回归玩家","IOSTuiJianHuiGui",3,"苹果推荐活动回归玩家"},
	[905969664] = {905969664,"常驻回归玩家","BackActivity",3,"常驻回归玩家"},
}

local Keys = {402653184,503316480,503316481,503316482,503316483,637534208,905969664,}



local LabelTableBase = {

    -- 记录数
	COUNT = 8,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	label_type = 4,
	discription = 5,

    -- 标识常量
	["YearlyReport"] = "YearlyReport",
	["FeiR"] = "FeiR",
	["XiaoR"] = "XiaoR",
	["ZhongR"] = "ZhongR",
	["DaR"] = "DaR",
	["IOSTuiJianHuiGui"] = "IOSTuiJianHuiGui",
	["BackActivity"] = "BackActivity",
}



return LabelTableBase