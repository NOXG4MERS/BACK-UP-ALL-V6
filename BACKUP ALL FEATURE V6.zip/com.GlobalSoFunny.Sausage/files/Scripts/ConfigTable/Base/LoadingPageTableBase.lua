local List0 = {
	[335544320] = {335544320,"杂技球","LevelA15",1556467200,1557071940,2},
	[335544321] = {335544321,"信号枪","LevelA16",1557072000,1557676740,2},
	[335544322] = {335544322,"杂技球","LevelA15",1557925200,1557926400,1},
	[335544323] = {335544323,"信号枪","LevelA16",1557926400,1557927600,1},
}

local Keys = {335544320,335544321,335544322,335544323,}



local LoadingPageTableBase = {

    -- 记录数
	COUNT = 5,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	title = 2,
	sign = 3,
	start_time = 4,
	end_time = 5,
	server_type = 6,

    -- 标识常量
	["LevelA15"] = "LevelA15",
	["LevelA16"] = "LevelA16",
	["LevelA15"] = "LevelA15",
	["LevelA16"] = "LevelA16",
}



return LoadingPageTableBase