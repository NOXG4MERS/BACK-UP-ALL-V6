local List0 = {
	[1] = {1,"RegisterTimeGE","注册时间>=","填入大于等于的时间戳"},
	[2] = {2,"RegisterTimeLE","注册时间<=","填入小于等于的时间戳"},
	[3] = {3,"TotalPayGE","付费额度>=","填入大于等于的付费额度"},
	[4] = {4,"TotalPayLE","付费额度<=","填入小于等于的付费额度"},
	[5] = {5,"ItemEQ","拥有物品","填入需要拥有的物品ID"},
	[6] = {6,"TrafficPermitLvGE","季票等级>=","填入大于等于的季票等级"},
	[7] = {7,"TrafficPermitLvLE","季票等级<=","填入小于等于的季票等级"},
	[8] = {8,"RandomGet","获得概率百分比","填入获得邮件的概率"},
}

local Keys = {1,2,3,4,5,6,7,8,}



local MailRuleLogicTableBase = {

    -- 记录数
	COUNT = 9,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	sign = 2,
	name = 3,
	describe = 4,

    -- 标识常量
	["RegisterTimeGE"] = "RegisterTimeGE",
	["RegisterTimeLE"] = "RegisterTimeLE",
	["TotalPayGE"] = "TotalPayGE",
	["TotalPayLE"] = "TotalPayLE",
	["ItemEQ"] = "ItemEQ",
	["TrafficPermitLvGE"] = "TrafficPermitLvGE",
	["TrafficPermitLvLE"] = "TrafficPermitLvLE",
	["RandomGet"] = "RandomGet",
}



return MailRuleLogicTableBase