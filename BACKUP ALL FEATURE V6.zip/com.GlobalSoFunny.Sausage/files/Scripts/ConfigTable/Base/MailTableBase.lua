local List0 = {
	[1] = {1,1,"系统","System","系统","Desc 描述","{Desc}"},
	[2] = {2,1,"系统","Prosecutor","举报反馈","Time 提交的时间\r\nNick 玩家的昵称\r\nUid  玩家的UID","收到您在{Time}提交对玩家{Nick}（ID:{Uid}）的举报，我们已经警告该玩家，并将对其行为进行严密监控。一旦举报核实，我们将对该玩家进行严厉处罚。感谢您对健康、良好的游戏环境做出的贡献!我们对破坏游戏环境的行为决不姑息！"},
	[3] = {3,1,"系统","Defendant","被举报反馈","Time 被举报时间","由于你在{Time}的对局中收到多名玩家的举报"},
	[4] = {4,1,"系统","ReportFreezeID","处罚反馈","Time 提交的时间\r\nNick 玩家的昵称\r\nUid  玩家的UID\r\nBehavior 违规行为","经过检测判定，您在{Time}的对局中举报的用户<color=#ff911a>{Nick}</color>（ID:{Uid}）确有<color=#cf3c3c>{Behavior}</color>行为，现已进行<color=#cf3c3c>封号处理</color>。我们会加倍努力对此类玩家进行更快速的处理！感谢您对健康、良好的游戏环境做出的贡献!我们对破坏游戏环境的行为决不姑息！"},
	[5] = {5,1,"系统","Gold2Donut","货币变化邮件通知","Gold 金币\r\nDonut 甜甜圈","由于补给箱商人最近喜爱甜食，所以决定不再接受金币，改收甜甜圈，请各位岛民知悉。您的{Gold}个金币转化成{Donut}个甜甜圈，请查收。"},
	[6] = {6,1,"系统","StartShutup","开始禁言","Period 周期\r\nEndTime 结束时间","由于您违规，现已被系统禁言{Period}分钟惩罚，禁言时间至{EndTime}，如需申诉，可在大厅点击客服进行申诉。"},
	[7] = {7,1,"系统","EndShutup","结束禁言","","系统对于您的禁言惩罚已结束，请在游戏中注意文明用语。"},
	[8] = {8,1,"系统","Rename","强制改名","","由于您的名称违规，系统已自动将您的名字进行修改。"},
	[9] = {9,1,"系统","RenameCard","改名卡补偿","","您等级到达10级啦，获得了一张改名卡。"},
	[10] = {10,1,"系统","CheatingFlowWarning","坐挂车警告","Nick 玩家的昵称\r\nUid  玩家的UID","由于您在近期存在主动与作弊玩家{Nick}（ID：{Uid}）组队的游戏行为，特此警告，如果后续仍出现该行为，将会受到严厉处罚"},
	[134217728] = {134217728,1,"系统","MoNiQiMail1","举报反馈","Time 提交的时间\r\nNick 玩家的昵称\r\nUid  玩家的UID","经过系统检测判定，您在{Time}的对局中举报的用户{Nick}（ID:{Uid}）无违规行为，后续我们将继续对该玩家进行监测，祝您游戏愉快。"},
	[134217729] = {134217729,1,"系统","MoNiQiMail2","处罚反馈","Time 提交的时间\r\nNick 玩家的昵称\r\nUid  玩家的UID","经过系统检测判定，您在{Time}的对局中举报的用户{Nick}（ID:{Uid}）使用模拟器进行游戏，系统会立即对该玩家后续的匹配进行优化。影响了您的游戏体验，深表抱歉。感谢您对健康、良好的游戏环境做出的贡献!"},
	[234881024] = {234881024,1,"系统","SystemTask","系统补偿","EXP 金币\r\nDonut 甜甜圈","任务系统进行简化，完成游戏活跃行为可更快获得奖励，可前往补给箱功能查看详情。未完成任务的玩家，将获得满额任务奖励补偿。您获得了经验值{EXP}和甜甜圈{Donut}。"},
	[234881025] = {234881025,1,"系统","Donut2DonutCrate","甜甜圈变化邮件通知","Donut 甜甜圈\r\nCrate 基础补给箱","亲爱的各位岛民:\r\n\r\n由于当前版本取消了甜甜圈货币，因此游戏中的【甜甜圈补给箱】已更名为【基础补给箱】。\r\n\r\n您目前持有的{Donut}个【甜甜圈】已转化为{Crate}个【基础补给箱】，请查收。\r\n\r\n注：领取后可在“仓库”-“道具”界面中使用。"},
	[234881026] = {234881026,1,"系统","DiamondReturn","糖果返还邮件通知","Diamond 糖果","新的赛季已经开启啦，原有的会员特权将合并入季票系统的黄金季票中。您购买会员消耗的{Diamond}个糖果已返还，可用于购买黄金季票，请查收。"},
	[234881027] = {234881027,1,"系统","Donut2DonutCrate2","甜甜圈补给箱变化邮件通知","Donut 甜甜圈\r\nGoldCrate 甜甜圈补给箱\r\nCrate 基础补给箱","亲爱的各位岛民:\r\n\r\n由于当前版本取消了甜甜圈货币，因此游戏中的【甜甜圈补给箱】已更名为【基础补给箱】。\r\n\r\n您目前持有的{GoldCrate}个【甜甜圈补给箱】以及剩余的{Donut}个【甜甜圈】已转化为{Crate}个【基础补给箱】，请查收。\r\n\r\n注：领取后可在“仓库”-“道具”界面中使用。"},
	[335544320] = {335544320,1,"系统","ChatStartShutup","开始禁言","EndTime 结束时间","由于您在战场内或世界聊天中进行违规言论，目前聊天系统已被禁止使用，时间至{EndTime}，如需申诉，可在大厅点击客服进行申诉"},
	[335544321] = {335544321,1,"系统","ChatEndShutup","结束禁言","","系统对于您的禁言惩罚已结束，请在游戏中注意文明用语。"},
	[335544322] = {335544322,1,"系统","ZhaoHuiHuoDong","回归礼包","","亲爱的香肠岛民：\r\n欢迎回来，等你好久啦！\r\n为了庆祝您的回归，我们精心准备了回归大礼包！除了能带来欧气的钻石糖，还有最新的恶作剧道具！还请岛民查收。\r\n祝岛民们在香肠岛玩的开心。"},
	[335544323] = {335544323,1,"系统","MoNiQiJianCe","系统提示","PunishPeriod 处罚时间","亲爱的香肠岛民：\r\n\r\n由于您被检测到使用模拟器或外设进行游戏，为了游戏的公平性考虑，我们会将所有使用模拟器、外设进行游戏的用户进行隔离匹配，匹配时间会更长。\r\n\r\n本次游戏隔离匹配时间为{PunishPeriod}小时，在此期间我们将持续检测，若{PunishPeriod}小时监察期内您没有使用模拟器进行游戏，将会解除上述匹配限制。\r\n\r\n我们真诚建议岛民使用手机或平板设备进行游戏，感谢您的理解与支持。"},
	[369098752] = {369098752,1,"系统","ADmail","补给箱钥匙转换","DiamondCandy  当前缤纷补给箱钥匙数量\r\nDiamondCrate  转换后缤纷补给箱钥匙数量","亲爱的各位岛民:\r\n\r\n由于当前版本调整了补给箱钥匙与箱子之间的兑换比例，将原有的3个【彩虹补给箱钥匙】兑换1个【彩虹补给箱】，调整为30个【彩虹补给箱钥匙】兑换1个【彩虹补给箱】；6个【缤纷补给箱钥匙】兑换1个【缤纷补给箱】调整为60个【缤纷补给箱钥匙】兑换1个【缤纷补给箱】。\r\n\r\n \r\n因此，已将您目前持有的{DiamondCandy}个【缤纷补给箱钥匙】转化为{DiamondCrate}个【缤纷补给箱钥匙】，请您查收。\r\n\r\n同时，我们也调整了活跃补给箱的随机产出内容，调整后的随机产出如下：\r\n\r\n【季票勋章*15】、【季票勋章*10】、【季票勋章*5】；\r\n\r\n【缤纷补给箱钥匙*12】、【缤纷补给箱钥匙*8】、【缤纷补给箱钥匙*4】；\r\n\r\n【彩虹补给箱钥匙*12】、【彩虹补给箱钥匙*8】、【彩虹补给箱钥匙*4】。\r\n\r\n感谢大家的理解与支持！"},
	[369098753] = {369098753,1,"系统","ADmail2","补给箱钥匙转换","RainbowKey  当前彩虹补给箱钥匙数量\r\nRainbowCrate 转换后彩虹补给箱钥匙数量","亲爱的各位岛民:\r\n\r\n由于当前版本调整了补给箱钥匙与箱子之间的兑换比例，将原有的3个【彩虹补给箱钥匙】兑换1个【彩虹补给箱】，调整为30个【彩虹补给箱钥匙】兑换1个【彩虹补给箱】；6个【缤纷补给箱钥匙】兑换1个【缤纷补给箱】调整为60个【缤纷补给箱钥匙】兑换1个【缤纷补给箱】。\r\n\r\n \r\n因此，已将您目前持有的{RainbowKey}个【彩虹补给箱钥匙】转化为{RainbowCrate}个【彩虹补给箱钥匙】，请您查收。\r\n\r\n同时，我们也调整了活跃补给箱的随机产出内容，调整后的随机产出如下：\r\n\r\n【季票勋章*15】、【季票勋章*10】、【季票勋章*5】；\r\n\r\n【缤纷补给箱钥匙*12】、【缤纷补给箱钥匙*8】、【缤纷补给箱钥匙*4】；\r\n\r\n【彩虹补给箱钥匙*12】、【彩虹补给箱钥匙*8】、【彩虹补给箱钥匙*4】。\r\n\r\n感谢大家的理解与支持！"},
	[369098754] = {369098754,1,"系统","ADmail3","补给箱钥匙转换","DiamondCandy  当前缤纷补给箱钥匙数量\r\nDiamondCrate  转换后缤纷补给箱钥匙数量\r\nRainbowKey  当前彩虹补给箱钥匙数量\r\nRainbowCrate 转换后彩虹补给箱钥匙数量","亲爱的各位岛民:\r\n\r\n由于当前版本调整了补给箱钥匙与箱子之间的兑换比例，将原有的3个【彩虹补给箱钥匙】兑换1个【彩虹补给箱】，调整为30个【彩虹补给箱钥匙】兑换1个【彩虹补给箱】；6个【缤纷补给箱钥匙】兑换1个【缤纷补给箱】调整为60个【缤纷补给箱钥匙】兑换1个【缤纷补给箱】。\r\n\r\n\r\n因此，已将您目前持有的{RainbowKey}个【彩虹补给箱钥匙】转化为{RainbowCrate}个【彩虹补给箱钥匙】，{DiamondCandy}个【缤纷补给箱钥匙】转化为{DiamondCrate}个【缤纷补给箱钥匙】，请您查收。\r\n\r\n同时，我们也调整了活跃补给箱的随机产出内容，调整后的随机产出如下：\r\n\r\n【季票勋章*15】、【季票勋章*10】、【季票勋章*5】；\r\n\r\n【缤纷补给箱钥匙*12】、【缤纷补给箱钥匙*8】、【缤纷补给箱钥匙*4】；\r\n\r\n【彩虹补给箱钥匙*12】、【彩虹补给箱钥匙*8】、【彩虹补给箱钥匙*4】。\r\n\r\n\r\n感谢大家的理解与支持！"},
	[369098755] = {369098755,2,"赠礼","Gift","好友赠礼","TargetNick  目标昵称\r\nNotice  留言\r\nSourceNick 源昵称\r\nSourceUid 源uid","亲爱的 {TargetNick}:\r\n\r\n          {Notice}"},
	[369098756] = {369098756,1,"系统","GiftFail","赠礼失败","TargetNick  目标昵称","由于{TargetNick}已获得黄金季票，您送给TA的黄金季票未开通成功，请联系心动客服处理。"},
	[436207616] = {436207616,1,"系统","CheatingFlowCaution","坐挂车提示","Nick 玩家的昵称\r\nUid  玩家的UID","经系统判定，您近期主动组队的玩家{Nick}（ID：{Uid}）为作弊玩家。若您遇到作弊队友，请积极举报并中断对局，以免对您造成不利影响，让我们一起让香肠派对变得更好~"},
	[436207617] = {436207617,1,"系统","ExteriorDevice","外设反馈","","系统检测到您正在使用外设，影响游戏环境公平。特此提醒，如果后续仍出现该行为，将会收到处罚。"},
	[436207618] = {436207618,1,"系统","PunishResponse","处罚反馈","Time 对局结束的时间\r\nNick 作弊玩家的昵称\r\nUid  作弊玩家的Uid\r\nMode 对局模式","亲爱的岛民：\r\n\r\n您在{Time}的{Mode}中被{Nick}（ID：{Uid}）淘汰，经系统核实，该玩家为作弊玩家。\r\n现已对该玩家实行<color=#EEC712>封号处罚</color>，我们对您遇到的不公平体验深感抱歉~\r\n针对作弊玩家，我们一直抱着严打严惩，绝不姑息的态度。\r\n若您在游戏内遇到作弊玩家，请积极举报，让我们一起让香肠派对变得更好~"},
	[436207619] = {436207619,1,"系统","AbnormalRide","恶意组队警告","","由于您在近期存在恶意组队行为，破坏游戏环境公平，特此警告：如果后续仍出现该行为，将会收到严厉处罚。"},
	[436207620] = {436207620,1,"系统","StartForbidRanking","禁榜处罚","EndTime 结束时间","由于检测到您在近期有违规行为，破坏游戏环境，现已无法参与地区、全服范围的排行榜。\r\n处罚结束时间：{EndTime}\r\n如需申诉，可在大厅点击客服进行申诉。"},
	[436207621] = {436207621,1,"系统","EndForbidRanking","禁榜处罚结束","","系统对您的禁榜处罚已结束，现在您可以正常参与排行榜，请规范游戏行为。"},
	[1006632960] = {1006632960,1,"系统","OfficialCertificationGet","获得官方认证","OfficialName  认证称号","亲爱的岛民：\r\n\r\n您已获得{OfficialName}官方认证。"},
	[1006632961] = {1006632961,1,"系统","OfficialCertificationLose","失去官方认证","OfficialName  认证称号","亲爱的岛民：\r\n\r\n您已失去{OfficialName}官方认证。"},
	[1207959552] = {1207959552,1,"系统","ReturnTheRoomCard","返还房间卡","Nick  目标昵称","亲爱的 {Nick}：\r\n     自定义房间莫名其妙的关闭了，你站在房间门口非常愤怒，突然一阵大风刮来，一张卡片掉到你的手中，你仔细一看，居然是一张自定义房间卡！"},
	[1275068416] = {1275068416,1,"系统","MaliciousCarry","恶意托号警告","","由于你近期存在主动将作弊玩家带入高阶对局的行为，特此警告，如果后续仍出现该行为，将会受到严厉处罚。"},
	[1275068417] = {1275068417,1,"系统","ClearSoreResponse","清除段位分提示","Behavior 违规行为\r\nScore 段位分","由于您在近期存在{Behavior}行为，破坏游戏坏境公平。现清除{Score}段位分，以做惩罚，请规范游戏行为。"},
	[1275068418] = {1275068418,1,"系统","ContinousCliker","连点器提示","","系统检测到您正在使用连点器，影响游戏环境公平。特此提醒，如果后续仍出现该行为，将会受到处罚。"},
}

local Keys = {1,2,3,4,5,6,7,8,9,10,134217728,134217729,234881024,234881025,234881026,234881027,335544320,335544321,335544322,335544323,369098752,369098753,369098754,369098755,369098756,436207616,436207617,436207618,436207619,436207620,436207621,1006632960,1006632961,1207959552,1275068416,1275068417,1275068418,}



local MailTableBase = {

    -- 记录数
	COUNT = 38,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	mail_type = 2,
	sender = 3,
	sign = 4,
	title = 5,
	params = 6,
	content = 7,

    -- 标识常量
	["System"] = "System",
	["Prosecutor"] = "Prosecutor",
	["Defendant"] = "Defendant",
	["ReportFreezeID"] = "ReportFreezeID",
	["Gold2Donut"] = "Gold2Donut",
	["StartShutup"] = "StartShutup",
	["EndShutup"] = "EndShutup",
	["Rename"] = "Rename",
	["RenameCard"] = "RenameCard",
	["CheatingFlowWarning"] = "CheatingFlowWarning",
	["MoNiQiMail1"] = "MoNiQiMail1",
	["MoNiQiMail2"] = "MoNiQiMail2",
	["SystemTask"] = "SystemTask",
	["Donut2DonutCrate"] = "Donut2DonutCrate",
	["DiamondReturn"] = "DiamondReturn",
	["Donut2DonutCrate2"] = "Donut2DonutCrate2",
	["ChatStartShutup"] = "ChatStartShutup",
	["ChatEndShutup"] = "ChatEndShutup",
	["ZhaoHuiHuoDong"] = "ZhaoHuiHuoDong",
	["MoNiQiJianCe"] = "MoNiQiJianCe",
	["ADmail"] = "ADmail",
	["ADmail2"] = "ADmail2",
	["ADmail3"] = "ADmail3",
	["Gift"] = "Gift",
	["GiftFail"] = "GiftFail",
	["CheatingFlowCaution"] = "CheatingFlowCaution",
	["ExteriorDevice"] = "ExteriorDevice",
	["PunishResponse"] = "PunishResponse",
	["AbnormalRide"] = "AbnormalRide",
	["StartForbidRanking"] = "StartForbidRanking",
	["EndForbidRanking"] = "EndForbidRanking",
	["OfficialCertificationGet"] = "OfficialCertificationGet",
	["OfficialCertificationLose"] = "OfficialCertificationLose",
	["ReturnTheRoomCard"] = "ReturnTheRoomCard",
	["MaliciousCarry"] = "MaliciousCarry",
	["ClearSoreResponse"] = "ClearSoreResponse",
	["ContinousCliker"] = "ContinousCliker",
}

local languageColumns = {3, 5, 7}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return MailTableBase