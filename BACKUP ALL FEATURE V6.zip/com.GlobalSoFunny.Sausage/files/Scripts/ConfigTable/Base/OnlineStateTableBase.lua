local List0 = {
	[1] = {1,"Offline","玩家不在线",0,-1},
	[2] = {2,"Online","玩家在线",1,-1},
	[3] = {3,"PKInviter","pk邀请者",2,10},
	[4] = {4,"PKInvitee","pk被邀请者",3,10},
	[5] = {5,"PKMatch","处于pk匹配中",4,5},
	[6] = {6,"Group","处于队伍中",5,-1},
	[7] = {7,"Match","处于通常游戏匹配中",6,1200},
	[8] = {8,"Battle","处于战斗中",7,1800},
	[9] = {9,"SendBattleInfo","发送战斗信息",8,120},
	[10] = {10,"RPCMatch","RPC匹配状态可以转为Matching",9,10},
	[671088640] = {671088640,"CustomRoom","自定义房间",10,3600},
}

local Keys = {1,2,3,4,5,6,7,8,9,10,671088640,}



local OnlineStateTableBase = {

    -- 记录数
	COUNT = 12,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	sign = 2,
	description = 3,
	state_value = 4,
	timeout = 5,

    -- 标识常量
	["Offline"] = "Offline",
	["Online"] = "Online",
	["PKInviter"] = "PKInviter",
	["PKInvitee"] = "PKInvitee",
	["PKMatch"] = "PKMatch",
	["Group"] = "Group",
	["Match"] = "Match",
	["Battle"] = "Battle",
	["SendBattleInfo"] = "SendBattleInfo",
	["RPCMatch"] = "RPCMatch",
	["CustomRoom"] = "CustomRoom",
}



return OnlineStateTableBase