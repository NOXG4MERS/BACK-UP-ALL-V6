local List0 = {
	[1] = {1,282,291,1},
	[2] = {2,371,294,1},
	[3] = {3,372,357,1},
	[4] = {4,373,358,1},
	[5] = {5,374,359,1},
	[6] = {6,375,360,1},
	[7] = {7,376,361,1},
	[8] = {8,377,362,1},
}

local Keys = {1,2,3,4,5,6,7,8,}



local PayCrateFirstBuyRewardTableBase = {

    -- 记录数
	COUNT = 9,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	crate_id = 2,
	item_id = 3,
	item_num = 4,

    -- 标识常量
}



return PayCrateFirstBuyRewardTableBase