local List0 = {
	[1] = {1,1,1,7500},
	[2] = {2,1,2,1999},
	[3] = {3,1,3,400},
	[4] = {4,1,4,100},
	[5] = {5,1,5,1},
	[6] = {6,2,1,7500},
	[7] = {7,2,2,1999},
	[8] = {8,2,3,400},
	[9] = {9,2,4,100},
	[10] = {10,2,5,1},
}

local Keys = {1,2,3,4,5,6,7,8,9,10,}



local PayCrateQualityProbabilityTableBase = {

    -- 记录数
	COUNT = 11,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	topic_id = 2,
	quality_id = 3,
	probability = 4,

    -- 标识常量
}



return PayCrateQualityProbabilityTableBase