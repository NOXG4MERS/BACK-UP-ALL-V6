local List0 = {
	[1] = {1,282,1,2},
	[2] = {2,371,1,1},
	[3] = {3,372,1,3},
	[4] = {4,373,1,4},
	[5] = {5,374,2,4},
	[6] = {6,375,2,3},
	[7] = {7,376,2,1},
	[8] = {8,377,2,2},
}

local Keys = {1,2,3,4,5,6,7,8,}



local PayCrateTableBase = {

    -- 记录数
	COUNT = 9,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	crate_id = 2,
	topic_id = 3,
	show_order = 4,

    -- 标识常量
}



return PayCrateTableBase