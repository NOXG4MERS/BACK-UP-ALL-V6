local List0 = {
	[1] = {1,"西游主题","XiYouZhuTi",1546358400,1561651200},
	[2] = {2,"春节主题","ChunJieZhuTi",1548777600,1561651200},
}

local Keys = {1,2,}



local PayCrateTopicTableBase = {

    -- 记录数
	COUNT = 3,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	start_time = 4,
	end_time = 5,

    -- 标识常量
	["XiYouZhuTi"] = "XiYouZhuTi",
	["ChunJieZhuTi"] = "ChunJieZhuTi",
}

local languageColumns = {2}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return PayCrateTopicTableBase