local List0 = {
	[872415232] = {872415232,1588435200,14,2},
	[872423424] = {872423424,1588435200,14,1},
	[1040187392] = {1040187392,4417977600,20,2147483392},
}

local Keys = {872415232,872423424,1040187392,}



local PrimeCratePromotionConfigTableBase = {

    -- 记录数
	COUNT = 4,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	start_time = 2,
	period = 3,
	server_type = 4,

    -- 标识常量
}



return PrimeCratePromotionConfigTableBase