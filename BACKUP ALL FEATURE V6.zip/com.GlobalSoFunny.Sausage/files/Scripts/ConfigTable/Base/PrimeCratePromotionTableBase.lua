local List0 = {
	[2080374784] = {2080374784,2080374784,335544435,1,"FanChangZQJ","6015","6016"},
	[2080374785] = {2080374785,2080374784,268435457,2,"FanChangVRXF","6021","6022"},
	[2080374786] = {2080374786,2080374784,335544436,3,"FanChangFHX","6017","6018"},
	[2080374787] = {2080374787,2080374785,335544478,1,"FanChangWSJ","6023","6024"},
	[2080374788] = {2080374788,2080374785,704643093,2,"FanChangTZSX","6025","6026"},
	[2080374789] = {2080374789,2080374785,637534230,3,"FanChangBXTH","6027","6028"},
}

local Keys = {2080374784,2080374785,2080374786,2080374787,2080374788,2080374789,}



local PrimeCratePromotionTableBase = {

    -- 记录数
	COUNT = 7,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	preferential_shop_id = 2,
	crate_id = 3,
	show_order = 4,
	pic_sign = 5,
	product_id1 = 6,
	product_id2 = 7,

    -- 标识常量
}



return PrimeCratePromotionTableBase