local List0 = {
	[1] = {1,776,"靓仔布偶团","XiongXinBaoDan","",""},
	[268435456] = {268435456,268435457,"VR先锋","VRXianFengZhuTi","",""},
	[335544320] = {335544320,335544350,"元气摇滚团","HuaiHuaiShaoNv","HuaiHuaiShaoNvTJ",""},
	[335544321] = {335544321,335544435,"19年中秋","ZhongQiuZhuTi","ZhongQiuZhuTiTJ",""},
	[335544322] = {335544322,335544436,"范海辛","FanHaiXinZhuTi","FanHaiXinZhuTiTJ",""},
	[335544323] = {335544323,335544448,"元气摇滚团","YuanQiYaoGunTuan","YuanQiYaoGunTuanTJ",""},
	[335544324] = {335544324,335544478,"19年万圣节","WanSheng19ZhuTi","WanSheng19ZhuTi",""},
	[369098752] = {369098752,369098780,"超人学院","ChaoRenXueYuanZhuTi","ChaoRenXueYuanZhuTi",""},
	[469762048] = {469762048,469762185,"20年鱼人节","YuRenJieZhuTi","YuRenJieZhuTi",""},
	[469762049] = {469762049,469762218,"寻宝探险","XunBaoTanXianZhuTi","XunBaoTanXianZhuTi",""},
	[469762050] = {469762050,469762228,"儿童节礼物","ErTongJieLiWu","ErTongJieLiWu",""},
	[469762051] = {469762051,469762276,"20年七夕","QiXiZhuTi20","",""},
	[503316480] = {503316480,503316633,"暗夜别动队","AnYeBieDongDui","",""},
	[570425344] = {570425344,570425403,"封神","FengShenZhuTi","FengShenZhuTi",""},
	[570425345] = {570425345,570425427,"华贵埃及","HuaGuiAiJi","HuaGuiAiJi",""},
	[603979776] = {603979776,603979925,"希望之种","XiWangZhiZhong","","https://n17x06.xdcdn.net/cartoon/27/v1/index.html?timestamp=1604296800000"},
	[637534208] = {637534208,637534230,"冰雪童话","BingXueTongHua","BingXueTongHua",""},
	[637534209] = {637534209,637534251,"20年情人节","QingRenJie20","QingRenJie20",""},
	[637534210] = {637534210,637534271,"20年女神节","NvShenJieZhuTi","NvShenJieZhuTi",""},
	[704643072] = {704643072,704643093,"特战双雄","VRZhanJing","VRZhanJing",""},
	[738197504] = {738197504,738197521,"三周年礼物","SanZhouNian","",""},
	[738197505] = {738197505,738197557,"盛夏派对","ShengXiaPaiDui","ShengXiaPaiDui",""},
	[872415232] = {872415232,872415378,"吕布貂蝉","LvBuDiaoChan","","https://n17x06.xdcdn.net/cartoon/28/v1/index.html?timestamp=1606406400"},
	[872415233] = {872415233,872415421,"20年圣诞节","ShengDan20","",""},
	[872415234] = {872415234,872415431,"圣诞节礼物","SDLW","",""},
	[872415235] = {872415235,872415433,"11111","111111","",""},
	[973078528] = {973078528,973078545,"花木兰","HuaMuLan","",""},
	[1107296256] = {1107296256,1107296281,"20年万圣节","WanShengJie20","",""},
	[2080374784] = {2080374784,2080374798,"20年元旦","YuanDan20ZhuTi","YuanDan20ZhuTi",""},
	[2080374785] = {2080374785,2080374876,"爱丽丝","AiLiSiZhuTi","",""},
	[2080374786] = {2080374786,2080374875,"牛魔王","NiuMoWang","","https://n17x06.xdcdn.net/cartoon/31/v1/index.html"},
	[2080374787] = {2080374787,2080374903,"21年春节礼物","ChunJie21","",""},
	[2080374788] = {2080374788,2080374939,"21年女神节","NvShenJie21","","https://n17x06.xdcdn.net/cartoon/v2/index.html#32"},
	[2113929216] = {2113929216,2113929240,"19年圣诞节","ShengDan19ZhuTi","ShengDan19ZhuTi",""},
	[2113929217] = {2113929217,2113929241,"国风潮流","GuoChaoZhuTi","",""},
	[2113929218] = {2113929218,2113929304,"20年儿童节","ErTongJie20","ErTongJie20",""},
	[2113929219] = {2113929219,2113929372,"20年中秋","ZhongQiu20","",""},
	[2113929220] = {2113929220,2113929440,"21年鱼人节","YuRenJie21","","https://n17x06.xdcdn.net/cartoon/v2/index.html#33"},
}

local Keys = {1,268435456,335544320,335544321,335544322,335544323,335544324,369098752,469762048,469762049,469762050,469762051,503316480,570425344,570425345,603979776,637534208,637534209,637534210,704643072,738197504,738197505,872415232,872415233,872415234,872415235,973078528,1107296256,2080374784,2080374785,2080374786,2080374787,2080374788,2113929216,2113929217,2113929218,2113929219,2113929220,}



local PrimeCrateTopicTableBase = {

    -- 记录数
	COUNT = 39,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	crate_id = 2,
	name = 3,
	sign = 4,
	pic_sign = 5,
	link = 6,

    -- 标识常量
	["XiongXinBaoDan"] = "XiongXinBaoDan",
	["VRXianFengZhuTi"] = "VRXianFengZhuTi",
	["HuaiHuaiShaoNv"] = "HuaiHuaiShaoNv",
	["ZhongQiuZhuTi"] = "ZhongQiuZhuTi",
	["FanHaiXinZhuTi"] = "FanHaiXinZhuTi",
	["YuanQiYaoGunTuan"] = "YuanQiYaoGunTuan",
	["WanSheng19ZhuTi"] = "WanSheng19ZhuTi",
	["ChaoRenXueYuanZhuTi"] = "ChaoRenXueYuanZhuTi",
	["YuRenJieZhuTi"] = "YuRenJieZhuTi",
	["XunBaoTanXianZhuTi"] = "XunBaoTanXianZhuTi",
	["ErTongJieLiWu"] = "ErTongJieLiWu",
	["QiXiZhuTi20"] = "QiXiZhuTi20",
	["AnYeBieDongDui"] = "AnYeBieDongDui",
	["FengShenZhuTi"] = "FengShenZhuTi",
	["HuaGuiAiJi"] = "HuaGuiAiJi",
	["XiWangZhiZhong"] = "XiWangZhiZhong",
	["BingXueTongHua"] = "BingXueTongHua",
	["QingRenJie20"] = "QingRenJie20",
	["NvShenJieZhuTi"] = "NvShenJieZhuTi",
	["VRZhanJing"] = "VRZhanJing",
	["SanZhouNian"] = "SanZhouNian",
	["ShengXiaPaiDui"] = "ShengXiaPaiDui",
	["LvBuDiaoChan"] = "LvBuDiaoChan",
	["ShengDan20"] = "ShengDan20",
	["SDLW"] = "SDLW",
	["111111"] = "111111",
	["HuaMuLan"] = "HuaMuLan",
	["WanShengJie20"] = "WanShengJie20",
	["YuanDan20ZhuTi"] = "YuanDan20ZhuTi",
	["AiLiSiZhuTi"] = "AiLiSiZhuTi",
	["NiuMoWang"] = "NiuMoWang",
	["ChunJie21"] = "ChunJie21",
	["NvShenJie21"] = "NvShenJie21",
	["ShengDan19ZhuTi"] = "ShengDan19ZhuTi",
	["GuoChaoZhuTi"] = "GuoChaoZhuTi",
	["ErTongJie20"] = "ErTongJie20",
	["ZhongQiu20"] = "ZhongQiu20",
	["YuRenJie21"] = "YuRenJie21",
}

local languageColumns = {3}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return PrimeCrateTopicTableBase