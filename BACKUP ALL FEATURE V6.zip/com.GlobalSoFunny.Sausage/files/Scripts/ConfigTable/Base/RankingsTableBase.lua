local List0 = {
	[503316480] = {503316480,"段位榜","GradeScore",1,1,"",1,1,0,0,1,1,0,1,1,1,1,1,1,0,0,0,20,20,100,0,0,0,"本周增长","当前段位分",2000,"",1,1},
	[503316481] = {503316481,"美味值","DeliciousScore",2,2,"当前美味值",1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,20,20,100,0,0,0,"本周增长","本赛季增长",0,"",2,1},
	[503316482] = {503316482,"粉丝","FansScore",3,2,"当前粉丝数",1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,2,3,10,0,0,0,"本周增长","本赛季增长",0,"",3,1},
	[503316483] = {503316483,"淘汰大师","EliminationScore",4,3,"总淘汰数",1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,2,3,10,0,0,0,"淘汰数","淘汰数",2000,"",9,1},
	[503316484] = {503316484,"暴击大师","CritScore",5,3,"总暴击淘汰数",1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,2,3,10,0,0,0,"暴击淘汰数","暴击淘汰数",2000,"",10,1},
	[503316485] = {503316485,"夺冠大师","Champion",6,3,"总夺冠数",1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,1,1,3,0,0,0,"夺冠数","夺冠数",2000,"",11,1},
	[637534208] = {637534208,"获赞","Like",7,2,"总获赞数",1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0,0,"获赞数","获赞数",0,"",4,1},
	[1442840576] = {1442840576,"CP榜","Cp",8,4,"当前亲密度",1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,99,0,0,0,"本周增长","本赛季增长",0,"",5,0},
	[1442840577] = {1442840577,"拍档榜","Partner",9,4,"当前亲密度",1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,99,0,0,0,"本周增长","本赛季增长",0,"",6,0},
	[1442840578] = {1442840578,"基友榜","Bromance",10,4,"当前亲密度",1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,99,0,0,0,"本周增长","本赛季增长",0,"",7,0},
	[1442840579] = {1442840579,"闺蜜榜","Besties",11,4,"当前亲密度",1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,99,0,0,0,"本周增长","本赛季增长",0,"",8,0},
}

local Keys = {503316480,503316481,503316482,503316483,503316484,503316485,637534208,1442840576,1442840577,1442840578,1442840579,}

local List4 = { 
	[1] =  {503316480},
	[2] =  {503316481},
	[3] =  {503316482},
	[4] =  {503316483},
	[5] =  {503316484},
	[6] =  {503316485},
	[7] =  {637534208},
	[8] =  {1442840576},
	[9] =  {1442840577},
	[10] =  {1442840578},
	[11] =  {1442840579},
}
local List5 = { 
	[1] =  {503316480},
	[2] =  {503316481 ,503316482 ,637534208},
	[3] =  {503316483 ,503316484 ,503316485},
	[4] =  {1442840576 ,1442840577 ,1442840578 ,1442840579},
}


local RankingsTableBase = {

    -- 记录数
	COUNT = 12,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,

	List4 = List4,
	List5 = List5,


    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	rankings_key = 4,
	rankings_type = 5,
	history_description = 6,
	area_global = 7,
	area_province = 8,
	area_city = 9,
	area_village = 10,
	time_week = 11,
	time_season = 12,
	time_history = 13,
	notify_global_week = 14,
	notify_global_season = 15,
	notify_global_history = 16,
	notify_province_week = 17,
	notify_province_season = 18,
	notify_province_history = 19,
	notify_village_week = 20,
	notify_village_season = 21,
	notify_village_history = 22,
	week_min_score = 23,
	season_min_score = 24,
	history_min_score = 25,
	notify_city_week = 26,
	notify_city_season = 27,
	notify_city_history = 28,
	week_description = 29,
	season_description = 30,
	min_grade_score = 31,
	title = 32,
	sort = 33,
	area_friend = 34,

    -- 标识常量
	["GradeScore"] = "GradeScore",
	["DeliciousScore"] = "DeliciousScore",
	["FansScore"] = "FansScore",
	["EliminationScore"] = "EliminationScore",
	["CritScore"] = "CritScore",
	["Champion"] = "Champion",
	["Like"] = "Like",
	["Cp"] = "Cp",
	["Partner"] = "Partner",
	["Bromance"] = "Bromance",
	["Besties"] = "Besties",
}

local languageColumns = {2, 6, 29, 30}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return RankingsTableBase