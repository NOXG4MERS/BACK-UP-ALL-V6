local List0 = {
	[1] = {1,"行为,移动异常","AbnormalMove",0,0,0},
	[2] = {2,"血量异常","AbnormalHealth",0,0,0},
	[3] = {3,"攻击视线外目标","OutsideVision",0,0,0},
	[4] = {4,"伤害异常","AbnormalDamage",0,0,0},
	[5] = {5,"自动锁定目标","LockTarget",0,0,0},
	[6] = {6,"武器无后坐力","NoRecoil",0,0,0},
	[7] = {7,"恶意伤害队友","DamageTeammates",0,0,0},
	[8] = {8,"言语辱骂","Abuse",0,0,0},
	[9] = {9,"消极挂机","Hang",0,0,0},
	[33554432] = {33554432,"外挂,作弊","Cheating",0,144000,43200},
	[33554433] = {33554433,"恶意使用BUG","BugHacking",0,0,0},
	[33554434] = {33554434,"言语攻击,刷屏广告","VerbalHarassment",0,0,0},
	[33554435] = {33554435,"恶意组队","Teaming",0,0,0},
	[33554436] = {33554436,"恶意挂机","MaliciousAFK",0,0,0},
	[436207616] = {436207616,"系统自动检测言语违规","AutoCheckDiction",0,0,0},
}

local Keys = {1,2,3,4,5,6,7,8,9,33554432,33554433,33554434,33554435,33554436,436207616,}



local ReportTypeTableBase = {

    -- 记录数
	COUNT = 16,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	freeze_report_type_reason_id = 4,
	check_battle_duration = 5,
	record_time = 6,

    -- 标识常量
	["AbnormalMove"] = "AbnormalMove",
	["AbnormalHealth"] = "AbnormalHealth",
	["OutsideVision"] = "OutsideVision",
	["AbnormalDamage"] = "AbnormalDamage",
	["LockTarget"] = "LockTarget",
	["NoRecoil"] = "NoRecoil",
	["DamageTeammates"] = "DamageTeammates",
	["Abuse"] = "Abuse",
	["Hang"] = "Hang",
	["Cheating"] = "Cheating",
	["BugHacking"] = "BugHacking",
	["VerbalHarassment"] = "VerbalHarassment",
	["Teaming"] = "Teaming",
	["MaliciousAFK"] = "MaliciousAFK",
	["AutoCheckDiction"] = "AutoCheckDiction",
}



return ReportTypeTableBase