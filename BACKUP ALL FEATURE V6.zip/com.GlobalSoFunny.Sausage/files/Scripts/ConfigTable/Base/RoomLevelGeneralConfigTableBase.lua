local List0 = {
	[1] = {1,14,1,500,24,24,7776000},
	[2] = {2,14,2,1000,24,24,7776000},
}

local Keys = {1,2,}



local RoomLevelGeneralConfigTableBase = {

    -- 记录数
	COUNT = 3,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	game_mode = 2,
	level = 3,
	max_score = 4,
	min_real_player_count = 5,
	max_real_player_count = 6,
	not_enough_min_count_timeout = 7,

    -- 标识常量
}



return RoomLevelGeneralConfigTableBase