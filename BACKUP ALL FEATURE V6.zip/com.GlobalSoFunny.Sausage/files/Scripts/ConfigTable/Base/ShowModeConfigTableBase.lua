local List0 = {
	[570425344] = {570425344,9,"Entrance_Battle2V2_ui"},
	[603979776] = {603979776,1,"Entrance_ClassRandomMap_ui"},
	[603979777] = {603979777,2,"Entrance_FastRandomMap_ui"},
	[603979778] = {603979778,3,"Entrance_TeamtRandomMap_ui"},
	[603979779] = {603979779,4,"Entrance_SniperRandomMap_ui"},
	[603979780] = {603979780,7,"Entrance_CircusTroupe_ui"},
	[603979781] = {603979781,8,"Entrance_RainbowFight_ui"},
	[838860800] = {838860800,5,"Entrance_Knockout_ui"},
}

local Keys = {570425344,603979776,603979777,603979778,603979779,603979780,603979781,838860800,}



local ShowModeConfigTableBase = {

    -- 记录数
	COUNT = 9,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	show_mode = 2,
	custom_room_resources = 3,

    -- 标识常量
}



return ShowModeConfigTableBase