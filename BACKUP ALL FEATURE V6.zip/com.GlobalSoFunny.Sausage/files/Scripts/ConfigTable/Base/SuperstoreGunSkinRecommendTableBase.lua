local List0 = {
	[1] = {1,1,1,1563120000,1569168000},
	[335544320] = {335544320,2,3,1564675200,1566575999},
	[335544321] = {335544321,3,2,1562860800,1564675199},
}

local Keys = {1,335544320,335544321,}



local SuperstoreGunSkinRecommendTableBase = {

    -- 记录数
	COUNT = 4,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	recommend_theme = 2,
	order_id = 3,
	start_time = 4,
	end_time = 5,

    -- 标识常量
}



return SuperstoreGunSkinRecommendTableBase