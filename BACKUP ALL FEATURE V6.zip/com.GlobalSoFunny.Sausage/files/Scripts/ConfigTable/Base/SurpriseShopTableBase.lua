local List0 = {
	[503316480] = {503316480,2,"限时1元特惠",503316481,1,"com.xd.sausage.DiscountPrice.1",2,"XianShiTangGuo1","200",1},
	[503316481] = {503316481,2,"限时3元特惠",503316481,1,"com.xd.sausage.DiscountPrice.3",5,"XianShiTangGuo1","180",0},
	[503316482] = {503316482,2,"限时6元特惠",503316481,2,"com.xd.sausage.DiscountPrice.6",10,"XianShiTangGuo2","180",1},
	[503316483] = {503316483,2,"限时8元特惠",503316481,2,"com.xd.sausage.DiscountPrice.8",14,"XianShiTangGuo2","180",0},
	[503316484] = {503316484,2,"限时12元特惠",503316481,3,"com.xd.sausage.DiscountPrice.12",21,"XianShiTangGuo3","180",1},
	[503316485] = {503316485,2,"限时18元特惠",503316481,3,"com.xd.sausage.DiscountPrice.18",32,"XianShiTangGuo3","180",0},
	[503316486] = {503316486,2,"限时1元特惠",503316482,1,"com.xd.sausage.DiscountPrice.1",2,"XianShiTangGuo1","200",0},
	[503316487] = {503316487,2,"限时3元特惠",503316482,1,"com.xd.sausage.DiscountPrice.3",5,"XianShiTangGuo1","180",1},
	[503316488] = {503316488,2,"限时6元特惠",503316482,1,"com.xd.sausage.DiscountPrice.6",10,"XianShiTangGuo1","180",0},
	[503316489] = {503316489,2,"限时8元特惠",503316482,2,"com.xd.sausage.DiscountPrice.8",14,"XianShiTangGuo2","180",1},
	[503316490] = {503316490,2,"限时12元特惠",503316482,2,"com.xd.sausage.DiscountPrice.12",21,"XianShiTangGuo2","180",0},
	[503316491] = {503316491,2,"限时18元特惠",503316482,3,"com.xd.sausage.DiscountPrice.18",32,"XianShiTangGuo3","180",1},
	[503316492] = {503316492,2,"限时25元特惠",503316482,3,"com.xd.sausage.DiscountPrice.25",45,"XianShiTangGuo3","180",0},
	[503316493] = {503316493,2,"限时1元特惠",503316483,1,"com.xd.sausage.DiscountPrice.1",2,"XianShiTangGuo1","200",0},
	[503316494] = {503316494,2,"限时3元特惠",503316483,1,"com.xd.sausage.DiscountPrice.3",5,"XianShiTangGuo1","180",0},
	[503316495] = {503316495,2,"限时6元特惠",503316483,1,"com.xd.sausage.DiscountPrice.6",10,"XianShiTangGuo1","180",1},
	[503316496] = {503316496,2,"限时8元特惠",503316483,2,"com.xd.sausage.DiscountPrice.8",14,"XianShiTangGuo2","180",0},
	[503316497] = {503316497,2,"限时12元特惠",503316483,2,"com.xd.sausage.DiscountPrice.12",21,"XianShiTangGuo2","180",0},
	[503316498] = {503316498,2,"限时18元特惠",503316483,2,"com.xd.sausage.DiscountPrice.18",32,"XianShiTangGuo3","180",1},
	[503316499] = {503316499,2,"限时25元特惠",503316483,2,"com.xd.sausage.DiscountPrice.25",45,"XianShiTangGuo3","180",0},
	[503316500] = {503316500,2,"限时28元特惠",503316483,2,"com.xd.sausage.DiscountPrice.28",50,"XianShiTangGuo3","180",0},
	[503316501] = {503316501,2,"限时30元特惠",503316483,3,"com.xd.sausage.DiscountPrice.30",54,"XianShiTangGuo4","180",0},
	[503316502] = {503316502,2,"限时40元特惠",503316483,3,"com.xd.sausage.DiscountPrice.40",72,"XianShiTangGuo4","180",1},
	[503316503] = {503316503,2,"限时50元特惠",503316483,3,"com.xd.sausage.DiscountPrice.50",90,"XianShiTangGuo4","180",0},
	[503316504] = {503316504,2,"免费糖果",503316481,0,"com.xd.sausage.DiscountPrice.1",5,"XianShiTangGuo1","0",0},
	[503316505] = {503316505,2,"免费糖果",503316482,0,"com.xd.sausage.DiscountPrice.1",5,"XianShiTangGuo1","0",0},
	[503316506] = {503316506,2,"免费糖果",503316483,0,"com.xd.sausage.DiscountPrice.1",5,"XianShiTangGuo1","0",0},
	[1040187392] = {1040187392,2147483392,"限时0.99美元特惠",503316481,1,"xdglobal.sausage.limitoffer1",0,"XianShiTangGuo1","180",1},
	[1040187393] = {1040187393,2147483392,"限时1.99美元特惠",503316481,1,"xdglobal.sausage.limitoffer501",0,"XianShiTangGuo1","180",0},
	[1040187394] = {1040187394,2147483392,"免费糖果",503316481,0,"xdglobal.sausage.limitoffer1",0,"XianShiTangGuo1","0",0},
	[1040187395] = {1040187395,2147483392,"限时2.99美元特惠",503316481,2,"xdglobal.sausage.limitoffer51",0,"XianShiTangGuo2","180",1},
	[1040187396] = {1040187396,2147483392,"限时3.99美元特惠",503316481,2,"xdglobal.sausage.limitoffer101",0,"XianShiTangGuo2","180",0},
	[1040187397] = {1040187397,2147483392,"限时4.99美元特惠",503316481,3,"xdglobal.sausage.limitoffer151",0,"XianShiTangGuo3","180",1},
	[1040187398] = {1040187398,2147483392,"限时5.99美元特惠",503316481,3,"xdglobal.sausage.limitoffer201",0,"XianShiTangGuo3","180",0},
	[1040187399] = {1040187399,2147483392,"限时0.99美元特惠",503316482,1,"xdglobal.sausage.limitoffer1",0,"XianShiTangGuo1","180",0},
	[1040187400] = {1040187400,2147483392,"限时1.99美元特惠",503316482,3,"xdglobal.sausage.limitoffer501",0,"XianShiTangGuo1","180",1},
	[1040187401] = {1040187401,2147483392,"免费糖果",503316482,0,"xdglobal.sausage.limitoffer1",0,"XianShiTangGuo1","0",0},
	[1040187402] = {1040187402,2147483392,"限时2.99美元特惠",503316482,1,"xdglobal.sausage.limitoffer51",0,"XianShiTangGuo1","180",0},
	[1040187403] = {1040187403,2147483392,"限时3.99美元特惠",503316482,2,"xdglobal.sausage.limitoffer101",0,"XianShiTangGuo2","180",1},
	[1040187404] = {1040187404,2147483392,"限时4.99美元特惠",503316482,2,"xdglobal.sausage.limitoffer151",0,"XianShiTangGuo2","180",0},
	[1040187405] = {1040187405,2147483392,"限时5.99美元特惠",503316482,3,"xdglobal.sausage.limitoffer201",0,"XianShiTangGuo3","180",1},
	[1040187406] = {1040187406,2147483392,"限时6.99美元特惠",503316482,3,"xdglobal.sausage.limitoffer251",0,"XianShiTangGuo3","180",0},
	[1040187407] = {1040187407,2147483392,"限时0.99美元特惠",503316483,1,"xdglobal.sausage.limitoffer1",0,"XianShiTangGuo1","180",0},
	[1040187408] = {1040187408,2147483392,"限时1.99美元特惠",503316483,1,"xdglobal.sausage.limitoffer501",0,"XianShiTangGuo1","180",0},
	[1040187409] = {1040187409,2147483392,"免费糖果",503316483,0,"xdglobal.sausage.limitoffer1",0,"XianShiTangGuo1","0",0},
	[1040187410] = {1040187410,2147483392,"限时2.99美元特惠",503316483,1,"xdglobal.sausage.limitoffer51",0,"XianShiTangGuo1","180",1},
	[1040187411] = {1040187411,2147483392,"限时3.99美元特惠",503316483,2,"xdglobal.sausage.limitoffer101",0,"XianShiTangGuo2","180",0},
	[1040187412] = {1040187412,2147483392,"限时4.99美元特惠",503316483,2,"xdglobal.sausage.limitoffer151",0,"XianShiTangGuo3","180",0},
	[1040187413] = {1040187413,2147483392,"限时5.99美元特惠",503316483,2,"xdglobal.sausage.limitoffer201",0,"XianShiTangGuo3","180",1},
	[1040187414] = {1040187414,2147483392,"限时6.99美元特惠",503316483,2,"xdglobal.sausage.limitoffer251",0,"XianShiTangGuo3","180",0},
	[1040187415] = {1040187415,2147483392,"限时7.99美元特惠",503316483,2,"xdglobal.sausage.limitoffer301",0,"XianShiTangGuo3","180",0},
	[1040187416] = {1040187416,2147483392,"限时9.99美元特惠",503316483,3,"xdglobal.sausage.limitoffer351",0,"XianShiTangGuo4","180",0},
	[1040187417] = {1040187417,2147483392,"限时11.99美元特惠",503316483,3,"xdglobal.sausage.limitoffer401",0,"XianShiTangGuo4","180",1},
	[1040187418] = {1040187418,2147483392,"限时12.99美元特惠",503316483,3,"xdglobal.sausage.limitoffer451",0,"XianShiTangGuo4","180",0},
}

local Keys = {503316480,503316481,503316482,503316483,503316484,503316485,503316486,503316487,503316488,503316489,503316490,503316491,503316492,503316493,503316494,503316495,503316496,503316497,503316498,503316499,503316500,503316501,503316502,503316503,503316504,503316505,503316506,1040187392,1040187393,1040187394,1040187395,1040187396,1040187397,1040187398,1040187399,1040187400,1040187401,1040187402,1040187403,1040187404,1040187405,1040187406,1040187407,1040187408,1040187409,1040187410,1040187411,1040187412,1040187413,1040187414,1040187415,1040187416,1040187417,1040187418,}



local SurpriseShopTableBase = {

    -- 记录数
	COUNT = 55,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	server_type = 2,
	name = 3,
	pay_label_id = 4,
	surprise_shop_grade = 5,
	product_id = 6,
	original_price = 7,
	pic_sign = 8,
	discount_sign = 9,
	is_init = 10,

    -- 标识常量
}



return SurpriseShopTableBase