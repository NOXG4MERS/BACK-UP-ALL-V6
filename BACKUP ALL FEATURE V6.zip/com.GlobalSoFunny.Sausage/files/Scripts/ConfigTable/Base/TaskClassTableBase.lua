local List0 = {
	[1] = {1,"动作击杀","ActionKiller",8,10,0,1},
	[2] = {2,"消耗子弹","ConsumeBullet",13,10,0,1},
	[3] = {3,"使用动作","UseAction",14,10,0,1},
	[4] = {4,"舔空投","GetItem",10,10,0,1},
	[5] = {5,"击杀-距离外","KillOutDistance",8,10,0,1},
	[6] = {6,"击杀-距离内","KillInDistance",8,10,0,1},
	[7] = {7,"杂技球击杀","CircusBallKill",8,10,0,1},
	[8] = {8,"累计参赛","TotalBattle",2,10,0,1},
	[9] = {9,"跳伞","Jump",16,10,0,1},
	[10] = {10,"特殊行为","Special",17,10,0,1},
	[11] = {11,"累计拾取物品(次)","TotalCollectItem",18,10,0,1},
	[12] = {12,"名次评分","Grade",2,10,0,1},
	[13] = {13,"区域淘汰","AreaKill",8,10,0,1},
	[14] = {14,"非事件任务","NoEvent",0,10,0,2},
	[15] = {15,"驾驶击杀","DriveKill",19,10,0,1},
	[16] = {16,"破坏载具","DestroyCarrier",20,10,0,1},
	[167772160] = {167772160,"参与","Join",2,10,0,1},
	[167772161] = {167772161,"排名","Rank",2,10,0,1},
	[167772162] = {167772162,"移动","Move",5,10,0,1},
	[167772163] = {167772163,"存活","Alive",2,10,0,1},
	[167772164] = {167772164,"使用物品","UseItem",4,10,0,1},
	[167772165] = {167772165,"恢复血量","AddHp",3,10,0,1},
	[167772166] = {167772166,"武器系列杀人","SeriesKiller",8,10,0,1},
	[167772167] = {167772167,"具体武器杀人","SpecificKiller",8,10,0,1},
	[167772168] = {167772168,"子弹杀人","BulletKille",8,10,0,1},
	[167772169] = {167772169,"伤害","Hurt",11,10,0,1},
	[167772170] = {167772170,"助攻","Assist",12,10,0,1},
	[167772171] = {167772171,"扶人","PickUp",1,10,0,1},
	[234881024] = {234881024,"衍生武器杀人","DeriveKiller",8,10,0,1},
	[234881025] = {234881025,"连续击杀","KillStreak",234881024,10,0,1},
	[234881026] = {234881026,"团队击杀","TeamKill",234881025,10,0,1},
	[234881027] = {234881027,"配件击杀","PartsKill",234881026,10,0,1},
	[234881028] = {234881028,"淘汰","WeedOut",234881027,10,0,1},
	[234881029] = {234881029,"使用传送大炮","UseCannon",234881028,10,0,1},
	[335544320] = {335544320,"拾取物品(局)","CollectItem",335544320,10,0,1},
	[335544321] = {335544321,"复活","Revive",335544321,10,0,1},
	[503316480] = {503316480,"击杀指定对象","KillAppointObject",503316480,10,0,1},
	[503316481] = {503316481,"指定对象造成伤害","AppointObjectHert",503316481,10,0,1},
	[503316482] = {503316482,"进入指定区域","AreaIntoClass",2,10,0,1},
	[738197504] = {738197504,"结算累计拾取物品","OverCollectItem",738197504,10,0,1},
}

local Keys = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,167772160,167772161,167772162,167772163,167772164,167772165,167772166,167772167,167772168,167772169,167772170,167772171,234881024,234881025,234881026,234881027,234881028,234881029,335544320,335544321,503316480,503316481,503316482,738197504,}



local TaskClassTableBase = {

    -- 记录数
	COUNT = 41,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	war_event_id = 4,
	weight = 5,
	client_jump_func = 6,
	task_class_type = 7,

    -- 标识常量
	["ActionKiller"] = "ActionKiller",
	["ConsumeBullet"] = "ConsumeBullet",
	["UseAction"] = "UseAction",
	["GetItem"] = "GetItem",
	["KillOutDistance"] = "KillOutDistance",
	["KillInDistance"] = "KillInDistance",
	["CircusBallKill"] = "CircusBallKill",
	["TotalBattle"] = "TotalBattle",
	["Jump"] = "Jump",
	["Special"] = "Special",
	["TotalCollectItem"] = "TotalCollectItem",
	["Grade"] = "Grade",
	["AreaKill"] = "AreaKill",
	["NoEvent"] = "NoEvent",
	["DriveKill"] = "DriveKill",
	["DestroyCarrier"] = "DestroyCarrier",
	["Join"] = "Join",
	["Rank"] = "Rank",
	["Move"] = "Move",
	["Alive"] = "Alive",
	["UseItem"] = "UseItem",
	["AddHp"] = "AddHp",
	["SeriesKiller"] = "SeriesKiller",
	["SpecificKiller"] = "SpecificKiller",
	["BulletKille"] = "BulletKille",
	["Hurt"] = "Hurt",
	["Assist"] = "Assist",
	["PickUp"] = "PickUp",
	["DeriveKiller"] = "DeriveKiller",
	["KillStreak"] = "KillStreak",
	["TeamKill"] = "TeamKill",
	["PartsKill"] = "PartsKill",
	["WeedOut"] = "WeedOut",
	["UseCannon"] = "UseCannon",
	["CollectItem"] = "CollectItem",
	["Revive"] = "Revive",
	["KillAppointObject"] = "KillAppointObject",
	["AppointObjectHert"] = "AppointObjectHert",
	["AreaIntoClass"] = "AreaIntoClass",
	["OverCollectItem"] = "OverCollectItem",
}



return TaskClassTableBase