local List0 = {
	[268435456] = {268435456,2,4,234881024,10},
}

local Keys = {268435456,}



local TaskExtraRewardTableBase = {

    -- 记录数
	COUNT = 2,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	task_type = 2,
	progress = 3,
	item_id = 4,
	item_count = 5,

    -- 标识常量
}



return TaskExtraRewardTableBase