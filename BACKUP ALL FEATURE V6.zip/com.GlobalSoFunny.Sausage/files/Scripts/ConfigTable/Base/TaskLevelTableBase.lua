local List0 = {
	[268435456] = {268435456,1,"普通","PuTong",251,700,234881024,2,251,1600,234881024,10,0,0,0,0},
	[268435457] = {268435457,2,"稀有","XiYou",251,1000,234881024,4,251,2500,234881024,15,0,0,0,0},
	[268435458] = {268435458,3,"史诗","ShiShi",251,1800,234881024,6,251,4000,234881024,20,251,1800,234881024,6},
}

local Keys = {268435456,268435457,268435458,}



local TaskLevelTableBase = {

    -- 记录数
	COUNT = 4,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	level = 2,
	discription = 3,
	sign = 4,
	daily_item1_id = 5,
	daily_item1_count = 6,
	daily_item2_id = 7,
	daily_item2_count = 8,
	weekly_item1_id = 9,
	weekly_item1_count = 10,
	weekly_item2_id = 11,
	weekly_item2_count = 12,
	vip_item1_id = 13,
	vip_item1_count = 14,
	vip_item2_id = 15,
	vip_item2_count = 16,

    -- 标识常量
	["PuTong"] = "PuTong",
	["XiYou"] = "XiYou",
	["ShiShi"] = "ShiShi",
}

local languageColumns = {3}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return TaskLevelTableBase