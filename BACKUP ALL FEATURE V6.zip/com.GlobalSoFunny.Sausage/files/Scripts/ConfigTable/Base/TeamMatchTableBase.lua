local List0 = {
	[1] = {1,1,-500,0,60},
	[2] = {2,2,0,1,20},
	[3] = {3,3,500,1,20},
	[4] = {4,4,1000,1,20},
}

local Keys = {1,2,3,4,}



local TeamMatchTableBase = {

    -- 记录数
	COUNT = 5,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	level = 2,
	max_score = 3,
	is_down = 4,
	waiting_time = 5,

    -- 标识常量
}



return TeamMatchTableBase