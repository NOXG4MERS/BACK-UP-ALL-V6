local List0 = {
	[738197504] = {738197504,1,"ThirdAnnual1","ThirdAnniversary1","TimeMachineTitle1","ThirdAnniversaryImage1"},
	[738197505] = {738197505,2,"ThirdAnnual2","ThirdAnniversary2","TimeMachineTitle2","ThirdAnniversaryImage2"},
	[738197506] = {738197506,3,"ThirdAnnual3","ThirdAnniversary3","TimeMachineTitle3","ThirdAnniversaryImage3"},
	[738197507] = {738197507,4,"ThirdAnnual4","ThirdAnniversary4","TimeMachineTitle4","ThirdAnniversaryImage4"},
	[738197508] = {738197508,5,"ThirdAnnual5","ThirdAnniversary5","TimeMachineTitle5","ThirdAnniversaryImage5"},
}

local Keys = {738197504,738197505,738197506,738197507,738197508,}



local TimeMachineInfoTableBase = {

    -- 记录数
	COUNT = 6,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	sort_id = 2,
	picture_sign = 3,
	content = 4,
	title_sign = 5,
	photo_sign = 6,

    -- 标识常量
}



return TimeMachineInfoTableBase