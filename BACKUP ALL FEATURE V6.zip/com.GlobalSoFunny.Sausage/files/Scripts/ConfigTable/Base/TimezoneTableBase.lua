local List0 = {
	[436207616] = {436207616,"Asia/Shanghai","UTC+8",28800},
	[436207617] = {436207617,"Asia/Tokyo","UTC+9",32400},
	[436207618] = {436207618,"Asia/Seoul","UTC+9",32400},
	[436207619] = {436207619,"Asia/Bangkok","UTC+7",25200},
	[436207620] = {436207620,"Asia/Singapore","UTC+8",28800},
	[436207621] = {436207621,"America/New_York","UTC-4->UTC-5",-14400},
	[436207622] = {436207622,"Europe/Berlin","UTC-2->UTC1",7200},
	[436207623] = {436207623,"America/Sao_Paulo","UTC-3->UTC-2",-10800},
	[1040187392] = {1040187392,"Asia/Singapore","UTC+8",28800},
	[1040187393] = {1040187393,"Asia/Kuala_Lumpur","UTC+8",28800},
	[1040187394] = {1040187394,"Asia/Jakarta","UTC+8",28800},
}

local Keys = {436207616,436207617,436207618,436207619,436207620,436207621,436207622,436207623,1040187392,1040187393,1040187394,}

local List2 = { 
	["Asia/Shanghai"] =  {436207616},
	["Asia/Tokyo"] =  {436207617},
	["Asia/Seoul"] =  {436207618},
	["Asia/Bangkok"] =  {436207619},
	["Asia/Singapore"] =  {436207620 ,1040187392},
	["America/New_York"] =  {436207621},
	["Europe/Berlin"] =  {436207622},
	["America/Sao_Paulo"] =  {436207623},
	["Asia/Kuala_Lumpur"] =  {1040187393},
	["Asia/Jakarta"] =  {1040187394},
}


local TimezoneTableBase = {

    -- 记录数
	COUNT = 12,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,

	List2 = List2,


    -- 字段索引
	id = 1,
	name = 2,
	utc = 3,
	utc_offset = 4,

    -- 标识常量
}



return TimezoneTableBase