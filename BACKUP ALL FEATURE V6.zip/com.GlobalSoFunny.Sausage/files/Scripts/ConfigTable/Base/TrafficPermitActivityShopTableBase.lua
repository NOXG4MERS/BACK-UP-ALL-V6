local List0 = {
	[905969664] = {905969664,905969668,905969664},
}

local Keys = {905969664,}



local TrafficPermitActivityShopTableBase = {

    -- 记录数
	COUNT = 2,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	activity_id = 2,
	activity_shop_id = 3,

    -- 标识常量
}



return TrafficPermitActivityShopTableBase