local List0 = {
	[1] = {1,234881024,125,2},
	[335544320] = {335544320,234881024,335544406,2},
}

local Keys = {1,335544320,}



local TrafficPermitSeasonChallengeTableBase = {

    -- 记录数
	COUNT = 3,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	season_id = 2,
	task_id = 3,
	client_jump_func = 4,

    -- 标识常量
}



return TrafficPermitSeasonChallengeTableBase