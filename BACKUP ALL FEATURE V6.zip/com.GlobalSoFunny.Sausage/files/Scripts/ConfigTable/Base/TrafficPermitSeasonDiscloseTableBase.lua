local List0 = {
	[738197504] = {738197504,503316480,1,"Y星飞碟","新关卡","ReviewIconS5_YXingUFO","Y星飞碟","新关卡","惊讶！某岛上空出现大型飞碟，难道是Y星友人来串门啦？","season_review/s5/s5_yxingufo.png"},
	[738197505] = {738197505,503316480,2,"小飞碟","新载具","ReviewIconS5_UFO","小飞碟","新载具","羡慕！Y星人的豪华装备小飞碟，击落Y星侦察兵就可以抢夺过来啦！","season_review/s5/s5_ufo.png"},
	[738197506] = {738197506,503316480,3,"Y星加速机枪","新武器","ReviewIconS5_FocusGun","Y星加速机枪","新武器","Y星人作战能力很强？原来是靠这把枪才能如此嚣张！Y星科技能量武器，你值得拥有~","season_review/s5/s5_focusgun.png"},
	[738197507] = {738197507,503316480,4,"积木","靶场新玩具","ReviewIconS5_Lego","积木","靶场新玩具","发挥天马行空的想象力，想建哪里建哪里~","season_review/s5/s5_lego.png"},
	[738197508] = {738197508,503316480,5,"星星争夺战","新玩法","ReviewIconS5_RainbowFight","星星争夺战","新玩法","街机派对新玩法，冲突爆发！争夺更多星星，成为最大赢家！","season_review/s5/s5_rainbowfight.png"},
	[738197509] = {738197509,503316480,6,"Y星蓄能炮","新武器","ReviewIconS5_RailGun","Y星蓄能炮","新武器","大发现！Y星人压箱底的秘密武器，子弹不下坠，狙击手最爱！","season_review/s5/s5_railgun.png"},
	[738197510] = {738197510,905969664,1,"神王身份卡","新道具","ReviewIconS6_Zeus","神王身份卡","新道具","装备身份卡后可以获得神王宙斯的技能，瞬间飞高高、投掷闪电叉，超拉风！","season_review/s6/s6_zeus.png"},
	[738197511] = {738197511,905969664,2,"冥王身份卡","新道具","ReviewIconS6_Hades","冥王身份卡","新道具","装备身份卡后可以获得冥王哈迪斯的技能，隐身疾跑、投掷冥火球，超酷炫！","season_review/s6/s6_hades.png"},
	[738197512] = {738197512,905969664,3,"海神身份卡","新道具","ReviewIconS6_Poseidon","海神身份卡","新道具","装备身份卡后可以获得海神波塞冬的技能，召唤鲨鱼、生成护盾，超生猛！","season_review/s6/s6_poseidon.png"},
	[738197513] = {738197513,905969664,4,"众神浴场","新关卡","ReviewIconS6_ZhongShenYuChang","众神浴场","新关卡","彩虹岛出现了一座神迹，快来探秘众神浴场，和传说中的众神一起泡个澡吧~","season_review/s6/s6_zhongshenyuchang.png"},
	[738197514] = {738197514,905969664,5,"枪战对决","新玩法","ReviewIconS6_GunFight","枪战对决","新玩法","街机派对新玩法，小规模回合作战，决出香肠岛上最厉害的仔！","season_review/s6/s6_gunfight.png"},
	[738197515] = {738197515,1040187392,1,"军师身份卡","新道具","ReviewIconS7_ZhuGeLiang","军师身份卡","新道具","装备身份卡后可以获得军师诸葛亮的技能，投掷箭塔、八卦阵侦察，超智能！","season_review/s7/s7_zhugeliang.png"},
	[738197516] = {738197516,1040187392,2,"枭雄身份卡","新道具","ReviewIconS7_CaoCao","枭雄身份卡","新道具","装备身份卡后可以获得枭雄曹操的技能，投掷盾兵、枭雄降临，超霸气！","season_review/s7/s7_caocao.png"},
	[738197517] = {738197517,1040187392,3,"武圣身份卡","新道具","ReviewIconS7_GuanYu","武圣身份卡","新道具","装备身份卡后可以获得武圣关羽的技能，无畏冲锋、十方无敌，超威武！","season_review/s7/s7_guanyu.png"},
	[738197518] = {738197518,1040187392,4,"三国学院","新关卡","ReviewIconS7_SanGuoXueYuan","三国学院","新关卡","战斗岛新地标，肠岛大乱，硝烟四起，来三国学院，煮酒论巅峰！","season_review/s7/s7_sanguoxueyuan.png"},
	[738197519] = {738197519,1040187392,5,"身份卡乱斗","新玩法","ReviewIconS7_IDCardMode","身份卡乱斗","新玩法","肠岛英雄大乱斗！快比比谁能笑傲全场，现已加入街机派对豪华午餐~","season_review/s7/s7_idcardmode.png"},
	[738197520] = {738197520,1040187392,6,"小马","新载具","ReviewIconS7_PonyVehicle","小马","新载具","来自三国学院的奇妙物种，加速时要坐稳了！！！它是个烈性子！","season_review/s7/s7_ponyvehicle.png"},
	[905969664] = {905969664,234881024,1,"皮皮球","新道具","ReviewIconS1_CircusBall","皮皮球","新道具","皮皮马戏团的表演道具，踩上去可以嗖嗖地加速移动，被攻击会爆掉的哦。","season_review/s1/s1_circusball.png"},
	[905969665] = {905969665,234881024,8,"战术掩体","新道具","ReviewIconS1_SandCastle","战术掩体","新道具","可以有效地抵御对手的一波枪林弹雨，在掩体破裂前要想好作战计划才行。","season_review/s1/s1_sandcastle.png"},
	[905969666] = {905969666,234881024,5,"团队激斗","新模式","ReviewIconS1_TeamFight","团队激斗","新模式","分为两个阵营的PVP模式，为了团队的荣耀冲锋陷阵淘汰更多对手吧。","season_review/s1/s1_teamfight.png"},
	[905969667] = {905969667,234881024,3,"马戏团","新关卡","ReviewIconS1_MaXiTuan","马戏团","新关卡","S1赛季皮皮马戏团的表演场地，有巨型小丑团长建筑和过山车式的滑索公园。","season_review/s1/s1_maxituan.png"},
	[905969668] = {905969668,234881024,2,"信号枪","新武器","ReviewIconS1_SignalGun","信号枪","新武器","发射后可以召唤超级空投，想要逆天改命就来一发吧~记得要正对着天空发射哦！","season_review/s1/s1_signalgun.png"},
	[905969669] = {905969669,234881024,6,"RPG","新武器","ReviewIconS1_RPG","RPG","新武器","范围爆炸伤害，没有什么问题是一发RPG解决不了的，如果有，就再来一发。","season_review/s1/s1_rpg.png"},
	[905969670] = {905969670,234881024,7,"加特林","新武器","ReviewIconS1_Minigun","加特林","新武器","biubiubiubiuibiu~来见识见识加特林机枪的火力压制吧。","season_review/s1/s1_minigun.png"},
	[905969671] = {905969671,234881024,4,"KSG","新武器","ReviewIconS1_KSG","KSG","新武器","彩虹岛专属霰弹枪，不要怂，就是刚！","season_review/s1/s1_ksg.png"},
	[905969672] = {905969672,1,1,"狙击对决","新玩法","ReviewIconS2_Sniping","狙击对决","新玩法","不抢空投了，AWM在手，看看谁才是真正的狙神吧。","season_review/s2/s2_sniping.png"},
	[905969673] = {905969673,1,3,"海盗船","新关卡","ReviewIconS2_FeiChuan","海盗船","新关卡","S2赛季飞翔海盗团的大飞船，船上有许多稀有的宝箱资源。起飞后一段时间会慢慢降落。","season_review/s2/s2_feichuan.png"},
	[905969674] = {905969674,1,6,"传送大炮","新机关","ReviewIconS2_PirateCannon","传送大炮","新机关","嘭！咻~~~彩虹岛布置了许多传送大炮，能快速转移，从天而降时还可以造成范围伤害。","season_review/s2/s2_piratecannon.png"},
	[905969675] = {905969675,1,4,"激光瞄准器","新配件","ReviewIconS2_LaserSight","激光瞄准器","新配件","装上去之后，感觉打枪更稳了呢~","season_review/s2/s2_lasersight.png"},
	[905969676] = {905969676,1,2,"QBZ","新武器","ReviewIconS2_QBZ","QBZ","新武器","全新上架的突击步枪，走过路过不要错过！","season_review/s2/s2_qbz.png"},
	[905969677] = {905969677,1,5,"拉钩钩","新道具","ReviewIconS2_ShipAnchor","拉钩钩","新道具","有了拉钩钩，你就可以化身为飞檐走壁的蜘蛛肠，指哪儿勾哪儿。","season_review/s2/s2_shipanchor.png"},
	[905969678] = {905969678,2,2,"城堡","新关卡","ReviewIconS3_ChengBao","城堡","新关卡","S3赛季饿龙盘踞的城堡。里面有没有公主呢？或许城堡内蹦蹦跳跳的啵啵可以告诉你答案。","season_review/s3/s3_chengbao.png"},
	[905969679] = {905969679,2,4,"躲猫猫","新玩法","ReviewIconS3_CircusTroupe","躲猫猫","新玩法","嘘~快变成各种道具躲起来！每隔一段时间会出现系统警报暴露位置，要赶快换个地方藏哦。","season_review/s3/s3_circustroupe.png"},
	[905969680] = {905969680,2,6,"投掷啵啵","新道具","ReviewIconS3_SlimeBomb","投掷啵啵","新道具","就决定是你了——啵啵！把捕获的啵啵投掷出去，踩上去之后就可以高高蹦起来了。","season_review/s3/s3_slimebomb.png"},
	[905969681] = {905969681,2,7,"野生啵啵","新岛民","ReviewIconS3_wildBomb","野生啵啵","新岛民","野外生长的啵啵，颜色也和城堡里不一样，打爆之后可以获得各种补给品。","season_review/s3/s3_wildbomb.png"},
	[905969682] = {905969682,2,1,"圣剑","新武器","ReviewIconS3_HolySword","圣剑","新武器","一刀999，全场横着走，圣剑在手，难逢对手。","season_review/s3/s3_holysword.png"},
	[905969683] = {905969683,2,3,"呆呆龙","新载具","ReviewIconS3_SummonGun","呆呆龙","新载具","呆呆龙最多承载4人，可以在空中快速移动、喷射火焰，能量耗尽时要用彩虹能源为呆呆龙充能哦。","season_review/s3/s3_summongun.png"},
	[905969684] = {905969684,2,5,"火球","新道具","ReviewIconS3_FireBall","火球","新道具","投掷后生成一片火焰灼烧区域，不要傻傻地进去哦，自己也会被烧伤的。","season_review/s3/s3_fireball.png"},
	[905969685] = {905969685,2,8,"爆炸弓","新武器","ReviewIconS3_Bow","爆炸弓","新武器","咻~~Bomb！蓄力瞄准之后射出去，可以造成爆炸伤害哦。","season_review/s3/s3_bow.png"},
	[905969686] = {905969686,469762048,1,"实验室","新关卡","ReviewIconS4_ShiYanShi","实验室","新关卡","S4赛季沙谷傲博士的疯狂实验室基地，标志性的彩虹马建筑和各种科技秘密吸引着各路高手前往。","season_review/s4/s4_shiyanshi.png"},
	[905969687] = {905969687,469762048,3,"限时派对","新模式","ReviewIconS4_TimeLimitMode","限时派对","新模式","每隔一段时间就会上架新玩法，要记得常回来看看哦！","season_review/s4/s4_timelimitmode.png"},
	[905969688] = {905969688,469762048,8,"多人靶场","新玩法","ReviewIconS4_SausageClub","多人靶场","新玩法","终于可以和隔壁班的小伙伴一起愉快地打靶练枪玩道具了！我要开机甲~","season_review/s4/s4_sausageclub.png"},
	[905969689] = {905969689,469762048,6,"变形机甲","新载具","ReviewIconS4_Machine_Carrier","变形机甲MA-01","新载具","沙谷傲博士使用外星材料制造的变形机甲，不论是移动速度还是火力输出都首屈一指。","season_review/s4/s4_machine_carrier.png"},
	[905969690] = {905969690,469762048,2,"AK-12","新武器","ReviewIconS4_AK-12","AK-12","新武器","沙谷傲博士改造的突击步枪，一经面世就风靡香肠岛。","season_review/s4/s4_ak-12.png"},
	[905969691] = {905969691,469762048,7,"全息装置","新道具","ReviewIconS4_ARSuit","全息装置","新道具","沙谷傲博士研发的分身道具，穿上后变成小肠肠时就可以复制出2个全息分身，保命必备！","season_review/s4/s4_arsuit.png"},
	[905969692] = {905969692,469762048,4,"虫洞手雷","新道具","ReviewIconS4_ShiftDevice","虫洞手雷","新道具","沙谷傲博士研发的空间装置，使用后制造出2个可进行短距离传送的空间虫洞。","season_review/s4/s4_shiftdevice.png"},
	[905969693] = {905969693,469762048,5,"变大大","新道具","ReviewIconS4_Bigger","变大大","新道具","机械女仆打翻了博士的药剂，偶然培育出来的变异蘑菇，食用后可以变成双倍大的香肠人！","season_review/s4/s4_bigger.png"},
	[905969694] = {905969694,738197504,1,"影武者身份卡","新道具","ReviewIconS8_YingWuZhe","影武者身份卡","新道具","装备身份卡后可以获得影武者的技能，投掷钩爪、制造分身，超酷炫！","season_review/s8/s8_yingwuzhe.png"},
	[905969695] = {905969695,738197504,2,"甜心身份卡","新道具","ReviewIconS8_TianXin","甜心身份卡","新道具","装备身份卡后可以获得彩虹甜心的技能，治愈效果、复活队友，超实用！","season_review/s8/s8_tianxin.png"},
	[905969696] = {905969696,738197504,3,"P90","新武器","ReviewIconS8_P90","P90","新武器","拿上P90，冲就完事了~","season_review/s8/s8_p90.png"},
	[905969697] = {905969697,738197504,4,"废墟","新关卡","ReviewIconS8_FeiXu","废墟","新关卡","大战之后，一片狼藉，这里还会有什么东西留下来呢？","season_review/s8/s8_feixu.png"},
	[905969698] = {905969698,738197504,5,"奔跑吧！肠肠！","新玩法","ReviewIconS8_ChangChangPaoMode","奔跑吧！肠肠！","新玩法","24位肠肠，经过4轮关卡的重重筛选，决出前3，站上领奖台。像肠肠一样，奔跑吧！","season_review/s8/s8_changchangpaomode.png"},
}

local Keys = {738197504,738197505,738197506,738197507,738197508,738197509,738197510,738197511,738197512,738197513,738197514,738197515,738197516,738197517,738197518,738197519,738197520,905969664,905969665,905969666,905969667,905969668,905969669,905969670,905969671,905969672,905969673,905969674,905969675,905969676,905969677,905969678,905969679,905969680,905969681,905969682,905969683,905969684,905969685,905969686,905969687,905969688,905969689,905969690,905969691,905969692,905969693,905969694,905969695,905969696,905969697,905969698,}



local TrafficPermitSeasonDiscloseTableBase = {

    -- 记录数
	COUNT = 53,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	season_id = 2,
	show_order = 3,
	name = 4,
	type_name = 5,
	icon = 6,
	head = 7,
	sub_head = 8,
	describe = 9,
	pic_resource = 10,

    -- 标识常量
}

local languageColumns = {4, 5, 7, 8, 9}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return TrafficPermitSeasonDiscloseTableBase