local List0 = {
}

local Keys = {}



local TrafficPermitSeasonLimitActivityTableBase = {

    -- 记录数
	COUNT = 1,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	season_id = 2,
	period = 3,
	activity_id = 4,
	offset_days = 5,

    -- 标识常量
}



return TrafficPermitSeasonLimitActivityTableBase