local List0 = {
	[1] = {1,3,"S2","飞翔海盗团","S2",1,"s2",1},
	[2] = {2,4,"S3","香肠逗饿龙","S3",1,"s3",1},
	[234881024] = {234881024,2,"S1","皮皮马戏团","S1",1,"s1",1},
	[234881025] = {234881025,1,"热身","热身赛季","",0,"",0},
	[234881026] = {234881026,-1,"总","综合","",0,"",0},
	[469762048] = {469762048,5,"S4","疯狂实验室","S4",1,"s4",1},
	[503316480] = {503316480,6,"S5","YYY星人","S5",1,"s5",1},
	[738197504] = {738197504,9,"S8","游戏守护者","S8",1,"s8",1},
	[905969664] = {905969664,7,"S6","众神降临","S6",1,"s6",1},
	[905969665] = {905969665,10,"S9","银河战舰","S9",1,"s9",0},
	[1040187392] = {1040187392,8,"S7","胡闹三国","S7",1,"s7",1},
	[1040187393] = {1040187393,9,"T1","游戏守护者","T1",1,"T1",0},
	[1040187394] = {1040187394,10,"T2","银河战舰","T2",1,"T2",0},
}

local Keys = {1,2,234881024,234881025,234881026,469762048,503316480,738197504,905969664,905969665,1040187392,1040187393,1040187394,}



local TrafficPermitSeasonTableBase = {

    -- 记录数
	COUNT = 14,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	season = 2,
	name = 3,
	title = 4,
	icon = 5,
	is_use_traffic_permit = 6,
	show_pic_sign = 7,
	show_disclose = 8,

    -- 标识常量
}

local languageColumns = {3, 4}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return TrafficPermitSeasonTableBase