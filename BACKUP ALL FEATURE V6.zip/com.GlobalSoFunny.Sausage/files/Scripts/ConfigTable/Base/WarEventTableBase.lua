local List0 = {
	[1] = {1,"PickUP","扶人","成功扶触发","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0}"},
	[2] = {2,"GameOver","游戏结束","结算触发","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0,\"at\":0,\"r\":0,\"isfriend\":0,\"suit\":0,\"total_hurt\":0,\"group_info\":0,\"war_equip\":0,\"grade\":0,\"ndtl\":0,\"is_get_into_yscout\":0}"},
	[3] = {3,"AddHP","增加血量","增加血量触发","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"ahp\":0}"},
	[4] = {4,"UseItem","使用物品","每次使用物品触发","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0,\"itemid\":0,\"itemtype\":0,\"card1\":0,\"card2\":0,\"card3\":0,\"card4\":0,\"card5\":0}"},
	[5] = {5,"Move","移动","移动一定距离触发","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"movetype\":0,\"wd\":0,\"carrier_id\":0}"},
	[8] = {8,"Kill","击杀","击杀一个玩家触发","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0,\"weapon_type\":0,\"weapon\":0,\"kbh\":0,\"kb\":0,\"pte\":0,\"inwater\":0,\"bullet\":0,\"detonate_vehicle\":0,\"kill_distance\":0,\"kill_group\":0,\"in_sky\":0,\"on_ball\":0,\"is_change_role_size\":0}"},
	[9] = {9,"Dead","死亡","死亡触发","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"at\":0}"},
	[10] = {10,"GetItemFromBox","舔包","捡起玩家尸体或者空投","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0,\"boxt\":0,\"air_drop_box\":0}"},
	[11] = {11,"Hurt","伤害量","对敌方造成伤害","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"h\":0,\"hbh\":0,\"ht\":0,\"weapon_type\":0,\"weapon\":0,\"bullet\":0}"},
	[12] = {12,"Assists","助攻","助攻","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0}"},
	[13] = {13,"ConsumeBullet","消费子弹","消费子弹","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"cbid\":0,\"cbc\":0}"},
	[14] = {14,"UseAction","使用动作","使用动作","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0,\"action_type\":0,\"dance\":0,\"face\":0,\"group_cmd\":0,\"two_jump\":0}"},
	[15] = {15,"WarAliveCount","战场存活人数","战场存活人数",""},
	[16] = {16,"Jump","跳伞","跳伞","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0}"},
	[17] = {17,"Special","特殊","特殊行为","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0,\"use_airflow\":0,\"use_strop\":0,\"use_bobo\":0,\"destroy_bobo\":0,\"bobo_type\":0}"},
	[18] = {18,"TotalCollectItem","累计拾取物品","累计拾取物品","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"quality\":0,\"itemid\":0}"},
	[19] = {19,"DriveKill","驾驶击杀","驾驶击杀敌人","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"is_driver\":0,\"carrier_id\":0}"},
	[20] = {20,"DestroyCarrier","破坏载具","破坏载具","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"carrier_id\":0,\"is_ball\":0}"},
	[21] = {21,"DecItem","战场消耗大厅物品","消耗物品","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"item_count\":0,\"itemid\":0}"},
	[22] = {22,"WarPlayerStatusDetails","战场玩家状态详情","战场玩家状态详情",""},
	[23] = {23,"WatchCount","战场观战人数","战场观战人数",""},
	[24] = {24,"UnetReport","Unet举报","Unet举报",""},
	[25] = {25,"SyncUnetTeamPids","同步Unet队伍成员","同步Unet队伍成员",""},
	[26] = {26,"UnetCloseTeamMatch","unet关闭队伍匹配","unet关闭队伍匹配",""},
	[27] = {27,"PlayerExitWar","玩家退出战斗","玩家退出战斗",""},
	[28] = {28,"CustomRoomWarOver","自定义房间战斗结束","自定义房间战斗结束",""},
	[29] = {29,"PlayerLike","玩家点赞事件","玩家点赞事件",""},
	[30] = {30,"UnetUpdateClientType","Unet更新客户端类型","Unet更新客户端类型",""},
	[234881024] = {234881024,"KillStreak","连续击杀","连续击杀","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"max_kill_streak\":0}"},
	[234881025] = {234881025,"TeamKill","团队击杀","团队击杀","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"team_kill_count\":0}"},
	[234881026] = {234881026,"PartsKill","配件击杀","配件击杀","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"part1\":0,\"part2\":0,\"part3\":0,\"part4\":0,\"part5\":0}"},
	[234881027] = {234881027,"WeedOut","淘汰","淘汰","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0,\"weapon_type\":0,\"weapon\":0}"},
	[234881028] = {234881028,"UseCannon","使用传送大炮","使用传送大炮","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"coord\":0}"},
	[335544320] = {335544320,"CollectItem","拾取物品","拾取物品","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"collect_itemid\":0,\"is_sausage_baby\":0,\"itemtype\":0,\"card1\":0,\"card2\":0,\"card3\":0,\"card4\":0,\"card5\":0}"},
	[335544321] = {335544321,"Revive","复活","复活队友","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"man_count\":0}"},
	[503316480] = {503316480,"KillAppointObject","击杀指定对象","击杀指定对象","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"object_type\":0}"},
	[503316481] = {503316481,"AppointObjectHert","指定对象造成伤害","对指定对象造成伤害","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"object_type\":0,\"hurt\":0}"},
	[704643072] = {704643072,"UnetPIDLogin","unetPID登陆","unet玩家登陆同步",""},
	[704643073] = {704643073,"UnetPIDLogout","unetPID登出","unet玩家登出同步",""},
	[738197504] = {738197504,"OverCollectItem","结算拾取物品","结算时拾取物品","{\"mapmod\":0,\"groupmod\":0,\"gamemod\":0,\"showmod\":0,\"quality\":0,\"itemid\":0,\"item_count\":0}"},
	[1107296256] = {1107296256,"ClassicGameStart","经典战斗开始","经典类型起飞之前发消息",""},
	[1107296257] = {1107296257,"ClassicTeamExit","经典队伍退出","整个队伍退出发消息",""},
}

local Keys = {1,2,3,4,5,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,234881024,234881025,234881026,234881027,234881028,335544320,335544321,503316480,503316481,704643072,704643073,738197504,1107296256,1107296257,}



local WarEventTableBase = {

    -- 记录数
	COUNT = 43,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	sign = 2,
	name = 3,
	description = 4,
	json_format = 5,

    -- 标识常量
	["PickUP"] = "PickUP",
	["GameOver"] = "GameOver",
	["AddHP"] = "AddHP",
	["UseItem"] = "UseItem",
	["Move"] = "Move",
	["Kill"] = "Kill",
	["Dead"] = "Dead",
	["GetItemFromBox"] = "GetItemFromBox",
	["Hurt"] = "Hurt",
	["Assists"] = "Assists",
	["ConsumeBullet"] = "ConsumeBullet",
	["UseAction"] = "UseAction",
	["WarAliveCount"] = "WarAliveCount",
	["Jump"] = "Jump",
	["Special"] = "Special",
	["TotalCollectItem"] = "TotalCollectItem",
	["DriveKill"] = "DriveKill",
	["DestroyCarrier"] = "DestroyCarrier",
	["DecItem"] = "DecItem",
	["WarPlayerStatusDetails"] = "WarPlayerStatusDetails",
	["WatchCount"] = "WatchCount",
	["UnetReport"] = "UnetReport",
	["SyncUnetTeamPids"] = "SyncUnetTeamPids",
	["UnetCloseTeamMatch"] = "UnetCloseTeamMatch",
	["PlayerExitWar"] = "PlayerExitWar",
	["CustomRoomWarOver"] = "CustomRoomWarOver",
	["PlayerLike"] = "PlayerLike",
	["UnetUpdateClientType"] = "UnetUpdateClientType",
	["KillStreak"] = "KillStreak",
	["TeamKill"] = "TeamKill",
	["PartsKill"] = "PartsKill",
	["WeedOut"] = "WeedOut",
	["UseCannon"] = "UseCannon",
	["CollectItem"] = "CollectItem",
	["Revive"] = "Revive",
	["KillAppointObject"] = "KillAppointObject",
	["AppointObjectHert"] = "AppointObjectHert",
	["UnetPIDLogin"] = "UnetPIDLogin",
	["UnetPIDLogout"] = "UnetPIDLogout",
	["OverCollectItem"] = "OverCollectItem",
	["ClassicGameStart"] = "ClassicGameStart",
	["ClassicTeamExit"] = "ClassicTeamExit",
}



return WarEventTableBase