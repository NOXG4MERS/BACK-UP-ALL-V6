local List0 = {
	[1] = {1,"秀数据","ShowData",3},
	[2] = {2,"徽章","Badge",3},
	[3] = {3,"背景","InkPresenter",1},
	[4] = {4,"角色POSE","ShowPosture",1},
	[5] = {5,"开场表情","OpenFace",1},
	[6] = {6,"淘汰表情","EndFace",1},
}

local Keys = {1,2,3,4,5,6,}



local WarFlagInfoTypeTableBase = {

    -- 记录数
	COUNT = 7,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	count = 4,

    -- 标识常量
	["ShowData"] = "ShowData",
	["Badge"] = "Badge",
	["InkPresenter"] = "InkPresenter",
	["ShowPosture"] = "ShowPosture",
	["OpenFace"] = "OpenFace",
	["EndFace"] = "EndFace",
}

local languageColumns = {2}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return WarFlagInfoTypeTableBase