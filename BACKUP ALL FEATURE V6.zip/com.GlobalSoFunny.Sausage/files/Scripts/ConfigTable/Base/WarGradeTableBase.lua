local List0 = {
	[1] = {1,"B","B",0,19},
	[2] = {2,"B+","BPlus",20,34},
	[3] = {3,"A","A",35,44},
	[4] = {4,"A+","APlus",45,54},
	[5] = {5,"S","S",55,64},
	[6] = {6,"S+","SPlus",65,74},
	[7] = {7,"SS","SS",75,84},
	[8] = {8,"SS+","SSPlus",85,94},
	[9] = {9,"SSS","SSS",95,100},
}

local Keys = {1,2,3,4,5,6,7,8,9,}



local WarGradeTableBase = {

    -- 记录数
	COUNT = 10,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	grade_name = 2,
	sign = 3,
	min = 4,
	max = 5,

    -- 标识常量
	["B"] = "B",
	["BPlus"] = "BPlus",
	["A"] = "A",
	["APlus"] = "APlus",
	["S"] = "S",
	["SPlus"] = "SPlus",
	["SS"] = "SS",
	["SSPlus"] = "SSPlus",
	["SSS"] = "SSS",
}



return WarGradeTableBase