local BasicsShopTable = class({}, Assets.req("Scripts.ConfigTable.Base.BasicsShopTableBase"))
-- 通过 Id 得到内容
function BasicsShopTable:GetValueById (id)
	if self.List0[id] then
		return self.List0[id]
	end
	return nil
end

-- 通过 Id，字段 得到内容
function BasicsShopTable:GetSingleValue (id, fieldIndex)
	local value = self:GetValueById(id)
	if value and value[fieldIndex] then
		return value[fieldIndex]
	end
	return nil
end

-- 通过 字段 得到 Id
function BasicsShopTable:GetIdByFieldIndex (fieldIndex, value)
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			return k
		end
	end
	return nil
end

-- 通过 字段 得到 Ids
function BasicsShopTable:GetIdsByFieldIndex (fieldIndex, value)
	local idList = {}
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			idList[#idList + 1] = k
		end
	end
	return idList
end
--------------------------------------------自动生成--------------------------------------------

function BasicsShopTable:GetShopItems(argServerType)
	local items = {}
	if self.List2[argServerType] then
		for k, id in pairs(self.List2[argServerType]) do
			local item = {
				order = self:GetSingleValue(id, self.show_order),
				productID = self:GetSingleValue(id, self.product_id),
				diamond = self:GetSingleValue(id, self.diamond),
				sendDiamond = self:GetSingleValue(id, self.send_diamond)
			}
			table.insert(items, item)
		end
	end
	if #items > 0 then
		table.sort(items, function(lhs, rhs)
			return lhs.order < rhs.order
		end)
	end
	return items
end

return BasicsShopTable