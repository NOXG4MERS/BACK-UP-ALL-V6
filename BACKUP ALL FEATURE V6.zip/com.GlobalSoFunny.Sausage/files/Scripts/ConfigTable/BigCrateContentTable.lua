local BigCrateContentTable = class({}, Assets.req("Scripts.ConfigTable.Base.BigCrateContentTableBase"))
-- 通过 Id 得到内容
function BigCrateContentTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function BigCrateContentTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function BigCrateContentTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function BigCrateContentTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

local funReturnList = {}
function BigCrateContentTable:getItemByBoxID(argid, argCrateID)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.topic_id, argid)
    local showQualities = ConfigTable.BigCrateTable:GetShowQuality(argCrateID)

    for i = 1, #ids do
        local tempItemID = self:GetSingleValue(ids[i], self.get_item_id)
        local tempIsShow = true
        if next(showQualities) ~= nil then
            local tempQuality = ConfigTable.ItemTable:getQualtiyID(tempItemID)
            if not showQualities[tempQuality] then
                tempIsShow = false
            end
        end

        if tempIsShow then
            list[#list + 1] = {
                itemId = tempItemID,
                num = self:GetSingleValue(ids[i], self.item_num),
                showOrder = self:GetSingleValue(ids[i], self.show_order)
            }
        end
    end
    return list
end

function BigCrateContentTable:getAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = v[self.get_item_id],
            crateId = v[self.topic_id]
        }
    end
    return list
end

--用来处理物品的获得来源
function BigCrateContentTable:getItemAccess(argItemId, argTimeNow, argplatKey)
    local itemName = ""
    local itemDescription = ""
    if ConfigTable.ItemTable:GetValueById(argItemId) ~= nil then
        local itemSource = ConfigTable.ItemTable:GetItemDescription(argItemId)
        local itemTypeId = ConfigTable.ItemTable:GetValueById(argItemId)[ConfigTable.ItemTable.item_type_id]
        itemName = self:getItemTypeStr(argItemId, itemTypeId)
        if itemSource ~= "" then
            itemDescription = itemSource
        end
        if ConfigTable.ItemSourceTable:IsItemCustomSource(argItemId, ConfigTable:GetServerType()) then
            return string.concat(itemName, itemDescription)
        end
    end
    local isSuit = self:isItemSuit(argItemId)
    if not isSuit then
        local crateTypeRP = self:getCrateAccess(argItemId, argTimeNow, argplatKey)
        local crateTypeReturn = self:getReturnCrateAccess(argItemId)
        local crateTypeBasics, crateTypeSenior = self:getCrateTopicAccess(argItemId, argTimeNow)
        local crateTypeRainbow = self:getBigCrateContentAccess(argItemId, argTimeNow)
        if crateTypeRP and itemDescription ~= "" then
            itemDescription = itemDescription .. "," .. CS.Language.Get("Crate_5")
        elseif crateTypeRP and itemDescription == "" then
            itemDescription = itemDescription .. CS.Language.Get("Crate_5")
        end

        if crateTypeBasics and itemDescription ~= "" then
            itemDescription = itemDescription .. "," .. CS.Language.Get("Crate_6")
        elseif crateTypeBasics and itemDescription == "" then
            itemDescription = itemDescription .. CS.Language.Get("Crate_6")
        end

        if crateTypeSenior and itemDescription ~= "" then
            itemDescription = itemDescription .. "," .. CS.Language.Get("Crate_7")
        elseif crateTypeSenior and itemDescription == "" then
            itemDescription = itemDescription .. CS.Language.Get("Crate_7")
        end

        if crateTypeRainbow and itemDescription ~= "" then
            itemDescription = itemDescription .. "," .. CS.Language.Get("Crate_8")
        elseif crateTypeRainbow and itemDescription == "" then
            itemDescription = itemDescription .. CS.Language.Get("Crate_8")
        end
        if crateTypeReturn and itemDescription ~= "" then
            itemDescription = itemDescription .. "," .. CS.Language.Get("Crate_10")
        elseif crateTypeReturn and itemDescription == "" then
            itemDescription = itemDescription .. CS.Language.Get("Crate_10")
        end
    end

    if itemDescription == "" then
        itemDescription = CS.Language.Get("Crate_9")
    end

    local strText = itemName .. itemDescription
    return strText
end

--得到是否拥有缤纷补给箱的物品来源
function BigCrateContentTable:getCrateAccess(argItemId, argTimeNow, argplatKey)
    local isbool = false
    local tempNowTime = argTimeNow
    local isFirst = argplatKey == "first_test"

    local suitID = ConfigTable.SuitSetContentTable:getSuitId(argItemId)
    local primeCrateTopicContentSuitList = nil
    if suitID ~= nil then --如果该物品是套装部件再解析
        local suitItemID = ConfigTable.SuitSetTable:getSuitItemID(suitID)
        primeCrateTopicContentSuitList = ConfigTable.PrimeCrateTopicContentTable:getItemsByTypeId(suitItemID)
    end
    local PrimeCrateTopicContentList = ConfigTable.PrimeCrateTopicContentTable:getItemsByTypeId(argItemId)
    if primeCrateTopicContentSuitList ~= nil then
        for i = 1, #primeCrateTopicContentSuitList do
            table.insert(PrimeCrateTopicContentList, primeCrateTopicContentSuitList[i])
        end
    end
    if PrimeCrateTopicContentList ~= nil then
        for i = 1, #PrimeCrateTopicContentList do
            local PrimeCrateTopicContent = PrimeCrateTopicContentList[i]
            local crateId = PrimeCrateTopicContent
            local primeCrateList = ConfigTable.PrimeCrateTable:getSubjectType(crateId)
            --得到主题列表
            for i = 1, #primeCrateList do
                local primeCrate = primeCrateList[i] --得到主题ID
                local crateID = primeCrate[ConfigTable.PrimeCrateTable.crate_id]
                local timeRange = ConfigTable:GetTimeRange("PrimeCrateTimeTable", crateID)
                if timeRange and tempNowTime >= timeRange.startTime and tempNowTime <= timeRange.endTime then
                    isbool = true
                end
            end
        end
    end
    return isbool
end

--得到物品来源是否缤纷返场

function BigCrateContentTable:getReturnCrateAccess(argItemId)
    local isbool = false
    local suitID = ConfigTable.SuitSetContentTable:getSuitId(argItemId)
    local primeCrateTopicContentSuitList = nil
    if suitID ~= nil then --如果该物品是套装部件再解析
        local suitItemID = ConfigTable.SuitSetTable:getSuitItemID(suitID)
        primeCrateTopicContentSuitList = ConfigTable.PrimeCrateTopicContentTable:GetCrateID(suitItemID)
    end
    local PrimeCrateTopicContentList = ConfigTable.PrimeCrateTopicContentTable:getItemsByTypeId(argItemId)
    if primeCrateTopicContentSuitList ~= nil then
        for i = 1, #primeCrateTopicContentSuitList do
            table.insert(PrimeCrateTopicContentList, primeCrateTopicContentSuitList[i])
        end
    end

    local primeCrates = funReturnList
    if PrimeCrateTopicContentList ~= nil then
        for i = 1, #PrimeCrateTopicContentList do
            local crateId = PrimeCrateTopicContentList[i]
            for k = 1, #primeCrates do
                local returnCrateId = primeCrates[k].CrateId
                if returnCrateId == crateId then
                    isbool = true
                end
            end
        end
    end
    return isbool
end

function BigCrateContentTable:getFunReturnList(argFunReturn)
    funReturnList = {}
    if argFunReturn ~= nil then
        funReturnList = argFunReturn
    end
end

--获取物品是否有甜甜圈补给箱的来源
function BigCrateContentTable:getCrateTopicAccess(argItemId, argTimeNow)
    local isboolA = false
    local isboolB = false
    local tempNowTime = argTimeNow
    local quality = 0
    local suitID = ConfigTable.SuitSetContentTable:getSuitId(argItemId)
    local SuitList = nil
    if suitID ~= nil then --如果该物品是套装部件再解析
        local suitItemID = ConfigTable.SuitSetTable:getSuitItemID(suitID)
        SuitList = ConfigTable.CrateTopicContentTable:getItemsByTypeId(suitItemID)
    end
    if ConfigTable.ItemTable:GetValueById(argItemId) ~= nil then
        quality = ConfigTable.ItemTable:GetValueById(argItemId)[ConfigTable.ItemTable.item_quality_id]
    end
    local CrateTopicContentlist = ConfigTable.CrateTopicContentTable:getItemsByTypeId(argItemId)
    if SuitList ~= nil then --将套装添加到列表
        for i = 1, #SuitList do
            table.insert(CrateTopicContentlist, SuitList[i])
        end
    end
    if CrateTopicContentlist ~= nil then
        for i = 1, #CrateTopicContentlist do
            local CrateTopicContent = CrateTopicContentlist[i]
            local crateId = CrateTopicContent[ConfigTable.CrateTopicContentTable.crate_topic_id]
            local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", crateId)
            if timeRange and argTimeNow >= timeRange.startTime and argTimeNow <= timeRange.endTime then
                isboolA = true
            end
        end
    end
    if isboolA and quality >= 3 then
        isboolB = true
    end
    return isboolA, isboolB
end
--获取物品是否有大宝箱,彩虹补给箱的来源
function BigCrateContentTable:getBigCrateContentAccess(argItemId, argTimeNow)
    local isbool = false
    local tempNowTime = argTimeNow
    local suitID = ConfigTable.SuitSetContentTable:getSuitId(argItemId)
    local SuitList = nil
    if suitID ~= nil then --如果该物品是套装部件再解析
        local suitItemID = ConfigTable.SuitSetTable:getSuitItemID(suitID)
        SuitList = self:getItemsByTypeId(suitItemID)
    end
    local BigCrateContentTableList = self:getItemsByTypeId(argItemId)
    if SuitList ~= nil then --将套装添加到列表
        for i = 1, #SuitList do
            table.insert(BigCrateContentTableList, SuitList[i])
        end
    end
    if BigCrateContentTableList ~= nil then
        for i = 1, #BigCrateContentTableList do
            local bigCrateContent = BigCrateContentTableList[i]
            local topicID = bigCrateContent[self.topic_id]
            local timeRange = ConfigTable:GetTimeRange("BigCrateTopicTimeTable", topicID)
            if timeRange and argTimeNow >= timeRange.startTime and argTimeNow <= timeRange.endTime then
                isbool = true
            end
        end
    end
    return isbool
end

function BigCrateContentTable:getItemTypeStr(argItemID, argItemType)
    local typeName = ""
    if argItemType == 89 then
        typeName = CS.Language.Get("Crate_1")
    elseif argItemType == 94 then
        typeName = CS.Language.Get("Crate_2")
    elseif argItemType == 93 then
        typeName = CS.Language.Get("Crate_3")
    elseif argItemType == 92 then
    else
        local tempWardrobeTypeId = ConfigTable.ItemTable:getItemTypeId(argItemID)
        if
            tempWardrobeTypeId ~= 11 and tempWardrobeTypeId ~= 234881033 and tempWardrobeTypeId ~= 234881034 and tempWardrobeTypeId ~= 234881035 and tempWardrobeTypeId ~= 234881036 and
                tempWardrobeTypeId ~= 234881037
         then
            typeName = ConfigTable.ItemTypeTable:getName(tempWardrobeTypeId)
        end
    end
    if typeName ~= "" then
        typeName = typeName .. "-"
    end
    return typeName
end

--判断是否是套装
function BigCrateContentTable:isItemSuit(argItemId)
    local isSuit = false
    local tempWardrobeTypeId = ConfigTable.ItemTable:getItemTypeId(argItemId)
    local tempTypeSign = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
    local tempBigTypeSign = ConfigTable.ItemTypeTable:getAssembleId(tempWardrobeTypeId)
    if tempTypeSign == "SuitSet" then
        isSuit = true
    end
    return isSuit
end

function BigCrateContentTable:getItemsByTypeId(typeId) --根据物品ID获得
    local items = {}
    if self.List3[typeId] ~= nil then
        for i, id in ipairs(self.List3[typeId]) do
            items[i] = self:GetValueById(id)
        end
    end
    return items
end

return BigCrateContentTable
