local BigCrateTopicTable = class({}, Assets.req("Scripts.ConfigTable.Base.BigCrateTopicTableBase"))
-- 通过 Id 得到内容
function BigCrateTopicTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function BigCrateTopicTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function BigCrateTopicTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function BigCrateTopicTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function BigCrateTopicTable:GetAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        local topicId = k
        local timeConfig = ConfigTable:GetTimeRange("BigCrateTopicTimeTable", topicId)
        if timeConfig then
            list[k] = {
                startTime = timeConfig.startTime,
                endTime = timeConfig.endTime
            }
        end
    end
    return list
end

--得到当前主题
function BigCrateTopicTable:GetItemIDByTime(argTime)
    for k, v in pairs(self.List0) do
        local topicId = k
        local timeConfig = ConfigTable:GetTimeRange("BigCrateTopicTimeTable", topicId)
        if timeConfig and timeConfig.startTime <= argTime and timeConfig.endTime > argTime then
            return k
        end
    end
    return -1
end

function BigCrateTopicTable:GetItemIdsByTime(argTime)
    local list = {}
    for k, v in pairs(self.List0) do
        local topicId = k
        local timeRange = ConfigTable:GetTimeRange("BigCrateTopicTimeTable", topicId)
        if timeRange and timeRange.startTime <= argTime and timeRange.endTime > argTime then
            list[#list + 1] = {
                id = k,
                isNew = v[self.is_new],
                showSign = v[self.show_sign],
                crateTopicType = v[self.crate_topic_type]
            }
        end
    end

    return list
end

return BigCrateTopicTable
