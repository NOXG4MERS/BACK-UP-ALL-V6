local BigCrateTopicTimeTable = class({}, Assets.req("Scripts.ConfigTable.Base.BigCrateTopicTimeTableBase"))
-- 通过 Id 得到内容
function BigCrateTopicTimeTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function BigCrateTopicTimeTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function BigCrateTopicTimeTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function BigCrateTopicTimeTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function BigCrateTopicTimeTable:GetTimeRange(argTopicID, argServerType)
    if self.List2[argTopicID] then
        for k, id in pairs(self.List2[argTopicID]) do
            local serverType = self:GetSingleValue(id, self.server_type)
            if serverType == argServerType then
                local startTime = self:GetSingleValue(id, self.start_time)
                local endTime = self:GetSingleValue(id, self.end_time)
                return {startTime = startTime, endTime = endTime}
            end
        end
    end
    return nil
end

return BigCrateTopicTimeTable
