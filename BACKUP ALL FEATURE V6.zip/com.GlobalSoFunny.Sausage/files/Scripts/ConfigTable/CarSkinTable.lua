local CarSkinTable = class({}, Assets.req("Scripts.ConfigTable.Base.CarSkinTableBase"))
-- 通过 Id 得到内容
function CarSkinTable:GetValueById (id)
	if self.List0[id] then
		return self.List0[id]
	end
	return nil
end

-- 通过 Id，字段 得到内容
function CarSkinTable:GetSingleValue (id, fieldIndex)
	local value = self:GetValueById(id)
	if value and value[fieldIndex] then
		return value[fieldIndex]
	end
	return nil
end

-- 通过 字段 得到 Id
function CarSkinTable:GetIdByFieldIndex (fieldIndex, value)
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			return k
		end
	end
	return nil
end

-- 通过 字段 得到 Ids
function CarSkinTable:GetIdsByFieldIndex (fieldIndex, value)
	local idList = {}
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			idList[#idList + 1] = k
		end
	end
	return idList
end
--------------------------------------------自动生成--------------------------------------------
--得到全部的物品
function CarSkinTable:GetAllCarList()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {id = k, carID = v[self.car_item_id], skinCarID = v[self.skin_item_id]}
    end
    return list
end

function CarSkinTable:GetCarIdFormCarSkinId(argId)
    local id = self:GetIdByFieldIndex(self.skin_item_id, argId)
    if id then
        return self:GetSingleValue(id, self.car_item_id)
    end
    return -1
end


return CarSkinTable

