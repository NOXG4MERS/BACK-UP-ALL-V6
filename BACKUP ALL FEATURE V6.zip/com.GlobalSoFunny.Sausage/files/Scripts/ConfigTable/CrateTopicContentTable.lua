local CrateTopicContentTable = class({}, Assets.req("Scripts.ConfigTable.Base.CrateTopicContentTableBase"))
-- 通过 Id 得到内容
function CrateTopicContentTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function CrateTopicContentTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function CrateTopicContentTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function CrateTopicContentTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
-- 获取紫色品质以上的物品

function CrateTopicContentTable:getContentItem()
    local itemList = {}
    for k, v in pairs(self.List0) do
        local itemId = v[self.get_item_id]
        local quality = ConfigTable.ItemTable:getQualtiy(itemId)
        local typeId = ConfigTable.ItemTable:getItemTypeId(itemId)
        local mainClass = ConfigTable.ItemTypeTable:getAssembleId(typeId)
        local sign = ConfigTable.SysDictTable:getAssembleSign(mainClass)

        if (quality >= 3 and quality <= 5) or sign == "action" then
            local temp = {}
            temp.id = itemId
            temp.sign = sign
            table.insert(itemList, temp)
        end
    end
    return itemList
end

--得到对应品质和主题的参数
function CrateTopicContentTable:getContentQualityItem(argTopicId, argQuality)
    local itemList = {}
    for k, v in pairs(self.List0) do
        local itemId = v[self.get_item_id]
        local quality = ConfigTable.ItemTable:getQualtiy(itemId) + 1
        if quality == argQuality and argTopicId.Id == v[self.crate_topic_id] then
            local temp = {}
            temp.itemId = itemId
            temp.quality = argQuality
            temp.num = 1
            temp.crateTopicType = argTopicId.CrateTopicType
            itemList[#itemList + 1] = temp
        end
    end
    return itemList
end

function CrateTopicContentTable:getIdListBy(TopicId)
    local list = {}
    for k, v in pairs(self.List0) do
        if v[self.crate_topic_id] == TopicId then
            list[#list + 1] = v[self.get_item_id]
        end
    end
    return list
end

function CrateTopicContentTable:getTopicId(id)
    for k, v in pairs(self.List0) do
        if v[self.get_item_id] == id then
            return v[self.crate_topic_id]
        end
    end
    return 0
end

function CrateTopicContentTable:getAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = v[self.get_item_id],
            crateId = v[self.crate_topic_id]
        }
    end
    return list
end

function CrateTopicContentTable:getItemsByTypeId(typeId) --根据物品ID获得
    local items = {}
    if self.List3[typeId] ~= nil then
        for i, id in ipairs(self.List3[typeId]) do
            items[i] = self:GetValueById(id)
        end
    end
    return items
end

return CrateTopicContentTable
