local CrateTopicTable = class({}, Assets.req("Scripts.ConfigTable.Base.CrateTopicTableBase"))
-- 通过 Id 得到内容
function CrateTopicTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function CrateTopicTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function CrateTopicTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function CrateTopicTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local CrateTopicContentTable = Assets.req("Scripts.ConfigTable.CrateTopicContentTable")

local mt = {}

mt.__add = function(t1, t2)
    for k, v in pairs(t2) do
        table.insert(t1, v)
    end
    return t1
end

function CrateTopicTable:getAllTopicItem(nowSecond)
    local list = {}
    local tempContenlist = {}
    setmetatable(tempContenlist, mt)
    local topicContent = {}
    setmetatable(topicContent, mt)

    for k, v in pairs(self.List0) do
        local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", v[self.id])
        if timeRange then
            if timeRange.startTime == 0 and timeRange.endTime == 0 then
                list[#list + 1] = k
            else
                if timeRange.startTime <= nowSecond and timeRange.endTime >= nowSecond then
                    list[#list + 1] = k
                end
            end
        end
    end

    for i = 1, #list do
        topicContent = {}
        topicContent = CrateTopicContentTable:getIdListBy(list[i])
        tempContenlist = tempContenlist + topicContent
    end
    return tempContenlist
end

function CrateTopicTable:GetTopicIDsByTime(time)
    local ids = {}
    for k, v in pairs(self.List0) do
        local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", v[self.id])
        if timeRange and timeRange.startTime <= time and timeRange.endTime > time then
            table.insert(ids, {Id = k, CrateTopicType = v[self.crate_topic_type]})
        end
    end
    table.sort(
        ids,
        function(lhs, rhs)
            local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", lhs.Id)
            local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", rhs.Id)
            return timeRange.startTime < timeRange.startTime
        end
    )
    return ids
end

function CrateTopicTable:getAllTopicQualityItem(nowSecond, argQuality)
    local list = {}
    for k, v in pairs(self.List0) do
        local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", v[self.id])
        if timeRange and timeRange.startTime <= nowSecond and timeRange.endTime > nowSecond then
            local qualityList = CrateTopicContentTable:getContentQualityItem({Id = k, CrateTopicType = v[self.crate_topic_type]}, argQuality)
            for j = 1, #qualityList do
                list[#list + 1] = qualityList[j]
            end
        end
    end
    return list
end

function CrateTopicTable:getSign(id)
    return self:GetSingleValue(id, self.mark_sign)
end

function CrateTopicTable:getName(id)
    return self:GetSingleValue(id, self.name)
end

function CrateTopicTable:getStartTime(id)
    return self:GetSingleValue(id, self.start_time)
end

function CrateTopicTable:getAllTopicInfo(nowSecond)
    local list = {}
    for k, v in pairs(self.List0) do
        local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", v[self.id])
        if timeRange and timeRange.startTime <= nowSecond and timeRange.endTime >= nowSecond then
            list[#list + 1] = {
                id = k,
                name = v[self.name],
                sign = v[self.sign],
                startTime = timeRange.startTime,
                endTime = timeRange.endTime
            }
        end
    end
    return list
end

function CrateTopicTable:getAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        local timeRange = ConfigTable:GetTimeRange("CrateTopicTimeTable", v[self.id])
        if timeRange then
            list[k] = {
                startTime = timeRange.startTime,
                endTime = timeRange.endTime
            }
        end
    end
    return list
end

return CrateTopicTable
