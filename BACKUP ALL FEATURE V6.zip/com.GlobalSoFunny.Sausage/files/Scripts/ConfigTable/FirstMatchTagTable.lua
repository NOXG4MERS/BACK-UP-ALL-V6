local FirstMatchTagTable = class({}, Assets.req("Scripts.ConfigTable.Base.FirstMatchTagTableBase"))
-- 通过 Id 得到内容
function FirstMatchTagTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function FirstMatchTagTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function FirstMatchTagTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function FirstMatchTagTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function FirstMatchTagTable:GetAllTagConfig()
    local tempConfigs = {}
    for k, v in pairs(self.List0) do
        local tempConfig = {
            ID = v[self.id],
            Description = v[self.description],
            Position = v[self.show_pos],
            IconSign = v[self.resource_sign]
        }
        table.insert(tempConfigs, tempConfig)
    end

    local onSort = function(a, b)
        return a.Position < b.Position
    end
    table.sort(tempConfigs, onSort)

    return tempConfigs
end

function FirstMatchTagTable:GetTagConfig(argTagID)
    local tempID = self:GetIdByFieldIndex(self.id, argTagID)
    if tempID == nil then
        return nil
    end

    local tempConfig = {
        ID = self:GetSingleValue(tempID, self.id),
        Description = self:GetSingleValue(tempID, self.description),
        Position = self:GetSingleValue(tempID, self.show_pos),
        IconSign = self:GetSingleValue(tempID, self.resource_sign)
    }
    return tempConfig
end

return FirstMatchTagTable
