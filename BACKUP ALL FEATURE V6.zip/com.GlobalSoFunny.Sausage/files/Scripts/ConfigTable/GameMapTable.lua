local GameMapTable = class({}, Assets.req("Scripts.ConfigTable.Base.GameMapTableBase"))
-- 通过 Id 得到内容
function GameMapTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function GameMapTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function GameMapTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function GameMapTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function GameMapTable:getGameMod(argMatchMod)
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchMod)
    return self:GetSingleValue(id, self.game_mod)
end

function GameMapTable:getMapMod(argMatchMod)
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchMod)
    return self:GetSingleValue(id, self.map_mod)
end

function GameMapTable:getDataByMatchMode(argMatchMode)
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchMode)
    if id then
        local data = self:GetValueById(id)
        return {
            MatchMode = data[self.match_mod],
            GameMode = data[self.game_mod],
            MapMode = data[self.map_mod],
            ResSign = data[self.icon],
            ShowType = data[self.show_mode]
        }
    end
    return nil
end

function GameMapTable:getIconByMatchMode(argGameMode, argMapMod)
    if argMapMod == 0 then
        return self:getRandomIcon(argGameMode)
    else
        for k, v in pairs(self.List0) do
            if v[self.game_mod] == argGameMode and v[self.map_mod] == argMapMod then
                return v[self.icon]
            end
        end
    end
    return nil
end

--随机模式获得地图标识
function GameMapTable:getRandomIcon(argGameMode)
    if argGameMode == 1 then
        return "Entrance_ClassiBattle_ui"
    elseif argGameMode == 2 then
        return "Entrance_LaTale_ui"
    elseif argGameMode == 3 then
        return "Entrance_SportsCenter_ui"
    elseif argGameMode == 4 then
        return "Entrance_Sniping_ui"
    end
end

function GameMapTable:getMapModByGameMod(argGameMod)
    local list = {}
    for k, v in pairs(self.List0) do
        if v[self.game_mod] == argGameMod and v[self.show_mode] ~= 5 then
            list[#list + 1] = v[self.map_mod]
        end
    end
    return list
end

function GameMapTable:getShowType(argMatchMode)
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchMode)
    if id then
        return self:GetSingleValue(id, self.show_mode)
    end
    return 0
end

function GameMapTable:GetTargetMatchMode(argGameMode, argMapMode)
    local tempMatchMode = 0
    for k, v in pairs(self.List0) do
        if v[self.game_mod] == argGameMode and v[self.map_mod] == argMapMode then
            tempMatchMode = v[self.match_mod]
            break
        end
    end

    return tempMatchMode
end

function GameMapTable:GetShowGroup(argMatchmod)
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchmod)
    local showIndex = self:GetSingleValue(id, self.is_show_group)
    return showIndex == 1
end

function GameMapTable:GetHistoricalRecord(argMatchmod)
    local isShow = self:GetShowGroup(argMatchmod)
    local mapType = nil
    local mapName = nil
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchmod)
    local historyDescription = self:GetSingleValue(id, self.history_description)
    local stringList = string.split(historyDescription, ";")
    for i = 1, #stringList do
        local index = i
        local strName = stringList[index]
        if index == 1 then
            mapType = strName
        elseif index == 3 then
            mapName = strName
        end
    end
    local config = {mapType = mapType, mapName = mapName, isShow = isShow}
    return config
end

function GameMapTable:GetFriendsDescription(argMatchmod)
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchmod)
    local historyDescription = self:GetSingleValue(id, self.friends_description)
    return historyDescription
end

function GameMapTable:GetGameOverDescription(argMatchmod)
    local isShow = self:GetShowGroup(argMatchmod)
    local mapType = nil
    local mapName = nil
    local id = self:GetIdByFieldIndex(self.match_mod, argMatchmod)
    local gameOverDescription = self:GetSingleValue(id, self.game_over_description)
    local stringList = string.split(gameOverDescription, ";")
    for i = 1, #stringList do
        local index = i
        local strName = stringList[index]
        if index == 1 then
            mapType = string.gsub(strName, "{0}", "")
        elseif index == 2 then
            mapName = strName
        end
    end
    local config = {mapType = mapType, mapName = mapName, isShow = isShow}
    return config
end

return GameMapTable
