local GameSelectionConfigTable = class({}, Assets.req("Scripts.ConfigTable.Base.GameSelectionConfigTableBase"))
-- 通过 Id 得到内容
function GameSelectionConfigTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function GameSelectionConfigTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function GameSelectionConfigTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function GameSelectionConfigTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local GameMapTable = Assets.req("Scripts.ConfigTable.GameMapTable")

function GameSelectionConfigTable:GetMatchModeList(argGameSelectionID)
    local tempMatchModeList = {}
    local serverType = ConfigTable:GetServerType()

    for k, v in pairs(self.List0) do
        if v[self.game_selection_id] == argGameSelectionID and v[self.game_server_type] == serverType then
            local tempConfig = {}
            tempConfig["MatchMode"] = v[self.match_mode]
            tempConfig["RandomValue"] = v[self.random_value]
            table.insert(tempMatchModeList, tempConfig)
        end
    end

    return tempMatchModeList
end

function GameSelectionConfigTable:GetDefaultMatchMode(argGameSelectionID)
    local tempMatchMode = 0
    local tempMatchModeList = self:GetMatchModeList(argGameSelectionID)
    if #tempMatchModeList > 0 then
        tempMatchMode = tempMatchModeList[1].MatchMode
    end

    return tempMatchMode
end

function GameSelectionConfigTable:GetGameMode(argGameSelectionID)
    local tempGameMode = 0
    local tempMatchMode = self:GetDefaultMatchMode(argGameSelectionID)
    if tempMatchMode > 0 then
        tempGameMode = GameMapTable:getGameMod(tempMatchMode)
    end

    return tempGameMode
end

return GameSelectionConfigTable
