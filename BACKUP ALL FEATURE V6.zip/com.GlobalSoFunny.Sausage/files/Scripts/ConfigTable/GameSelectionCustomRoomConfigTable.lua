local GameSelectionCustomRoomConfigTable = class({}, Assets.req("Scripts.ConfigTable.Base.GameSelectionCustomRoomConfigTableBase"))
-- 通过 Id 得到内容
function GameSelectionCustomRoomConfigTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function GameSelectionCustomRoomConfigTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function GameSelectionCustomRoomConfigTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function GameSelectionCustomRoomConfigTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function GameSelectionCustomRoomConfigTable:GetInfo(argGameSelectionId)
    local list = {}
    local id = self:GetIdByFieldIndex(self.game_selection_id, argGameSelectionId)
    if id then
        local data = self:GetValueById(id)
        list = {
            minPlayer = data[self.min_player_count],
            maxPlayer = data[self.max_player_count],
            show = data[self.show],
            canWatch = data[self.can_watch] == 1
        }
    end
    return list
end

return GameSelectionCustomRoomConfigTable
