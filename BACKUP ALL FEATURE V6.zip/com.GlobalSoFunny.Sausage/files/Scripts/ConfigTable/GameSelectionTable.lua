local GameSelectionTable = class({}, Assets.req("Scripts.ConfigTable.Base.GameSelectionTableBase"))
-- 通过 Id 得到内容
function GameSelectionTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function GameSelectionTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function GameSelectionTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function GameSelectionTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function GameSelectionTable:GetShowType(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.show_mode)
end

function GameSelectionTable:GetSign(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.sign)
end

function GameSelectionTable:GetPosition(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.pos)
end

function GameSelectionTable:GetResources(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.resources)
end

function GameSelectionTable:GetDescription(argGameSelectionID)
    local tempData = self:GetSingleValue(argGameSelectionID, self.show_description)
    if tempData then
        local tempFormat = string.split(tempData, ";")
        return {
            condition1 = tempFormat[1],
            condition2 = tempFormat[2],
            condition3 = tempFormat[3],
            condition4 = tempFormat[4]
        }
    end
end

function GameSelectionTable:GetEnteranceName(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.enter_description)
end

function GameSelectionTable:GetGroupModeShowType(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.show_group_mode)
end

function GameSelectionTable:NeedShowRedPoint(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.is_red) == 1
end

function GameSelectionTable:GetRoomList()
    local list = {}

    for i = 1, #self.Keys do
        if self:GetSingleValue(self.Keys[i], self.is_custom_room_use) == 1 then
            local data = self:GetValueById(self.Keys[i])
            local roomInfoList = ConfigTable.GameSelectionCustomRoomConfigTable:GetInfo(self.Keys[i])
            list[#list + 1] = {
                id = self.Keys[i],
                name = data[self.enter_description],
                sign = data[self.resources],
                showMode = data[self.show_mode],
                minPlayer = roomInfoList.minPlayer,
                maxPlayer = roomInfoList.maxPlayer,
                showType = roomInfoList.show,
                canWatch = roomInfoList.canWatch
            }
        end
    end
    return list
end

function GameSelectionTable:GetResourceSign(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.resources)
end

function GameSelectionTable:GetFastDescription(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.fast_description)
end

function GameSelectionTable:IsGetGroupModeFromCache(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.client_save) == 1
end

function GameSelectionTable:GetDefaultGroupMode(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.default_group_mode)
end

function GameSelectionTable:IsCanChangeGroupMode(argGameSelectionID)
    return self:GetSingleValue(argGameSelectionID, self.change_group_mode) == 1
end

return GameSelectionTable
