local GunSizeTable = class({}, Assets.req("Scripts.ConfigTable.Base.GunSizeTableBase"))
-- 通过 Id 得到内容
function GunSizeTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function GunSizeTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function GunSizeTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function GunSizeTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
-- argIndex: 1:季票界面 2：季票总预览 3：宝箱预览
function GunSizeTable:getGunSize(argGunId)
    local id = self:GetIdByFieldIndex(self.gun_item_id, argGunId)
    if id then
        return self:GetSingleValue(id, self.size)
    end
    return nil
end

return GunSizeTable
