local GunSkinTable = class({}, Assets.req("Scripts.ConfigTable.Base.GunSkinTableBase"))
-- 通过 Id 得到内容
function GunSkinTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function GunSkinTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function GunSkinTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function GunSkinTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
--[[
    获得全部物品（除了部位占用的物品）
]]
function GunSkinTable:getAllGunSkinList()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = k,
            gunId = v[self.gun_item_id],
            gunSkinId = v[self.skin_item_id]
        }
    end
    return list
end

--查找皮肤id对应枪支id
function GunSkinTable:getGunIdFromGunSkinId(argSkinId)
    local id = self:GetIdByFieldIndex(self.skin_item_id, argSkinId)
    if id then
        return self:GetSingleValue(id, self.gun_item_id)
    end
    print("无法获取物品皮肤对应的物品 ：" .. argSkinId)
    return -1
end

--查找皮肤id对应主题
function GunSkinTable:getThemeIdById(argSkinId)
    local id = self:GetIdByFieldIndex(self.skin_item_id, argSkinId)
    if id then
        return self:GetSingleValue(id, self.theme)
    end
    return -1
end

--查找皮肤id对应战场Index
function GunSkinTable:getWarIndexBySkinId(argSkinId)
    return self:GetIdByFieldIndex(self.skin_item_id, argSkinId)
end

--是否是抢ID
function GunSkinTable:isGunSkinRed(argRedId)
    local id = self:GetIdByFieldIndex(self.red_point, argRedId)
    if id then
        return true
    end
    return false
end

--[[
    获得全部物品（战场测试工具用）
]]
function GunSkinTable:getAllSkinInfo()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            itemId = v[self.gun_item_id],
            skinId = v[self.skin_item_id]
        }
    end
    return list
end

function GunSkinTable:getGunIdBySkinId(argSkinId)
    local id = self:GetIdByFieldIndex(self.skin_item_id, argSkinId)
    if id then
        return self:GetSingleValue(id, self.gun_item_id)
    end
    return nil
end

function GunSkinTable:getAllGunSkins()
    local gunSkins = {}
    for gunId, ids in pairs(self.List2) do
        local data = ConfigTable.ItemTable:GetValueById(gunId)
        local gunSign = data[ConfigTable.ItemTable.res_sign]
        local typeId = data[ConfigTable.ItemTable.item_type_id]
        for i, id in ipairs(ids) do
            local gunData = self:GetValueById(id)
            table.insert(
                gunSkins,
                {
                    id = id,
                    itemId = self:GetSingleValue(id, self.skin_item_id),
                    gunId = gunId,
                    gunSign = gunSign,
                    typeId = typeId,
                    skinName = ConfigTable.ItemTable.List0[gunData[self.skin_item_id]][ConfigTable.ItemTable.name],
                    skinSign = ConfigTable.ItemTable.List0[gunData[self.skin_item_id]][ConfigTable.ItemTable.res_sign]
                }
            )
        end
    end
    return gunSkins
end

return GunSkinTable
