local IconSortTable = class({}, Assets.req("Scripts.ConfigTable.Base.IconSortTableBase"))
-- 通过 Id 得到内容
function IconSortTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function IconSortTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function IconSortTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function IconSortTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
--[[
    获得限时时间
]]
function IconSortTable:getUnLockPor(level)
    for k, v in pairs(self.List0) do
        if v[self.level] == level and v[self.is_level_unlock] then
            return v[self.item_id]
        end
    end
    return -1
end

--[[
    获得上一个解锁头像
]]
function IconSortTable:getNextUnLockPor(level)
    local targetlevel = 0
    local id = 0
    for k, v in pairs(self.List0) do
        if v[self.level] <= level and v[self.is_level_unlock] == 1 and v[self.level] >= targetlevel then
            targetlevel = v[self.level]
            id = k
        end
    end
    local list = {level = targetlevel, itemId = self:GetSingleValue(id, self.item_id)}
    return list
end

function IconSortTable:getUnLockLevel(id)
    for k, v in pairs(self.List0) do
        if v[self.item_id] == id and v[self.is_level_unlock] == 1 then
            return v[self.level]
        end
    end
    return -1
end

--[[
    获得排序
]]
function IconSortTable:getSort(id)
    local id = self:GetIdByFieldIndex(self.item_id, id)
    if id then
        return self:GetSingleValue(id, self.item_sort)
    end
    return -1
end

return IconSortTable
