local ItemRelationPostureTable = class({}, Assets.req("Scripts.ConfigTable.Base.ItemRelationPostureTableBase"))
-- 通过 Id 得到内容
function ItemRelationPostureTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ItemRelationPostureTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ItemRelationPostureTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ItemRelationPostureTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function ItemRelationPostureTable:GetAllItemId()
    local itemDic = {}
    for k, v in pairs(self.List0) do
        local itemId = v[self.item_id]
        if not itemDic[itemId] then
            itemDic[itemId] = itemId
        end
    end
    return itemDic
end

function ItemRelationPostureTable:GetTypeItem(argType)
    local list = {}
    for k, v in pairs(self.List0) do
        local type = v[self.relation_type]
        if type == argType or type == 0 then
            list[#list + 1] = {itemId = v[self.item_id], type = v[self.relation_type], unlockRelationValue = v[self.unlock_relation_value]}
        end
    end
    return list
end

return ItemRelationPostureTable
