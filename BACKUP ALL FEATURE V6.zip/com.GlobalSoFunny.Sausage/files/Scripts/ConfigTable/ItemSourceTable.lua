local ItemSourceTable = class({}, Assets.req("Scripts.ConfigTable.Base.ItemSourceTableBase"))
-- 通过 Id 得到内容
function ItemSourceTable:GetValueById (id)
	if self.List0[id] then
		return self.List0[id]
	end
	return nil
end

-- 通过 Id，字段 得到内容
function ItemSourceTable:GetSingleValue (id, fieldIndex)
	local value = self:GetValueById(id)
	if value and value[fieldIndex] then
		return value[fieldIndex]
	end
	return nil
end

-- 通过 字段 得到 Id
function ItemSourceTable:GetIdByFieldIndex (fieldIndex, value)
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			return k
		end
	end
	return nil
end

-- 通过 字段 得到 Ids
function ItemSourceTable:GetIdsByFieldIndex (fieldIndex, value)
	local idList = {}
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			idList[#idList + 1] = k
		end
	end
	return idList
end
--------------------------------------------自动生成--------------------------------------------

function ItemSourceTable:GetItemDescription(argItemID, argServerType)
    if self.List2[argItemID] then
        for k, id in pairs(self.List2[argItemID]) do
            local serverType = self:GetSingleValue(id, self.server_type)
            if argServerType == serverType then
                return self:GetSingleValue(id, self.source)
            end
        end
    end
    return nil
end

function ItemSourceTable:IsItemCustomSource(argItemID, argServerType)
	if self.List2[argItemID] then
        for k, id in pairs(self.List2[argItemID]) do
            local serverType = self:GetSingleValue(id, self.server_type)
            if argServerType == serverType then
                return true
            end
        end
    end
	return false
end

return ItemSourceTable