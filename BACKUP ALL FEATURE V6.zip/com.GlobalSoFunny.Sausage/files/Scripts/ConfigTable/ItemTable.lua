local ItemTable = class({}, Assets.req("Scripts.ConfigTable.Base.ItemTableBase"))
-- 通过 Id 得到内容
function ItemTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ItemTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ItemTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ItemTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function ItemTable:getIdListBy(itemTypeId)
    local list = self:GetIdsByFieldIndex(self.item_type_id, itemTypeId)
    table.sort(
        list,
        function(a, b)
            local qualtitA = self:getQualtiy(a)
            local qualtitB = self:getQualtiy(b)
            return qualtitA > qualtitB
        end
    )
    return list
end

--[[
    获得初始装备
]]
function ItemTable:getInitEquipIds()
    local list = {}
    for k, v in pairs(self.List0) do
        if v[self.is_init_equip] == 1 and v[self.is_init] == 1 then
            list[#list + 1] = k
            print(self:getName(list[#list]))
        end
    end
    return list
end

--[[
    获得初始装备
]]
local fScopeSigns = {}
function ItemTable:getIdBySign(argSign, argType)
    if fScopeSigns[argSign] then
        return fScopeSigns[argSign]
    end
    local list = {}
    for k, v in pairs(self.List0) do
        if not argType then
            local tempSign = v[self.sign]
            if tempSign == argSign then
                local temnId = k
                fScopeSigns[tempSign] = temnId
                return temnId
            end
        else
            if v[self.item_type_id] == argType then
                local tempSign = v[self.sign]
                if tempSign == argSign then
                    local temnId = k
                    fScopeSigns[tempSign] = temnId
                    return temnId
                end
            end
        end
    end
    return 0
end

--[[
    获得默认装备
]]
function ItemTable:getDefaultIds()
    return self:GetIdsByFieldIndex(self.is_def, 1)
end

--[[
    获得初始装备
]]
function ItemTable:getInitIds()
    return self:GetIdsByFieldIndex(self.is_init, 1)
end

function ItemTable:getItemIdBySign(argSign)
    local value = {}
    for i = 1, #self.Keys do
        value = self:GetValueById(self.Keys[i])
        if value[self.res_sign] == argSign then
            return self.Keys[i]
        end
    end
    return 0
end

--[[
    获得全部物品（除了部位占用的物品）
]]
function ItemTable:getAllItemId()
    return self:GetIdsByFieldIndex(self.item_id, 0)
end

--[[
    获得所有气泡
]]
function ItemTable:getAllExpressionId()
    return self:GetIdsByFieldIndex(self.item_type_id, 234881024)
end

--[[
    获得所有动作
]]
function ItemTable:getAllActionId()
    local list = {}
    for k, v in pairs(self.List0) do
        if v[self.item_type_id] == 86 or v[self.item_type_id] == 234881025 then
            list[#list + 1] = k
        end
    end
    return list
end

--[[
    获得物品描述
]]
--现已弃用该方法2019/10/31
function ItemTable:GetItemDescription(id)
    local source = ConfigTable.ItemSourceTable:GetItemDescription(id, ConfigTable:GetServerType())
    if source then
        return source
    end
    source = self:GetSingleValue(id, self.source)
    return source
end

--[[
    获得限时时间
]]
function ItemTable:getItemLimitTime(id)
    return self:GetSingleValue(id, self.limit_time)
end

--宝箱类型id
function ItemTable:getCrateTypeID(id)
    return self:GetSingleValue(id, self.item_crate_type_id)
end

function ItemTable:getSign(id)
    return self:GetSingleValue(id, self.res_sign)
end

function ItemTable:getSignForOnly(id)
    return self:GetSingleValue(id, self.sign)
end

function ItemTable:getName(id)
    return self:GetSingleValue(id, self.show_name)
end

function ItemTable:getNameBySign(argSign)
    local id = self:GetIdByFieldIndex(self.sign, argSign)
    if id then
        return self:GetSingleValue(id, self.show_name)
    end
    return ""
end

function ItemTable:getQualtiy(id)
    local qualtiyID = self:GetSingleValue(id, self.item_quality_id)
    if qualtiyID == 234881024 then
        return 0
    end
    if not qualtiyID then
        return 0
    end
    return qualtiyID - 1
end

function ItemTable:getQualtiyID(id)
    return self:GetSingleValue(id, self.item_quality_id)
end

function ItemTable:getItemTypeId(id)
    return self:GetSingleValue(id, self.item_type_id)
end

--是否是消耗物品
function ItemTable:getItemConsume(id)
    local itemTypeId = self:getItemTypeId(id)
    local itemType = ConfigTable.ItemTypeTable:getSign(itemTypeId)
    local tempBigTypeSign = ConfigTable.ItemTypeTable:getAssembleId(itemTypeId)
    local sysTypeSign = ConfigTable.SysDictTable:getAssembleSign(tempBigTypeSign)
    if
        sysTypeSign == ConfigTable.SysDictTable.crate or itemType == ConfigTable.ItemTypeTable.Gold or itemType == ConfigTable.ItemTypeTable.Money or itemType == ConfigTable.ItemTypeTable.Score or itemType == ConfigTable.ItemTypeTable.Currency or
            itemType == ConfigTable.ItemTypeTable.Diamond or
            itemType == ConfigTable.ItemTypeTable.UseableItem or
            itemType == ConfigTable.ItemTypeTable.JokerItem or
            itemType == ConfigTable.ItemTypeTable.TrafficPermit or
            itemType == ConfigTable.ItemTypeTable.Medal or
            itemType == ConfigTable.ItemTypeTable.DiamondCandy or
            itemType == ConfigTable.ItemTypeTable.RelationGift or
            itemType == ConfigTable.ItemTypeTable.CustomMatchCard
     then
        return true
    end
    return false
end

function ItemTable:IsCrateByItemId(id)
    local isCrate = false
    local itemTypeID = self:getItemTypeId(id)
    local tempBigTypeSign = ConfigTable.ItemTypeTable:getAssembleId(itemTypeID)
    local sysTypeSign = ConfigTable.SysDictTable:getAssembleSign(tempBigTypeSign)
    if sysTypeSign == ConfigTable.SysDictTable.crate then
        isCrate = true
    end
    return isCrate
end

function ItemTable:getExchangeMoney(id)
    return self:GetSingleValue(id, self.exchange_money)
end

function ItemTable:getQualtiyColor(qualtiy)
    local color = nil
    if qualtiy == 0 then
        color = UnityEngine.Color(232 / 255, 232 / 255, 232 / 255)
    elseif qualtiy == 1 then
        color = UnityEngine.Color(190 / 255, 240 / 255, 193 / 255)
    elseif qualtiy == 2 then
        color = UnityEngine.Color(178 / 255, 235 / 255, 246 / 255)
    elseif qualtiy == 3 then
        color = UnityEngine.Color(228 / 255, 193 / 255, 246 / 255)
    elseif qualtiy == 4 then
        color = UnityEngine.Color(255 / 255, 233 / 255, 170 / 255)
    elseif qualtiy == 5 then
        color = UnityEngine.Color(255 / 255, 181 / 255, 179 / 255)
    end
    return color
end

local OccupyPart = {}
function ItemTable:getOccupyPart(id)
    if OccupyPart[id] then
        return OccupyPart[id]
    end
    local list = self:GetIdsByFieldIndex(self.item_id, id)
    OccupyPart[id] = list
    return list
end

function ItemTable:GetIconKey(itemType, argSign, argIsAppearanceGunItem)
    if argIsAppearanceGunItem then
        return string.concat("Weapon_", argSign)
    end
    local tempBigTypeSign = ConfigTable.ItemTypeTable:getAssemBySign(itemType)
    local itemAssembleSign = ConfigTable.SysDictTable:getAssembleSign(tempBigTypeSign)
    if argSign == nil or argSign == "" then
        return nil
    end
    if itemType == ConfigTable.ItemTypeTable.Suit then -- 套件
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Complexion then --肤色
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Countenance then --表情
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Hair then --头部
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.FaceDecoration then --面部装饰
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Shirt then --上装
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Coat then --外套
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.HandDecorated then --手部
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Bottoms then --下装
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Shoe then --脚部
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Gold then --金币
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.CustomMatchCard then --房间卡
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.Diamond then --钻石
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.Money then --点券
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.Currency then --活跃度
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.DiamondCandy then --钻石糖
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.Bubble then --气泡
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Dance then --动作
        return string.concat("Appearance_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.Posture then --动作
        return string.concat("Appearance_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.Portrait then --动作
        return argSign
    elseif itemAssembleSign == ConfigTable.SysDictTable.crate or itemType == ConfigTable.ItemTypeTable.ComposeProduct then
        return string.concat("Appearance_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.InkPresenter then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.ShowPosture then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.ShowWarData then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.GunSkin or itemType == ConfigTable.ItemTypeTable.MeleeWeaponSkin then
        return string.concat("Crate_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.Looser then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.SuitSet then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Medal then --通行证勋章
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.BadgeOfLevel then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.BadgeOfScore then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.BadgeOfPeak then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.JokerItem then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.Aerocraft then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.XCCSkin then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.TrafficPermit then
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.UseableItem then
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.CustomMatchCard then
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.RelationGift then
        return string.concat("Common_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.BackpackSkin then
        return argSign
    elseif itemType == ConfigTable.ItemTypeTable.GunSkin then
        return string.concat("Appearance_", argSign)
    elseif itemType == ConfigTable.ItemTypeTable.CarSkin then
        return string.concat("Crate_", argSign)
    else -- 武器装备
        return string.concat("Item_", argSign)
    end
    return nil
end

--返回部位权重
function ItemTable:ReturnWeight(id)
    local wardrobeTypeId = self:getItemTypeId(id)
    return ConfigTable.ItemTypeTable:ReturnWeight(wardrobeTypeId)
end

-- 所有头像
function ItemTable:getPortraitList()
    return self:GetIdsByFieldIndex(self.item_type_id, 33554432)
end

-- 勋章解析
function ItemTable:getBadgeSignAndQualityById(argId, argNum)
    local tempWardrobeTypeId = self:getItemTypeId(argId)
    local tempTypeSign = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
    local tempItemSign = self:getSign(argId)
    local tempItemQuality = 0

    if tempTypeSign == ConfigTable.ItemTypeTable.BadgeOfAchievement then --成就勋章
        tempItemSign = tempItemSign .. argNum
        tempItemQuality = ConfigTable.AchievementStarQualityTable:getQuality(argNum)
    elseif tempTypeSign == ConfigTable.ItemTypeTable.BadgeOfLevel then --等级勋章
        tempItemSign, tempItemQuality = ConfigTable.BadgeOfLevelTable:getSignAndQuality(argNum)
    elseif tempTypeSign == ConfigTable.ItemTypeTable.BadgeOfScore then --段位勋章
        tempItemSign, tempItemQuality = ConfigTable.BadgeOfScoreTable:getSignAndQuality(argNum)
    elseif tempTypeSign == ConfigTable.ItemTypeTable.BadgeOfPeak then --段位勋章
        tempItemQuality = self:getQualtiy(argId)
    end
    return tempItemSign, tempItemQuality
end

--item获得图集
function ItemTable:setSprite(image, argItemId, nativeSize, argNum)
    local tempSign = self:getSign(argItemId)
    local tempWardrobeTypeId = self:getItemTypeId(argItemId)
    local tempTypeSign = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
    local iconKey = self:GetIconKey(tempTypeSign, tempSign)
    --钥匙处理
    if tempTypeSign == ConfigTable.ItemTypeTable.DiamondCandy then
        iconKey = self:GetDiamondCandySign(argItemId, argNum)
    end

    if nativeSize == nil then
        nativeSize = false
    end

    if tempWardrobeTypeId == 15 then
        image:SetSprite(string.concat("Common_", tempSign), nativeSize)
    else
        image:SetSprite(iconKey, nativeSize)
    end
end

-- 根据唯一标识获取物品Id
local fScopeUniqueSigns = {}
function ItemTable:getIdByUniqueSign(argSign)
    if fScopeUniqueSigns[argSign] then
        return fScopeUniqueSigns[argSign]
    end
    local list = {}
    for k, v in pairs(self.List0) do
        if v[self.sign] == argSign then
            fScopeUniqueSigns[argSign] = k
            return k
        end
    end
    return 0
end

--获取类型物品
function ItemTable:getItemsByType(argType)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.item_type_id, argType)
    for i = 1, #ids do
        local tempSign = self:getSign(ids[i])
        if not string.find(tempSign, "Lv4") then
            list[#list + 1] = ids[i]
        end
    end
    return list
end

--枪械排序
function ItemTable:ReturnWeightBySign(argId)
    local tempSign = self:getSignForOnly(argId)
    local weight = 0
    if tempSign == self.WarItemM416 then
        weight = 0
    elseif tempSign == self.WarItemAKM then
        weight = 10
    elseif tempSign == self.WarItemSCARL then
        weight = 20
    elseif tempSign == self.WarItemM16A4 then
        weight = 30
    elseif tempSign == self.WarItemAUG then
        weight = 40
    elseif tempSign == self.WarItemGroza then
        weight = 50
    elseif tempSign == self.WarItemKar98 then
        weight = 60
    elseif tempSign == self.WarItemM24 then
        weight = 70
    elseif tempSign == self.WarItemAWM then
        weight = 80
    elseif tempSign == self.WarItemSKS then
        weight = 90
    elseif tempSign == self.WarItemMini14 then
        weight = 100
    elseif tempSign == self.WarItemVSS then
        weight = 110
    elseif tempSign == self.WarItemMK14 then
        weight = 120
    elseif tempSign == self.WarItemSLR then
        weight = 130
    elseif tempSign == self.WarItemUMP9 then
        weight = 140
    elseif tempSign == self.WarItemTommyGun then
        weight = 150
    elseif tempSign == self.WarItemVector then
        weight = 160
    elseif tempSign == self.WarItemMicroUZI then
        weight = 170
    elseif tempSign == self.WarItemS686 then
        weight = 180
    elseif tempSign == self.WarItemS1897 then
        weight = 190
    elseif tempSign == self.WarItemS12K then
        weight = 200
    elseif tempSign == self.WarItemKSG then
        weight = 210
    elseif tempSign == self["WarItemDP-28"] then
        weight = 220
    elseif tempSign == self.WarItemM249 then
        weight = 230
    elseif tempSign == self.WarItemMinigun then
        weight = 240
    end
    return weight
end

function ItemTable:getResSignByID(argItemID)
    if not self.itemResSignCache then
        self.itemResSignCache = {}
    end

    if self.itemResSignCache[argItemID] then
        return self.itemResSignCache[argItemID]
    end
    self.itemResSignCache[argItemID] = self:GetSingleValue(argItemID, self.sign)
    return self.itemResSignCache[argItemID]
end

--获取仓库的列表数据根据物品类型进行分类
function ItemTable:ItemTableSort(argCallBack)
    self.allContentList = {}
    for k, v in pairs(self.List0) do
        local getItemIdIndex = v[self.item_id]
        if getItemIdIndex == 0 then
            local itemId = k
            local tempWardrobeTypeId = v[self.item_type_id]
            local tempTypeSign = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
            local tempAssembleId = ConfigTable.ItemTypeTable:getAssembleId(tempWardrobeTypeId)
            local tempAssembleSign = ConfigTable.SysDictTable:getAssembleSign(tempAssembleId)
            if tempTypeSign == ConfigTable.ItemTypeTable.ShowPosture then
                tempAssembleSign = ConfigTable.ItemTypeTable.ShowPosture
            elseif tempTypeSign == ConfigTable.ItemTypeTable.InkPresenter then
                tempAssembleSign = ConfigTable.ItemTypeTable.InkPresenter
            elseif tempTypeSign == ConfigTable.ItemTypeTable.XCCSkin then
                tempAssembleSign = ConfigTable.ItemTypeTable.XCCSkin
            end
            if tempAssembleSign ~= ConfigTable.SysDictTable.war_item and tempAssembleSign ~= ConfigTable.SysDictTable.war_useable_item then
                local limitTime = v[self.limit_time]
                if ConfigTable.ItemTypeTable:getIsEquip(tempWardrobeTypeId) == 0 then
                    if limitTime == 0 and tempAssembleSign ~= "None" then
                        if self.allContentList[tempAssembleSign] == nil then
                            self.allContentList[tempAssembleSign] = {}
                        end
                        if self.allContentList[tempTypeSign] == nil then
                            self.allContentList[tempTypeSign] = {}
                        end
                        if tempAssembleSign == ConfigTable.SysDictTable.badge then
                            local tempAchievementId = ConfigTable.BadgeOfAchievementTable:getAchievementId(itemId)
                            if tempAchievementId ~= -1 then
                                local tempAchievemenData = ConfigTable.AchievementTable:getItemByAchievementId(tempAchievementId)
                                if tempAchievemenData.IsExtinct then
                                    -- local tempItemInfo = self._data.ItemData:getItem(itemId)
                                    -- if tempItemInfo then
                                    --     if tempTypeSign == tempAssembleSign then
                                    --         table.insert(self.allContentList[tempTypeSign], {id = itemId})
                                    --     else
                                    --         table.insert(self.allContentList[tempTypeSign], {id = itemId})
                                    --         table.insert(self.allContentList[tempAssembleSign], {id = itemId})
                                    --     end
                                    -- end
                                else
                                    if tempTypeSign ~= tempAssembleSign then
                                        table.insert(self.allContentList[tempAssembleSign], {id = itemId})
                                    end
                                    table.insert(self.allContentList[tempTypeSign], {id = itemId})
                                end
                            else
                                if tempTypeSign ~= tempAssembleSign then
                                    table.insert(self.allContentList[tempAssembleSign], {id = itemId})
                                end
                                table.insert(self.allContentList[tempTypeSign], {id = itemId})
                            end
                        else
                            if tempTypeSign ~= tempAssembleSign then
                                table.insert(self.allContentList[tempAssembleSign], {id = itemId})
                            end
                            table.insert(self.allContentList[tempTypeSign], {id = itemId})
                        end
                    end
                end
            end
        end
    end
    if argCallBack then
        argCallBack()
    end
end

--获取物品装备的类型的位置

function ItemTable:wardobePopupItemType(argItemId)
    local type = -1
    local tempWardrobeTypeId = ConfigTable.ItemTable:getItemTypeId(argItemId)
    local tempTypeSign = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
    if tempTypeSign == ConfigTable.ItemTypeTable.Suit then -- 套件
        type = -1
    elseif tempTypeSign == ConfigTable.ItemTypeTable.Complexion then --肤色
        type = -1
    elseif tempTypeSign == ConfigTable.ItemTypeTable.Countenance then --表情
        type = -1
    elseif tempTypeSign == ConfigTable.ItemTypeTable.Hair then --头部
        type = 1
    elseif tempTypeSign == ConfigTable.ItemTypeTable.FaceDecoration then --面部装饰
        type = 2
    elseif tempTypeSign == ConfigTable.ItemTypeTable.Shirt then --上装
        type = 4
    elseif tempTypeSign == ConfigTable.ItemTypeTable.Coat then --外套
        type = 5
    elseif tempTypeSign == ConfigTable.ItemTypeTable.HandDecorated then --手部
        type = 6
    elseif tempTypeSign == ConfigTable.ItemTypeTable.Bottoms then --下装
        type = 7
    elseif tempTypeSign == ConfigTable.ItemTypeTable.Shoe then --脚部
        type = 8
    else
        type = -1
    end
    return type
end

function ItemTable:getBigint(argItemId)
    return self:GetSingleValue(argItemId, self.delicious_value)
end

--通过ID得到美味值
function ItemTable:getBigintByID(id)
    local deliciousValue = self:GetSingleValue(id, self.delicious_value)
    if deliciousValue == nil or deliciousValue == 0 then
        if deliciousValue == 0 then
            local itemTypeId = self:getItemTypeId(id)
            local qualtiy = self:getQualtiyID(id)
            deliciousValue = ConfigTable.ItemDeliciousTable:GetDelicious(itemTypeId, qualtiy)
        else
            deliciousValue = 0
        end
    elseif deliciousValue < 0 then
        deliciousValue = 0
    end
    return deliciousValue
end

function ItemTable:equipmentOccupation(argList, argId, argTypeSign) --装备占用
    local list = argList
    if argTypeSign and argId then
        if argTypeSign == "Suit" then
            local tempOccupyList = self:getOccupyPart(argId)
            for i = 1, #tempOccupyList do
                local tempWardrobeTypeId = self:getItemTypeId(tempOccupyList[i])
                local tempType = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
                list[tempType] = -1
            end
        end
    elseif list["Suit"] ~= -1 then
        local tempOccupyList = self:getOccupyPart(list["Suit"])
        for i = 1, #tempOccupyList do
            local tempWardrobeTypeId = self:getItemTypeId(tempOccupyList[i])
            local tempType = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
            if tempType == argTypeSign then
                list["Suit"] = -1
            end
        end
    end

    return list
end

function ItemTable:gearTryOn(argItemList, arglist) --装备试穿
    local list = arglist
    if list then
        for k, v in pairs(list) do
            if argItemList[k] ~= nil then
                list[k] = argItemList[k]
                if k == "Suit" then
                    local tempOccupyList = self:getOccupyPart(argItemList[k])
                    for i = 1, #tempOccupyList do
                        local tempWardrobeTypeId = self:getItemTypeId(tempOccupyList[i])
                        local tempType = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
                        list[tempType] = -1
                    end
                elseif list["Suit"] ~= -1 then
                    local tempOccupyList = self:getOccupyPart(list["Suit"])
                    for i = 1, #tempOccupyList do
                        local tempWardrobeTypeId = self:getItemTypeId(tempOccupyList[i])
                        local tempType = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
                        if tempType == k then
                            list["Suit"] = -1
                        end
                    end
                end
            else
                list[k] = -1
            end
        end
    end
    return list
end

function ItemTable:getItemsByTypeId(typeId)
    local items = {}
    for i, id in ipairs(self.List6[typeId]) do
        items[i] = self:GetValueById(id)
    end
    return items
end

function ItemTable:IsSeasonMedalItem(itemId)
    return itemId == 234881104 or itemId == 234881105
end

function ItemTable:GetDiamondCandySign(argItemID, argNum)
    local itemInfo = ConfigTable.DynamicQualityTable:GetItemSignAndQuality(argItemID, argNum)
    return string.concat("Common_", itemInfo.sign), itemInfo.quality - 1
end

function ItemTable:getIdByItemType(itemType)
    local id = self:GetIdByFieldIndex(self.item_type_id, itemType)
    return id
end

function ItemTable:GetSignNumById(id)
    local signNum = 0
    local sign = self:getSignForOnly(id)
    sign = string.reverse(sign)
    local index = string.find(sign, "_")
    if index then
        signNum = tonumber(string.reverse(string.sub(sign, 1, index - 1)))
        if not signNum then
            signNum = 0
        end
    end
    return signNum
end

function ItemTable:GetIsInitItem(id)
    return self:GetSingleValue(id, self.is_init)
end

return ItemTable
