local ItemTicketExchangeTable = class({}, Assets.req("Scripts.ConfigTable.Base.ItemTicketExchangeTableBase"))
-- 通过 Id 得到内容
function ItemTicketExchangeTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ItemTicketExchangeTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ItemTicketExchangeTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ItemTicketExchangeTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function ItemTicketExchangeTable:getExchangeMoney(qualityId)
    local id = self:GetIdByFieldIndex(self.quality_id, qualityId)
    if id then
        return self:GetSingleValue(id, self.item_to_ticket)
    end
    return 0
end

function ItemTicketExchangeTable:getItemIdByNum(argNum)
    local list = {}
    local next = 0
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            item = v[self.ticket_item],
            ticket = v[self.item_to_ticket],
            id = k
        }
    end

    table.sort(
        list,
        function(a, b)
            return a.ticket < b.ticket
        end
    )

    for i = 1, #list do
        next = i + 1
        if next > #list then
            return list[#list].item
        end
        if list[i].ticket <= argNum and list[next].ticket > argNum then
            return list[i].item
        end
    end
    return -1
end

return ItemTicketExchangeTable
