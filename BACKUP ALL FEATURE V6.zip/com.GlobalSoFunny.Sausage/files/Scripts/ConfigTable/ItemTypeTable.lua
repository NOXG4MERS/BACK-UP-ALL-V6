local ItemTypeTable = class({}, Assets.req("Scripts.ConfigTable.Base.ItemTypeTableBase"))
-- 通过 Id 得到内容
function ItemTypeTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ItemTypeTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ItemTypeTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ItemTypeTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function ItemTypeTable:getSign(id)
    return self:GetSingleValue(id, self.sign)
end

function ItemTypeTable:getAssembleId(id)
    return self:GetSingleValue(id, self.main_class)
end
function ItemTypeTable:getAssembleList(id)
    local list = {}
    for k, v in pairs(self.List0) do
        if v[self.main_class] == id and v[self.is_equip] == 0 then
            list[#list + 1] = {sign = v[self.sign], name = v[self.name]}
        end
    end
    return list
end

function ItemTypeTable:getIsEquip(id)
    return self:GetSingleValue(id, self.is_equip)
end

function ItemTypeTable:getName(id)
    return self:GetSingleValue(id, self.name)
end

function ItemTypeTable:getIdBySign(sign)
    return self:GetIdByFieldIndex(self.sign, sign)
end

function ItemTypeTable:getAssemBySign(sign)
    local id = self:GetIdByFieldIndex(self.sign, sign)
    if id then
        return self:GetSingleValue(id, self.main_class)
    end
end

function ItemTypeTable:getNameBySign(sign)
    local id = self:GetIdByFieldIndex(self.sign, sign)
    if id then
        return self:GetSingleValue(id, self.name)
    end
end

function ItemTypeTable:getSIGNListBy(isEquip)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.is_equip, isEquip)
    for i = 1, #ids do
        list[#list + 1] = self:GetSingleValue(ids[i], self.sign)
    end
    return list
end

function ItemTypeTable:ReturnWeight(id)
    local typeSign = self:getSign(id)
    return self:ReturnWeightBySign(typeSign)
end

function ItemTypeTable:ReturnWeightBySign(typeSign)
    local weight = 0
    if typeSign == "Set" then --套装
        weight = 0
    elseif typeSign == "dress" then --所有装扮
        weight = 1
    elseif typeSign == ItemTypeTable.Complexion then --皮肤
        weight = 2
    elseif typeSign == ItemTypeTable.Hair then --头部
        weight = 3
    elseif typeSign == ItemTypeTable.FaceDecoration then --面部装饰
        weight = 4
    elseif typeSign == ItemTypeTable.Countenance then --脸部
        weight = 5
    elseif typeSign == ItemTypeTable.Shirt then --上装
        weight = 6
    elseif typeSign == ItemTypeTable.Coat then --外套
        weight = 7
    elseif typeSign == ItemTypeTable.Suit then -- 连衣
        weight = 8
    elseif typeSign == ItemTypeTable.HandDecorated then --手部
        weight = 9
    elseif typeSign == ItemTypeTable.Bottoms then --下装
        weight = 10
    elseif typeSign == ItemTypeTable.Shoe then --脚部
        weight = 11
    elseif typeSign == "action" then --所有动作
        weight = 12
    elseif typeSign == ItemTypeTable.Posture then --姿势
        weight = 13
    elseif typeSign == ItemTypeTable.Dance then --舞蹈
        weight = 14
    elseif typeSign == "expression" then --所有气泡
        weight = 15
    elseif typeSign == ItemTypeTable.Bubble then --气泡
        weight = 16
    elseif typeSign == ItemTypeTable.WarItemTypeAssault then
        weight = 20
    elseif typeSign == ItemTypeTable.WarItemTypeSniper then
        weight = 21
    elseif typeSign == ItemTypeTable.WarItemTypeDesignatedMarksmanRifle then
        weight = 22
    elseif typeSign == ItemTypeTable.WarItemTypeSubmachineGun then
        weight = 23
    elseif typeSign == ItemTypeTable.WarItemTypeShotGun then
        weight = 24
    elseif typeSign == ItemTypeTable.WarItemTypeLightMachineGun then
        weight = 25
    end
    return weight
end

return ItemTypeTable
