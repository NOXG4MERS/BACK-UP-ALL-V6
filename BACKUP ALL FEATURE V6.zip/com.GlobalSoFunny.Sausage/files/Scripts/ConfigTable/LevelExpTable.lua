local LevelExpTable = class({}, Assets.req("Scripts.ConfigTable.Base.LevelExpTableBase"))
-- 通过 Id 得到内容
function LevelExpTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function LevelExpTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function LevelExpTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function LevelExpTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
-- 获得最大等级
local MaxLevel = -1
function LevelExpTable:getMaxLevel()
    if MaxLevel > -1 then
        return MaxLevel
    end
    for k, v in pairs(self.List0) do
        local tempLevel = v[self.level]
        if MaxLevel < tempLevel then
            MaxLevel = tempLevel
        end
    end
    return MaxLevel
end

-- 经验值
function LevelExpTable:getExpByLv(lv)
    local exp = 0
    for k, v in pairs(self.List0) do
        if lv >= v[self.level] then
            exp = exp + v[self.exp]
        end
    end
    return exp
end

-- 经验值
function LevelExpTable:getMaxExpByLv(lv)
    local id = self:GetIdByFieldIndex(self.level, lv)
    if id then
        return self:GetSingleValue(id, self.exp)
    end
    return 0
end

-- 计算能升到多少级
function LevelExpTable:getEndLevel(beforeLv, beforeExp, addExp)
    local endExp = self:getExpByLv(beforeLv) + beforeExp + addExp
    local lev = self:getLvByExp(endExp)
    return lev
end

-- 计算能升到多少级后剩多少经验
function LevelExpTable:getEndExp(beforeLv, beforeExp, addExp)
    local endExp = self:getExpByLv(beforeLv) + beforeExp + addExp
    local lev = self:getLvByExp(endExp)
    local endStartExp = self:getExpByLv(lev)
    local resultExp = endExp - endStartExp

    return resultExp
end

function LevelExpTable:getLvByExp(exp)
    local lv = 1
    local nowExp = 0
    for k, v in pairs(self.List0) do
        nowExp = nowExp + v[self.exp]
        if nowExp > exp then
            return v[self.level] - 1
        end
    end
    return 90
end

-- 甜甜圈数量
function LevelExpTable:getDonutByLv(lv)
    local id = self:GetIdByFieldIndex(self.level, lv)
    if id then
        return self:GetSingleValue(id, self.donut)
    end
    return 0
end

-- 额外甜甜圈
function LevelExpTable:getExtraDonut(lv)
    local id = self:GetIdByFieldIndex(self.level, lv)
    if id then
        return self:GetSingleValue(id, self.ex_donut)
    end
    return 0
end

return LevelExpTable
