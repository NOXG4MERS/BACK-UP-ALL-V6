local LoadingPageTable = class({}, Assets.req("Scripts.ConfigTable.Base.LoadingPageTableBase"))
-- 通过 Id 得到内容
function LoadingPageTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function LoadingPageTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function LoadingPageTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function LoadingPageTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function LoadingPageTable:getContent(id)
    local data = self:GetValueById(id)
    return {
        sign = data[self.sign],
        startTime = data[self.start_time],
        endTime = data[self.end_time]
    }
end

function LoadingPageTable:GetAllContent()
    local list = {}
    local serverType = ConfigTable:GetServerType()
    for k, v in pairs(self.List0) do
        local sign = v[self.sign]
        if v[self.server_type] == serverType then
            list[sign] = self:getContent(k)
        end
    end

    return list
end

return LoadingPageTable
