local PayCrateExtraRewardTable = class({}, Assets.req("Scripts.ConfigTable.Base.PayCrateExtraRewardTableBase"))
-- 通过 Id 得到内容
function PayCrateExtraRewardTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function PayCrateExtraRewardTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function PayCrateExtraRewardTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function PayCrateExtraRewardTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local tempItemIds = {}
function PayCrateExtraRewardTable:getItem(crateId)
    if tempItemIds[crateId] then
        return tempItemIds[crateId]
    end
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.crate_id, crateId)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        list[#list + 1] = {
            crateId = crateId,
            process = data[self.process],
            itemId = data[self.item_id],
            num = data[self.item_num]
        }
    end
    table.sort(
        list,
        function(a, b)
            return a.process < b.process
        end
    )

    tempItemIds[crateId] = list
    return list
end

return PayCrateExtraRewardTable
