local PreferentialShopTable = class({}, Assets.req("Scripts.ConfigTable.Base.PreferentialShopTableBase"))
-- 通过 Id 得到内容
function PreferentialShopTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function PreferentialShopTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function PreferentialShopTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function PreferentialShopTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function PreferentialShopTable:GetAllItemForTimeDic()
    local list = {}
    local serverType = ConfigTable:GetServerType()
    for k, v in pairs(self.List0) do
        if v[self.server_type] == serverType then
            local timeRange = {
                startTime = v[self.start_time],
                endTime = v[self.end_time]
            }
            timeRange.startTime = TimeHelper:GetConfigTimestamp(timeRange.startTime)
            timeRange.endTime = TimeHelper:GetConfigTimestamp(timeRange.endTime)
            list[v[self.product_id]] = timeRange
        end
    end
    return list
end

function PreferentialShopTable:getPreferentialShopTableName(argItemID)
    return self:GetSingleValue(argItemID, self.name)
end

function PreferentialShopTable:GetPreferentialShopName(id)
    local item = self:GetValueById(id)
    if not item then
        return nil
    end
    return item[self.name]
end

function PreferentialShopTable:GetPreferentialShopType(id)
    return self:GetSingleValue(id, self.preferential_shop_type)
end

function PreferentialShopTable:GetPreferentialShopName(id)
    local item = self:GetValueById(id)
    if not item then
        return nil
    end
    return item[self.name]
end

return PreferentialShopTable
