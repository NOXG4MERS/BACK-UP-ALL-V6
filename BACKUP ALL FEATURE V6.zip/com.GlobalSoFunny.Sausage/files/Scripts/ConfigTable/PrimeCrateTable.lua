local PrimeCrateTable = class({}, Assets.req("Scripts.ConfigTable.Base.PrimeCrateTableBase"))
-- 通过 Id 得到内容
function PrimeCrateTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function PrimeCrateTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function PrimeCrateTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function PrimeCrateTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function PrimeCrateTable:GetAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        local tempCrateId = v[self.crate_id]
        local timeRange = ConfigTable:GetTimeRange("PrimeCrateTimeTable", tempCrateId)
        if timeRange then
            list[tempCrateId] = {
                startTime = timeRange.startTime,
                endTime = timeRange.endTime
            }
        end
    end
    return list
end

--是否是缤纷补给箱
function PrimeCrateTable:isPrimeCrate(argID)
    local isPrimeCrate = false
    local id = self:GetIdByFieldIndex(self.crate_id, argID)
    if id then
        isPrimeCrate = true
    end
    return isPrimeCrate
end

function PrimeCrateTable:getSubjectType(typeId) --根据物品ID获得
    local items = {}
    if self.List2[typeId] ~= nil then
        for i, id in ipairs(self.List2[typeId]) do
            items[i] = self:GetValueById(id)
        end
    end
    return items
end

return PrimeCrateTable
