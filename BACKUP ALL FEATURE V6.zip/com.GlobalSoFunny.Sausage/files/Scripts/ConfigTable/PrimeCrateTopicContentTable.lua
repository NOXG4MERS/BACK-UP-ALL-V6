local PrimeCrateTopicContentTable = class({}, Assets.req("Scripts.ConfigTable.Base.PrimeCrateTopicContentTableBase"))
-- 通过 Id 得到内容
function PrimeCrateTopicContentTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function PrimeCrateTopicContentTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function PrimeCrateTopicContentTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function PrimeCrateTopicContentTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function PrimeCrateTopicContentTable:getItemsByTypeId(typeId) --根据物品ID获得
    local ids = self:GetIdsByFieldIndex(self.get_item_id, typeId)
    local items = {}
    for i = 1, #ids do
        local list = self:GetValueById(ids[i])
        for j = 1, #list do
            items[#items + 1] = list[j]
        end
    end
    return items
end

function PrimeCrateTopicContentTable:getContentByTopicId(argTopicId, argStartTime, argEndTime)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.topic_id, argTopicId)
    for i = 1, #ids do
        list[#list + 1] = {
            id = self:GetSingleValue(ids[i], self.get_item_id),
            num = self:GetSingleValue(ids[i], self.item_num),
            startTime = argStartTime,
            endTime = argEndTime,
            order = self:GetSingleValue(ids[i], self.show_order)
        }
    end
    return list
end

function PrimeCrateTopicContentTable:getContentByCrateId(argCrateId, argStartTime, argEndTime)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.crate_id, argCrateId)
    for i = 1, #ids do
        list[#list + 1] = {
            id = self:GetSingleValue(ids[i], self.get_item_id),
            num = self:GetSingleValue(ids[i], self.item_num),
            startTime = argStartTime,
            endTime = argEndTime,
            order = self:GetSingleValue(ids[i], self.show_order)
        }
    end
    return list
end

function PrimeCrateTopicContentTable:getAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = v[self.get_item_id],
            crateId = v[self.crate_id]
        }
    end
    return list
end

function PrimeCrateTopicContentTable:getCrateInfoByCrateId2(argCrateId)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.crate_id, argCrateId)
    for i = 1, #ids do
        list[#list + 1] = {
            itemId = self:GetSingleValue(ids[i], self.get_item_id),
            num = self:GetSingleValue(ids[i], self.item_num),
            showOrder = self:GetSingleValue(ids[i], self.show_order)
        }
    end
    return list
end
function PrimeCrateTopicContentTable:GetCrateID(argItemID) --根据物品ID获得
    local ids = self:GetIdByFieldIndex(self.get_item_id, argItemID)
    local data = self:GetValueById(ids)
    local list = {}
    if data then
        list[#list + 1] = data[self.crate_id]
    end
    return list
end
function PrimeCrateTopicContentTable:GetID(argItemID)
    local id = self:GetIdByFieldIndex(self.get_item_id, argItemID)
    return id
end

return PrimeCrateTopicContentTable
