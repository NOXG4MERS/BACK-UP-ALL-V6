local PrimeCrateTopicTable = class({}, Assets.req("Scripts.ConfigTable.Base.PrimeCrateTopicTableBase"))
-- 通过 Id 得到内容
function PrimeCrateTopicTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function PrimeCrateTopicTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function PrimeCrateTopicTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function PrimeCrateTopicTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function PrimeCrateTopicTable:getCrateIdById(argId)
    local data = self:GetValueById(argId)
    return {id = data[self.crate_id], sign = data[self.sign]}
end

function PrimeCrateTopicTable:getCrateInfoByCrateId(argCrateId)
    local id = self:GetIdByFieldIndex(self.crate_id, argCrateId)
    if id then
        local data = self:GetValueById(id)
        return {id = data[self.crate_id], crateId = argCrateId, sign = data[self.sign]}
    end
    return -1
end

function PrimeCrateTopicTable:getCrateNameByCrateId(argCrateId)
    local id = self:GetIdByFieldIndex(self.crate_id, argCrateId)
    if id then
        return self:GetSingleValue(id, self.name)
    end
    return ""
end

return PrimeCrateTopicTable
