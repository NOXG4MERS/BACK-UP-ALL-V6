local RankingsTable = class({}, Assets.req("Scripts.ConfigTable.Base.RankingsTableBase"))
-- 通过 Id 得到内容
function RankingsTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function RankingsTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function RankingsTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function RankingsTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local primaryRankTypes = nil
local rankTypes = nil
local secondaryRankTypes = {}

RankingsTable.RankType = {
    Grade = 1,
    Delicious = 2,
    Fans = 3,
    Elimination = 4,
    Crit = 5,
    Champion = 6,
    Like = 7,
    CP = 8,
    Partner = 9,
    Bromance = 10,
    Besties = 11
}

RankingsTable.RankArea = {
    Region = "Region",
    Server = "Server",
    Friend = "Friend"
}

RankingsTable.RankPeriod = {
    Week = "Week",
    Season = "Season",
    History = "History"
}

function RankingsTable:getItemByRankType(argRankType)
    local tempItem = self.List4[argRankType]
    if tempItem then
        return self:GetValueById(tempItem[1])
    end
    return nil
end

function RankingsTable:getMinScoreByRankType(argRankType)
    local tempItem = self:getItemByRankType(argRankType)
    if tempItem then
        return tempItem[self.min_grade_score]
    end
end

function RankingsTable:getSortByRankType(argRankType)
    local tempItem = self:getItemByRankType(argRankType)
    if tempItem then
        return tempItem[self.sort]
    end
end

function RankingsTable:getPrimaryRankTypes()
    if not primaryRankTypes then
        primaryRankTypes = {}
        for k, v in pairs(self.List5) do
            table.insert(primaryRankTypes, k)
        end
        table.sort(primaryRankTypes)
    end
    return primaryRankTypes
end

function RankingsTable:getPrimaryRankType(argRankType)
    local tempItem = self:getItemByRankType(argRankType)
    local tempPrimaryRankType = tempItem[self.rankings_type]
    return tempPrimaryRankType
end

function RankingsTable:GetRankTypes()
    if not rankTypes then
        rankTypes = {}
        for k, v in pairs(self.List4) do
            table.insert(rankTypes, k)
        end
        self:SortRankTypes(rankTypes)
    end
    return rankTypes
end

function RankingsTable:getSecondaryRankTypes(argPrimaryRankType)
    local tempIndex = table.getIndex(primaryRankTypes, argPrimaryRankType)
    if tempIndex then
        if not secondaryRankTypes[argPrimaryRankType] then
            secondaryRankTypes[argPrimaryRankType] = {}
            local tempItemIds = self.List5[argPrimaryRankType]
            for i = 1, #tempItemIds do
                local tempItem = self:GetValueById(tempItemIds[i])
                table.insert(secondaryRankTypes[argPrimaryRankType], tempItem[self.rankings_key])
            end
            table.sort(secondaryRankTypes[argPrimaryRankType])
        end
        return secondaryRankTypes[argPrimaryRankType]
    end
    return nil
end

function RankingsTable:HasRankArea(argRankType, argRankArea)
    local tempItem = self:getItemByRankType(argRankType)
    if not tempItem then
        return false
    end
    if argRankArea == self.RankArea.Server then
        return tempItem[self.area_global] == 1
    elseif argRankArea == self.RankArea.Region then
        return tempItem[self.area_province] == 1
    elseif argRankArea == self.RankArea.Friend then
        return tempItem[self.area_friend] == 1
    end
    return false
end

function RankingsTable:HasRankPeriod(argRankType, argRankPeriod)
    local tempItem = self:getItemByRankType(argRankType)
    if not tempItem then
        return false
    end
    if argRankPeriod == self.RankPeriod.Week then
        return tempItem[self.time_week] == 1
    elseif argRankPeriod == self.RankPeriod.Season then
        return tempItem[self.time_season] == 1
    elseif argRankPeriod == self.RankPeriod.History then
        return tempItem[self.time_history] == 1
    end
    return false
end

function RankingsTable:SortRankTypes(argRankTypes)
    table.sort(argRankTypes, function(lhs, rhs)
        local lhsSort = self:getSortByRankType(lhs)
        local rhsSort = self:getSortByRankType(rhs)
        if lhsSort ~= rhsSort then
            return lhsSort < rhsSort
        end
        return lhs < rhs
    end)
end

return RankingsTable
