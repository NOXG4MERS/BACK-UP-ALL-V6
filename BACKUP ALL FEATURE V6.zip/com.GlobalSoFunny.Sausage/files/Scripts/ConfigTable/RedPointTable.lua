local RedPointTable = class({}, Assets.req("Scripts.ConfigTable.Base.RedPointTableBase"))
-- 通过 Id 得到内容
function RedPointTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function RedPointTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function RedPointTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function RedPointTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function RedPointTable:getSignById(id)
    local sign = self:GetSingleValue(id, self.sign)
    sign = string.gsub(sign, "HD_", "")
    return sign
end

function RedPointTable:getIdBySign(sign)
    return self:GetIdByFieldIndex(self.sign, "HD_" .. sign)
end

function RedPointTable:getIdByRealSign(argSign)
    return self:GetIdByFieldIndex(self.sign, argSign)
end

function RedPointTable:isLobbyAppearanceId(id)
    if
        self:isAppearanceId(id) or self:isWarFlagId(id) or self:isExpressionId(id) or self:isActionId(id) or self:isWarItemId(id) or self:isKillballonId(id) or
            self:getIdByRealSign(self.HD_JokerItem) == id or
            self:getIdByRealSign(self.HD_Aerocraft) == id or
            self:getIdByRealSign(self.HD_Crate) == id or
            self:getIdByRealSign(self.HD_RenameCard) == id or
            self:getIdByRealSign(self.HD_CustomMatchCard) == id or
            self:getIdByRealSign(self.HD_BackpackSkin) == id or
            self:getIdByRealSign(self.HD_XCCSkin) == id or
            self:isMeleeMeleeWeapon(id) or
			self:IsCar(id)
     then
        return true
    else
        return false
    end
end

function RedPointTable:isWarPreparednessId(id)
    if
        self:getIdByRealSign(self.HD_JokerItem) == id or self:getIdByRealSign(self.HD_Aerocraft) == id or self:getIdByRealSign(self.HD_Looser) == id or self:getIdByRealSign(self.HD_BackpackSkin) == id or
            self:getIdByRealSign(self.HD_XCCSkin) == id
     then
        return true
    else
        return false
    end
end

function RedPointTable:isAppearanceId(id)
    if id <= 10 then
        return true
    else
        return false
    end
end

function RedPointTable:isWarFlagId(id)
    if (id >= 17 and id <= 20) or id == 15 then
        return true
    else
        return false
    end
end

function RedPointTable:isExpressionId(id)
    if id == 14 then
        return true
    else
        return false
    end
end

function RedPointTable:isActionId(id)
    if id == 13 or id == 15 then
        return true
    else
        return false
    end
end

function RedPointTable:isWarItemId(id)
    if ConfigTable.GunSkinTable:isGunSkinRed(id) then
        return true
    else
        return false
    end
end

function RedPointTable:isMeleeMeleeWeapon(id)
    if self:getIdByRealSign(self.HD_Pan) == id or self:getIdByRealSign(self.HD_Bat) == id or self:getIdByRealSign(self.HD_Plunger) == id or self:getIdByRealSign(self.HD_Fork) == id then
        return true
    else
        return false
    end
end

function RedPointTable:IsCar(id)
    if self:getIdByRealSign(self.HD_PonyVehicle) == id then
        return true
    else
        return false
    end
end

function RedPointTable:isKillballonId(id)
    if id == 234881024 then
        return true
    else
        return false
    end
end

--获取红点类型集合
function RedPointTable:getIdsBySign(argSign, argIsWarItem)
    if argIsWarItem then
        return self:getAllWarItemIdsByType(argSign)
    end
    local tempIds = {}
    if argSign == "action" then
        tempIds = self:getAllActionIds()
    elseif argSign == "expression" then
        tempIds = self:getAllExpressionIds()
    elseif argSign == "dress" then
        tempIds = self:getAllAppearanceIds()
    elseif argSign == "Crate" then
        tempIds = {335544320, 23, 369098752}
    else
        tempIds = {self:getIdBySign(argSign)}
    end
    return tempIds
end

function RedPointTable:getAllAppearanceIds()
    local list = {}
    for i = 1, self.COUNT do
        if i <= 10 then
            list[#list + 1] = i
        end
    end
    return list
end

function RedPointTable:getAllExpressionIds()
    local list = {14}
    return list
end

function RedPointTable:getAllActionIds()
    local list = {13, 15}
    return list
end

function RedPointTable:getAllWarItemIdsByType(argType)
    local list = {}
    for k, v in pairs(self.List0) do
        local tempId = k
        local tempSign = v[self.sign]
        tempSign = "WarItem" .. string.gsub(tempSign, "HD_", "")
        local tempItemId = ConfigTable.ItemTable:getIdByUniqueSign(tempSign)
        if tempItemId > 0 then
            local tempWardrobeTypeId = ConfigTable.ItemTable:getItemTypeId(tempItemId)
            local tempTypeSign = ConfigTable.ItemTypeTable:getSign(tempWardrobeTypeId)
            if tempTypeSign == argType then
                list[#list + 1] = tempId
            end
        end
    end
    return list
end
--是否存在红点套装装扮红点
function RedPointTable:isWardrobePopupId(id)
    local bool = false
    local list = ConfigTable.EquipSaveUnlockTable:getRedPointIdList()
    for i = 1, #list do
        local redpointId = list[i]
        if redpointId == id then
            bool = true
        end
    end
    return bool
end

return RedPointTable
