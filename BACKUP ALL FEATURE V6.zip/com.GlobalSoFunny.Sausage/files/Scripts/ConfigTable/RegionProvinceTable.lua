local RegionProvinceTable = class({}, Assets.req("Scripts.ConfigTable.Base.RegionProvinceTableBase"))
-- 通过 Id 得到内容
function RegionProvinceTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function RegionProvinceTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function RegionProvinceTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function RegionProvinceTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local provinceCodes = nil

function RegionProvinceTable:getItemByProvinceCode(argProvinceCode)
    local tempProvinceCode = argProvinceCode .. "0000"
    if self.List2[tempProvinceCode] then
        local tempItemId = self.List2[tempProvinceCode][1]
        return self:GetValueById(tempItemId)
    end
    return nil
end

function RegionProvinceTable:getProvinceName(argProvinceCode)
    local tempItem = self:getItemByProvinceCode(argProvinceCode)
    if tempItem then
        return tempItem[self.name]
    end
    return ""
end

function RegionProvinceTable:getProvinceCodes()
    if not provinceCodes then
        provinceCodes = {}
        for k, v in pairs(self.List2) do
            table.insert(provinceCodes, tonumber(string.sub(k, 1, 2)))
        end
        table.sort(provinceCodes)
    end
    return provinceCodes
end

return RegionProvinceTable
