local ScoreAwardItemTable = class({}, Assets.req("Scripts.ConfigTable.Base.ScoreAwardItemTableBase"))
-- 通过 Id 得到内容
function ScoreAwardItemTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ScoreAwardItemTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ScoreAwardItemTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ScoreAwardItemTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function ScoreAwardItemTable:getScoreRewardItemById(argId)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.score_award_id, argId)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        list[#list + 1] = {id = data[self.item_id], num = data[self.count]}
    end
    return list
end

function ScoreAwardItemTable:getAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = v[self.item_id],
            scoreAwardId = v[self.score_award_id]
        }
    end
    return list
end

return ScoreAwardItemTable
