local ScoreLvTable = class({}, Assets.req("Scripts.ConfigTable.Base.ScoreLvTableBase"))
-- 通过 Id 得到内容
function ScoreLvTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ScoreLvTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ScoreLvTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ScoreLvTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local sortedIDs = {}
local secondaryRankLevels = {}
--获得击杀分数
function ScoreLvTable:GetAttackValue(scorelv, killNum)
    local id = self:GetIdByFieldIndex(self.lv, scorelv)
    if id then
        return self:GetSingleValue(id, self.kill_score) * killNum
    end
    return 0
end

function ScoreLvTable:GetPrimaryRankLevel(score)
    if #sortedIDs == 0 then
        for k, v in pairs(self.List0) do
            table.insert(sortedIDs, k)
        end
        table.sort(sortedIDs, function(lhs, rhs)
            local lhsLevel = self:GetSingleValue(lhs, self.lv)
            local rhsLevel = self:GetSingleValue(rhs, self.lv)
            return lhsLevel < rhsLevel
        end)
    end
    for i = 1, #sortedIDs do
        local rankScore = self:GetSingleValue(sortedIDs[i], self.score)
        if score < rankScore then
            if i > 1 then
                return self:GetSingleValue(sortedIDs[i - 1], self.show_sign)
            end
            break
        end
    end
    return self:GetSingleValue(sortedIDs[#sortedIDs], self.show_sign)
end

function ScoreLvTable:GetSecondaryRankLevel(rankLevel)
    if #secondaryRankLevels == 0 then
        for k, levels in pairs(self.List9) do
            for i = 1, #levels do
                local secondaryRankLevel
                if i == 5 then
                    secondaryRankLevel = 1
                else
                    secondaryRankLevel = 5 - i % 5 + 1
                end
                secondaryRankLevels[levels[i]] = secondaryRankLevel
            end
        end
    end
    return secondaryRankLevels[rankLevel]
end

return ScoreLvTable
