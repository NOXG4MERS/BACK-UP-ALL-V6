local ScoreTable = class({}, Assets.req("Scripts.ConfigTable.Base.ScoreTableBase"))
-- 通过 Id 得到内容
function ScoreTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ScoreTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ScoreTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ScoreTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
--获得排名分数
function ScoreTable:GetRankValue(gameState, roleRank, level)
    if gameState == 2 then
        roleRank = roleRank * 2 - 1
    elseif gameState == 4 then
        roleRank = roleRank * 4 - 3
    end

    if roleRank > 120 then
        roleRank = 120
    end

    print("roleRank::" .. roleRank)
    for k, v in pairs(self.List0) do
        if v[self.sort] == roleRank and v[self.score_lv_id] == level then
            return v[self.score]
        end
    end
    return 0
end

return ScoreTable
