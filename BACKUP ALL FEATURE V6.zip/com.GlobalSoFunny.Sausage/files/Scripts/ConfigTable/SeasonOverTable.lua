local SeasonOverTable = class({}, Assets.req("Scripts.ConfigTable.Base.SeasonOverTableBase"))
-- 通过 Id 得到内容
function SeasonOverTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function SeasonOverTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function SeasonOverTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function SeasonOverTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

function SeasonOverTable:GetScoreAwardItemAndNum(argSeason, argTotablScore)
    local SeasonOverID = 0
    local tempMaxScore = 0
    for k, v in pairs(self.List0) do
        if v[self.season] == argSeason then
            if v[self.old_score] <= argTotablScore and v[self.old_score] >= 0 then
                if v[self.old_score] > tempMaxScore or tempMaxScore == 0 then
                    SeasonOverID = k
                    tempMaxScore = v[self.old_score]
                end
            end
        end
    end
    return ConfigTable.SeasonOverAwardTable:getAwardInfoById(SeasonOverID)
end

function SeasonOverTable:GetSeasonOverAwardScores(seasonID)
    local scores = {}
    if self.List2[seasonID] then
        local ids = self.List2[seasonID]
        for i = 1, #ids do
            local score = self:GetSingleValue(ids[i], self.old_score)
            table.insert(scores, score)
        end
    end
    return scores
end

return SeasonOverTable
