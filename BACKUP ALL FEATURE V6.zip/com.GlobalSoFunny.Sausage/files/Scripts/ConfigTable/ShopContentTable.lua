local ShopContentTable = class({}, Assets.req("Scripts.ConfigTable.Base.ShopContentTableBase"))
-- 通过 Id 得到内容
function ShopContentTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ShopContentTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ShopContentTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ShopContentTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------

local tempItemIds = {}
function ShopContentTable:getPriceData(crateId)
    if tempItemIds[crateId] then
        return tempItemIds[crateId]
    end
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.item_id, crateId)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        local tempProductId = data[self.product_id]
        local tempShopInfo = ConfigTable.ShopTable:getProductInfoByProductId(tempProductId)

        list[#list + 1] = {
            crateId = crateId,
            productId = tempProductId,
            price = tempShopInfo.price,
            itemId = data[self.item_id],
            num = data[self.num]
        }
    end

    table.sort(
        list,
        function(a, b)
            return a.price < b.price
        end
    )
    tempItemIds[crateId] = list
    return list
end

function ShopContentTable:getContentByProductId(argProductID)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.product_id, argProductID)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        list[#list + 1] = {
            itemId = data[self.item_id],
            num = data[self.num],
            showOrder = data[self.show_order]
        }
    end

    table.sort(
        list,
        function(a, b)
            return a.showOrder < b.showOrder
        end
    )
    return list
end

function ShopContentTable:getItemIDByProductId(argProductID)
    local id = self:GetIdByFieldIndex(self.product_id, argProductID)
    if id then
        return self:GetSingleValue(id, self.item_id)
    end
    return nil
end

function ShopContentTable:getProductItemAllNum(argProductID)
    local tempNum = 0
    local ids = self:GetIdsByFieldIndex(self.product_id, argProductID)
    for i = 1, #ids do
        tempNum = tempNum + self:GetSingleValue(ids[i], self.num)
    end
    return tempNum
end

function ShopContentTable:getAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = v[self.item_id],
            crateId = v[self.product_id]
        }
    end
    return list
end

return ShopContentTable
