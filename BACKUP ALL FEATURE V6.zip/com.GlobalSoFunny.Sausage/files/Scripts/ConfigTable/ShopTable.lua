local ShopTable = class({}, Assets.req("Scripts.ConfigTable.Base.ShopTableBase"))
-- 通过 Id 得到内容
function ShopTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function ShopTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function ShopTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function ShopTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local tempItemIds = {}
function ShopTable:getPriceData(crateId)
    if tempItemIds[crateId] then
        return tempItemIds[crateId]
    end
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.item_id, crateId)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        list[#list + 1] = {
            crateId = crateId,
            productId = data[self.product_id],
            price = data[self.price],
            itemId = data[self.item_id],
            num = data[self.num]
        }
    end

    table.sort(
        list,
        function(a, b)
            return a.price < b.price
        end
    )
    tempItemIds[crateId] = list
    return list
end

function ShopTable:getProductInfoByProductId(argProductId)
    local list = {}
    local id = self:GetIdByFieldIndex(self.product_id, argProductId)
    if id then
        local data = self:GetValueById(id)
        list = {
            crateId = data[self.id],
            name = data[self.name],
            sign = data[self.sign],
            desc = data[self.desc],
            shopType = data[self.shop_type],
            productId = argProductId,
            price = data[self.price],
            currencyId = data[self.currency_id],
            originalPrice = data[self.original_price]
        }
    end
    return list
end

function ShopTable:getProductInfoByProductId2(argProductId)
    local list = {}
    local id = self:GetIdByFieldIndex(self.product_id, argProductId)
    if id then
        local data = self:GetValueById(id)
        list = {
            CrateId = data[self.id],
            Name = data[self.name],
            Sign = data[self.sign],
            Desc = data[self.desc],
            ShopType = data[self.shop_type],
            ProductId = argProductId,
            Price = data[self.price],
            CurrencyId = data[self.currency_id],
            OriginalPrice = data[self.original_price]
        }
    end
    return list
end

return ShopTable
