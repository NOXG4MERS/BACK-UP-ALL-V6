local SuitSetContentTable = class({}, Assets.req("Scripts.ConfigTable.Base.SuitSetContentTableBase"))
-- 通过 Id 得到内容
function SuitSetContentTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function SuitSetContentTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function SuitSetContentTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function SuitSetContentTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function SuitSetContentTable:getSuitSetId(id)
    local index = -1
    local idIndex = self:GetIdByFieldIndex(self.item_id, id)
    if idIndex then
        index = self:GetSingleValue(idIndex, self.suit_set_id)
    end
    return index
end

function SuitSetContentTable:getSuitSetContent(id)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.suit_set_id, id)
    for i = 1, #ids do
        list[#list + 1] = self:GetSingleValue(ids[i], self.item_id)
    end
    return list
end

function SuitSetContentTable:getSuitSetFirstItem(id)
    local id = self:GetIdByFieldIndex(self.suit_set_id, id)
    if id then
        return self:GetSingleValue(id, self.item_id)
    end
end

function SuitSetContentTable:getHighQualtiy(id)
    local list = self:getSuitSetContent(id)
    local qualtiy = -1
    for i = 1, #list do
        if ConfigTable.ItemTable:getQualtiy(list[i]) > qualtiy then
            qualtiy = ConfigTable.ItemTable:getQualtiy(list[i])
        end
    end
    return qualtiy
end

function SuitSetContentTable:getItemsByTypeId(typeId) --根据物品ID得到套装ID
    local items = {}
    if self.List3[typeId] ~= nil then
        for i, id in ipairs(self.List3[typeId]) do
            items[i] = self:GetValueById(id)
        end
    end
    return items
end

function SuitSetContentTable:getSuitId(argItemId)
    local suitId = nil
    local suitList = self:getItemsByTypeId(argItemId)
    if suitList ~= nil then
        for i = 1, #suitList do
            local suitCoent = suitList[i]
            suitId = suitCoent[self.suit_set_id]
            return suitId
        end
    end
    return suitId
end

function SuitSetContentTable:getItemIdSetBySetId(setId)
    local itemIdSet = {}
    if self.List2[setId] ~= nil then
        for i, id in ipairs(self.List2[setId]) do
            local Data = self:GetValueById(id)
            itemIdSet[i] = Data[self.item_id]
        end
    end
    return itemIdSet
end

function SuitSetContentTable:getAllItemIdSets()
    local itemIdSets = {}
    for setId, ids in pairs(self.List2) do
        local itemIdSet = {}
        for i, id in ipairs(ids) do
            local Data = self:GetValueById(id)
            itemIdSet[i] = Data[self.item_id]
        end
        itemIdSets[setId] = itemIdSet
    end
    return itemIdSets
end

return SuitSetContentTable
