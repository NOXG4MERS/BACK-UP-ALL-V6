local SuitSetTable = class({}, Assets.req("Scripts.ConfigTable.Base.SuitSetTableBase"))
-- 通过 Id 得到内容
function SuitSetTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function SuitSetTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function SuitSetTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function SuitSetTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function SuitSetTable:getSign(id)
    return self:GetSingleValue(id, self.sign)
end

function SuitSetTable:getMarkSign(id)
    return self:GetSingleValue(id, self.mark_sign)
end

function SuitSetTable:getName(id)
    return self:GetSingleValue(id, self.name)
end

function SuitSetTable:getAllSetInfo()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = k,
            name = v[self.name],
            sign = v[self.sign],
            desc = v[self.discription],
            showOrder = v[self.show_order],
            topicSign = v[self.mark_sign]
        }
    end
    return list
end

function SuitSetTable:getSetInfo(argSetId)
    local tempInfo = {}
    local data = self:GetValueById(argSetId)
    if data then
        tempInfo = {
            id = data[self.id],
            name = data[self.name],
            sign = data[self.sign],
            desc = data[self.discription],
            showOrder = data[self.show_order],
            topicSign = data[self.mark_sign],
            pos = data[self.show_posture]
        }
    end

    return tempInfo
end

--通过itemID得到对应表ID
function SuitSetTable:getItemSuitId(argItemID)
    local id = self:GetIdByFieldIndex(self.item_id, argItemID)
    if id then
        return id
    end
    return 0
end

--通过ID得到套装皮肤ID
function SuitSetTable:getSkinIdById(argId)
    return self:GetSingleValue(argId, self.show_complexion)
end

function SuitSetTable:getItemsByTypeId(typeId) --根据物品ID得到套装ID
    local items = {}
    if self.List7[typeId] ~= nil then
        for i, id in ipairs(self.List7[typeId]) do
            items[i] = self:GetValueById(id)
        end
    end
    return items
end

function SuitSetTable:getSuitItemID(argSuitId) --得到套装ID的物品ID
    local suitItemID = nil
    local Data = self:GetValueById(argSuitId)
    if Data then
        suitItemID = Data[self.item_id]
        return suitItemID
    end
    return suitItemID
end

function SuitSetTable:getSuitSetById(id)
    return self:GetValueById(id)
end

return SuitSetTable
