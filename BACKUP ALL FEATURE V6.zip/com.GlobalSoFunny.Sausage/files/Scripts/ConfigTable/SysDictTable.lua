local SysDictTable = class({}, Assets.req("Scripts.ConfigTable.Base.SysDictTableBase"))
-- 通过 Id 得到内容
function SysDictTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function SysDictTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function SysDictTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function SysDictTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function SysDictTable:getItemMainClassList()
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.type, "item_main_class")
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        list[#list + 1] = {id = data[self.id], sign = data[self.sign], name = data[self.desc]}
    end
    return list
end

function SysDictTable:getAssembleSign(id)
    if id == 0 or id == nil then
        return "None"
    end
    for k, v in pairs(self.List0) do
        if v[self.type] == "item_main_class" and v[self.value] == id then
            return v[self.sign]
        end
    end
end

function SysDictTable:getValueBySign(sign, argType)
    for k, v in pairs(self.List0) do
        if v[self.type] == argType and v[self.sign] == sign then
            return v[self.value]
        end
    end
end

function SysDictTable:getSignByValue(argValue, argType)
    for k, v in pairs(self.List0) do
        if v[self.type] == argType and v[self.value] == argValue then
            return v[self.sign]
        end
    end
end

function SysDictTable:getValueForShowBySign(sign)
    for k, v in pairs(self.List0) do
        if v[self.sign] == sign and v[self.type] == "show_data_type" then
            return v[self.value]
        end
    end
end

function SysDictTable:getDescByValue(argValue, argType)
    for k, v in pairs(self.List0) do
        if v[self.value] == argValue and v[self.type] == argType then
            return v[self.desc]
        end
    end
    return ""
end

function SysDictTable:getSignByid(id)
    if id == 0 or id == nil then
        return "None"
    end
    return self:GetSingleValue(id, self.sign)
end

-- 通过类型找出所有信息
function SysDictTable:getInfoByType(argType)
    local list = {}
    local ids = self:GetIdsByFieldIndex(self.type, argType)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        local desc = string.split(data[self.desc], "_")
        list[#list + 1] = {
            Desc = desc[1],
            Value = data[self.value],
            id = data[self.id],
            Des = desc[2]
        }
    end
    table.sort(
        list,
        function(a, b)
            return a.Value < b.Value
        end
    )
    return list
end

function SysDictTable:getPrimaryRankName(argPrimaryRankType)
    for k, v in pairs(self.List0) do
        if v[self.type] == "rankings_type" and v[self.value] == argPrimaryRankType then
            return v[self.desc]
        end
    end
end

return SysDictTable
