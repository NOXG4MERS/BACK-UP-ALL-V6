local TaskContentTable = class({}, Assets.req("Scripts.ConfigTable.Base.TaskContentTableBase"))
-- 通过 Id 得到内容
function TaskContentTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TaskContentTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TaskContentTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TaskContentTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
-- 进度值
function TaskContentTable:getProgressValue(id, level)
    for k, v in pairs(self.List0) do
        if v[self.task_id] == id and v[self.task_level] == level then
            return v[self.progress]
        end
    end
    return 1
end

return TaskContentTable
