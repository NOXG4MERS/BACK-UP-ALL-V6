local TaskExtraRewardTable = class({}, Assets.req("Scripts.ConfigTable.Base.TaskExtraRewardTableBase"))
-- 通过 Id 得到内容
function TaskExtraRewardTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TaskExtraRewardTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TaskExtraRewardTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TaskExtraRewardTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TaskExtraRewardTable:getExtraReward()
    local awardList = {}
    for k, v in pairs(self.List0) do
        local temp = {
            id = v[self.item_id],
            num = v[self.item_count]
        }
        table.insert(awardList, temp)
    end
    return awardList
end

return TaskExtraRewardTable
