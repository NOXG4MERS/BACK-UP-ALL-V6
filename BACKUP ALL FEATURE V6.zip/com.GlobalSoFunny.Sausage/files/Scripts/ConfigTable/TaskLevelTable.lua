local TaskLevelTable = class({}, Assets.req("Scripts.ConfigTable.Base.TaskLevelTableBase"))
-- 通过 Id 得到内容
function TaskLevelTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TaskLevelTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TaskLevelTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TaskLevelTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TaskLevelTable:getDayAward(level)
    local awardList = {}
    local ids = self:GetIdsByFieldIndex(self.level, level)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        local temp1 = {
            id = data[self.daily_item1_id],
            num = data[self.daily_item1_count]
        }

        local temp2 = {
            id = data[self.daily_item2_id],
            num = data[self.daily_item2_count]
        }

        table.insert(awardList, temp1)
        table.insert(awardList, temp2)
        break
    end
    return awardList
end

function TaskLevelTable:getVipAward(level)
    local awardList = {}
    local ids = self:GetIdsByFieldIndex(self.level, level)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        local temp1 = {
            id = data[self.vip_item1_id],
            num = data[self.vip_item1_count]
        }

        local temp2 = {
            id = data[self.vip_item2_id],
            num = data[self.vip_item2_count]
        }

        table.insert(awardList, temp1)
        table.insert(awardList, temp2)
        break
    end
    return awardList
end

function TaskLevelTable:getWeekAward(level)
    local awardList = {}
    local ids = self:GetIdsByFieldIndex(self.level, level)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        local temp1 = {
            id = data[self.weekly_item1_id],
            num = data[self.weekly_item1_count]
        }

        local temp2 = {
            id = data[self.weekly_item2_id],
            num = data[self.weekly_item2_count]
        }

        table.insert(awardList, temp1)
        table.insert(awardList, temp2)
        break
    end
    return awardList
end

return TaskLevelTable
