local TaskShowListTable = class({}, Assets.req("Scripts.ConfigTable.Base.TaskShowListTableBase"))
-- 通过 Id 得到内容
function TaskShowListTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TaskShowListTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TaskShowListTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TaskShowListTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TaskShowListTable:getItemIdList(taskId)
    local itemIdList = {}
    local ids = self:GetIdsByFieldIndex(self.task_id, taskId)

    for i = 1, #ids do
        itemIdList[#itemIdList + 1] = self:GetSingleValue(ids[i], self.item_id)
    end
    return itemIdList
end

return TaskShowListTable
