local TimeMachineInfoTable = class({}, Assets.req("Scripts.ConfigTable.Base.TimeMachineInfoTableBase"))
-- 通过 Id 得到内容
function TimeMachineInfoTable:GetValueById (id)
	if self.List0[id] then
		return self.List0[id]
	end
	return nil
end

-- 通过 Id，字段 得到内容
function TimeMachineInfoTable:GetSingleValue (id, fieldIndex)
	local value = self:GetValueById(id)
	if value and value[fieldIndex] then
		return value[fieldIndex]
	end
	return nil
end

-- 通过 字段 得到 Id
function TimeMachineInfoTable:GetIdByFieldIndex (fieldIndex, value)
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			return k
		end
	end
	return nil
end

-- 通过 字段 得到 Ids
function TimeMachineInfoTable:GetIdsByFieldIndex (fieldIndex, value)
	local idList = {}
	for k, v in pairs(self.List0) do
		if v[fieldIndex] == value then
			idList[#idList + 1] = k
		end
	end
	return idList
end
--------------------------------------------自动生成--------------------------------------------
function TimeMachineInfoTable:GetAllList()
    local list = {}
    for key, value in pairs(self.List0) do
        local sort = value[self.sort_id]
        local pictureSign = value[self.picture_sign]
        local content = value[self.content]
        local titleSign = value[self.title_sign]
        local photoSign = value[self.photo_sign]
        list[#list + 1] = {sort = sort, pictureSign = pictureSign, content = content, titleSign = titleSign, photoSign = photoSign}
    end
    table.sort(
        list,
        function(a, b)
            return a.sort < b.sort
        end
    )
    return list
end
return TimeMachineInfoTable
