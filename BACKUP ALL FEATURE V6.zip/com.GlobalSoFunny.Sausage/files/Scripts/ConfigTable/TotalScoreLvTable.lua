local TotalScoreLvTable = class({}, Assets.req("Scripts.ConfigTable.Base.TotalScoreLvTableBase"))
-- 通过 Id 得到内容
function TotalScoreLvTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TotalScoreLvTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TotalScoreLvTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TotalScoreLvTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TotalScoreLvTable:getLeveName(score)
    local levelName = ""
    if not score then
        score = 0
    end

    for k, v in pairs(self.List0) do
        if v[self.score] <= score then
            levelName = v[self.name]
        end
    end

    if levelName == "" then
        local maxScore = self:getMaxScore()
        levelName = self:getLeveName(maxScore)
    end
    return levelName
end

function TotalScoreLvTable:getLeve(score)
    local level = -1
    for k, v in pairs(self.List0) do
        if v[self.score] <= score then
            level = v[self.lv]
        end
    end
    return level
end

function TotalScoreLvTable:getMaxScore()
    local maxScore = 0
    for k, v in pairs(self.List0) do
        if v[self.score] >= maxScore then
            maxScore = v[self.score]
        end
    end
    return maxScore
end

function TotalScoreLvTable:getLevelMaxScore(score)
    local maxScore = 0
    for k, v in pairs(self.List0) do
        if v[self.score] > score then
            return v[self.score]
        end
    end

    return self:getMaxScore()
end

function TotalScoreLvTable:getLevelMinScore(score)
    local minScore = 0

    if score < 0 then
        return minScore
    end

    local list = {}

    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = k,
            score = v[self.score]
        }
    end
    table.sort(
        list,
        function(a, b)
            return a.score < b.score
        end
    )

    for i = 1, #list do
        if list[i].score > score then
            if i - 1 > 0 then
                return list[i - 1].score
            else
                return list[1].score
            end
        end
    end

    minScore = self:getMaxScore()
    return minScore
end

function TotalScoreLvTable:GetTotalScoreSpr(totalScore)
    local sprName = ""
    if not totalScore then
        totalScore = 0
    end
    if totalScore < 1500 then
        sprName = "Ranking_1"
    elseif totalScore < 2000 then
        sprName = "Ranking_2"
    elseif totalScore < 2500 then
        sprName = "Ranking_3"
    elseif totalScore < 3000 then
        sprName = "Ranking_4"
    elseif totalScore < 3500 then
        sprName = "Ranking_5"
    elseif totalScore < 4000 then
        sprName = "Ranking_6"
    else
        sprName = "Ranking_7"
    end

    return sprName
end

function TotalScoreLvTable:GetRankLevelByScore(score)
    if self.List4[score] then
        return self.List4[score][1]
    end
    return nil
end

function TotalScoreLvTable:GetRankScoreList()
    return self.List4
end

function TotalScoreLvTable:GetScoreNameByLevel(argLevel)
    local tempScoreName = ""
    for k, v in pairs(self.List0) do
        if v[self.lv] == argLevel then
            tempScoreName = v[self.name]
        end
    end
    return tempScoreName
end

return TotalScoreLvTable
