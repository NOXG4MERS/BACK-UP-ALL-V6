local TrafficPermitAwardTable = class({}, Assets.req("Scripts.ConfigTable.Base.TrafficPermitAwardTableBase"))
-- 通过 Id 得到内容
function TrafficPermitAwardTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TrafficPermitAwardTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TrafficPermitAwardTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TrafficPermitAwardTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TrafficPermitAwardTable:cacheTable(argFreeTrafficPermitId, argBasicTrafficPermitId)
    local idItem = nil
    local lvTable = nil
    local idTable = nil
    local numTable = nil
    local trafficPermitId = nil

    local tempLeveList = {}
    for i = 1, TrafficPermitConfig.BuyMaxLevel do
        tempLeveList[i] = {}
    end

    local maxLeveList = {}
    for i = TrafficPermitConfig.BuyMaxLevel + 1, TrafficPermitConfig.MaxLevel do
        maxLeveList[i] = {}
    end

    for i = 1, #self.Keys do
        local data = self:GetValueById(self.Keys[i])

        idItem = data[self.id]
        lvTable = data[self.lv]
        idTable = data[self.item_id]
        numTable = data[self.count]
        trafficPermitId = data[self.traffic_permit_id]

        if lvTable <= TrafficPermitConfig.BuyMaxLevel then
            local tempLevelItem = tempLeveList[lvTable]
            tempLevelItem.lv = lvTable
            if trafficPermitId == argBasicTrafficPermitId then
                local tempAwards = tempLevelItem["Vip"]
                if not tempAwards then
                    tempAwards = {}
                    tempLevelItem["Vip"] = tempAwards
                end
                tempAwards[#tempAwards + 1] = {
                    idItem = idItem,
                    id = idTable,
                    lv = lvTable,
                    numTable = numTable
                }
            elseif trafficPermitId == argFreeTrafficPermitId then
                local tempAwards = tempLevelItem["noVip"]
                if not tempAwards then
                    tempAwards = {}
                    tempLevelItem["noVip"] = tempAwards
                end

                tempAwards[#tempAwards + 1] = {
                    idItem = idItem,
                    id = idTable,
                    lv = lvTable,
                    numTable = numTable
                }
            end
        else
            local tempLevelItem = maxLeveList[lvTable]
            tempLevelItem.lv = lvTable
            if trafficPermitId == argBasicTrafficPermitId then
                local tempAwards = tempLevelItem["Vip"]
                if not tempAwards then
                    tempAwards = {}
                    tempLevelItem["Vip"] = tempAwards
                end
                tempAwards[#tempAwards + 1] = {
                    idItem = idItem,
                    id = idTable,
                    lv = lvTable,
                    numTable = numTable
                }
            elseif trafficPermitId == argFreeTrafficPermitId then
                local tempAwards = tempLevelItem["noVip"]
                if not tempAwards then
                    tempAwards = {}
                    tempLevelItem["noVip"] = tempAwards
                end

                tempAwards[#tempAwards + 1] = {
                    idItem = idItem,
                    id = idTable,
                    lv = lvTable,
                    numTable = numTable
                }
            end
        end
    end

    local List = {}
    for i, v in pairs(maxLeveList) do
        List[#List + 1] = v
    end
    return tempLeveList, List
end

function TrafficPermitAwardTable:GetAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        list[#list + 1] = {
            id = v[self.item_id],
            trafficPermitId = v[self.traffic_permit_id]
        }
    end
    return list
end

--得到当前赛季物品赛季物品
function TrafficPermitAwardTable:GetSeasonAllItem(argFreeTrafficPermitId, argBasicTrafficPermitId)
    local list = {}
    local trafficPermitId = nil
    for i = 1, #self.Keys do
        local data = self:GetValueById(self.Keys[i])
        trafficPermitId = data[self.traffic_permit_id]
        if trafficPermitId == argFreeTrafficPermitId or trafficPermitId == argBasicTrafficPermitId then
            list[#list + 1] = {
                ItemId = data[self.item_id],
                Lv = data[self.lv],
                Id = data[self.id],
                Num = data[self.count],
                PayType = trafficPermitId == argBasicTrafficPermitId and true or false
            }
        end
    end

    return list
end

function TrafficPermitAwardTable:GetRewards(argFreeTrafficPermitId, argBasicTrafficPermitId)
    local list = {}
    local ids = self.List2[argFreeTrafficPermitId]

    if ids then
        self:GetItems(list, ids, false)
    end
    ids = self.List2[argBasicTrafficPermitId]
    if ids then
        self:GetItems(list, ids, true)
    end
    return list
end

function TrafficPermitAwardTable:GetItems(list, items, isVIP)
    for i = 1, #items do
        local data = self:GetValueById(items[i])
        local level = data[self.lv]
        if not list[level] then
            list[level] = {}
        end
        table.insert(
            list[level],
            {
                id = data[self.id],
                itemId = data[self.item_id],
                count = data[self.count],
                level = data[self.lv],
                isVIP = isVIP,
                index = i
            }
        )
    end
end

local tempLeveList = {}
local tempHundredLeveList = {}
function TrafficPermitAwardTable:GetSeasonPrize(argFreeTrafficPermitId, argBasicTrafficPermitId)
    if #tempLeveList == 0 then
        self:GetSeasonRewards(argFreeTrafficPermitId, argBasicTrafficPermitId)
        table.sort(
            tempLeveList,
            function(a, b)
                if a.level == b.level then
                    if not a.isVIP and b.isVIP then
                        return true
                    else
                        if a.index < b.index then
                            return true
                        else
                            return false
                        end
                    end
                else
                    return a.level < b.level
                end
            end
        )
        table.sort(
            tempHundredLeveList,
            function(a, b)
                if a.level == b.level then
                    if not a.isVIP and b.isVIP then
                        return true
                    else
                        if a.index < b.index then
                            return true
                        else
                            return false
                        end
                    end
                else
                    return a.level < b.level
                end
            end
        )
    end
    local list = {}
    local tempList = {}
    table.copy(tempLeveList, list)
    table.copy(tempHundredLeveList, tempList)

    return list, tempList
end

function TrafficPermitAwardTable:GetSeasonRewards(argFreeTrafficPermitId, argBasicTrafficPermitId)
    local ids = self.List2[argFreeTrafficPermitId]
    if ids then
        self:GetSeasonItems(ids, false)
    end
    ids = self.List2[argBasicTrafficPermitId]
    if ids then
        self:GetSeasonItems(ids, true)
    end
end

function TrafficPermitAwardTable:GetSeasonItems(ids, isVIP)
    for i = 1, #ids do
        local data = self:GetValueById(ids[i])
        local level = data[self.lv]
        local list = {
            id = data[self.id],
            itemId = data[self.item_id],
            count = data[self.count],
            level = data[self.lv],
            isVIP = isVIP,
            index = i,
            cellType = isVIP and 2 or 1,
            showLevel = data[self.award_level]
        }

        if level <= TrafficPermitConfig.BuyMaxLevel then
            table.insert(tempLeveList, list)
        else
            table.insert(tempHundredLeveList, list)
        end
    end
end

function TrafficPermitAwardTable:GetTrafficPermitAward(argItemID)
    local id = self:GetIdByFieldIndex(self.item_id, argItemID)
    return id
end

return TrafficPermitAwardTable
