local TrafficPermitProcessRewardTable = class({}, Assets.req("Scripts.ConfigTable.Base.TrafficPermitProcessRewardTableBase"))
-- 通过 Id 得到内容
function TrafficPermitProcessRewardTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TrafficPermitProcessRewardTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TrafficPermitProcessRewardTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TrafficPermitProcessRewardTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TrafficPermitProcessRewardTable:getRewardInfo(argTaskType, argServerType)
    if self.List3[argTaskType] then
        for k, id in pairs(self.List3[argTaskType]) do
            local serverType = self:GetSingleValue(id, self.server_type)
            if serverType == argServerType then
                return self:GetSingleValue(id, self.item_id), self:GetSingleValue(id, self.item_count)
            end
        end
    end
end

return TrafficPermitProcessRewardTable
