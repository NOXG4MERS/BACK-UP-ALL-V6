local TrafficPermitSeasonChallengeTable = class({}, Assets.req("Scripts.ConfigTable.Base.TrafficPermitSeasonChallengeTableBase"))
-- 通过 Id 得到内容
function TrafficPermitSeasonChallengeTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TrafficPermitSeasonChallengeTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TrafficPermitSeasonChallengeTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TrafficPermitSeasonChallengeTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TrafficPermitSeasonChallengeTable:getSkipType(argSeasonID, argTaskID)
    for k, v in pairs(self.List0) do
        local tempSeasonID = v[self.season_id]
        local tempTaskID = v[self.task_id]
        if tempSeasonID == argSeasonID and tempTaskID == argTaskID then
            return v[self.client_jump_func]
        end
    end
    return 0
end

return TrafficPermitSeasonChallengeTable
