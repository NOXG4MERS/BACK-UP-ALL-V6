local TrafficPermitSeasonTable = class({}, Assets.req("Scripts.ConfigTable.Base.TrafficPermitSeasonTableBase"))
-- 通过 Id 得到内容
function TrafficPermitSeasonTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TrafficPermitSeasonTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TrafficPermitSeasonTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TrafficPermitSeasonTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TrafficPermitSeasonTable:GetSeasonDataById(id)
    local seasonData = nil
    local data = self:GetValueById(id)
    local timeRange = ConfigTable:GetTimeRange("TrafficPermitTimeTable", data[self.season])
    if timeRange then
        seasonData = {
            Index = id,
            SeasonID = data[self.season],
            SeasonName = data[self.name],
            StartTime = timeRange.startTime,
            EndTime = timeRange.endTime,
            isUseTrafficPermit = data[self.is_use_traffic_permit]
        }
    end

    return seasonData
end

function TrafficPermitSeasonTable:getIcon(argId)
    return self:GetSingleValue(argId, self.icon)
end

function TrafficPermitSeasonTable:getSeason(id)
    return self:GetSingleValue(id, self.season)
end

function TrafficPermitSeasonTable:GetShowDiscloseValue(argSeasonId)
    local seasonConfig = self:GetValueById(argSeasonId)
    if seasonConfig then
        return seasonConfig[self.show_disclose]
    end

    return -1
end

return TrafficPermitSeasonTable
