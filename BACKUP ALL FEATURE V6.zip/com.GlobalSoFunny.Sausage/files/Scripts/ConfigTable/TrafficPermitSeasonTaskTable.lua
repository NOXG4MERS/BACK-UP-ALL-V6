local TrafficPermitSeasonTaskTable = class({}, Assets.req("Scripts.ConfigTable.Base.TrafficPermitSeasonTaskTableBase"))
-- 通过 Id 得到内容
function TrafficPermitSeasonTaskTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TrafficPermitSeasonTaskTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TrafficPermitSeasonTaskTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TrafficPermitSeasonTaskTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TrafficPermitSeasonTaskTable:GetTaskDataBySeasonID(argSeasonID)
    local tempTaskList = {}

    for k, v in pairs(self.List0) do
        if v[self.season_id] == argSeasonID then
            local week = v[self.week]
            local taskID = v[self.task_id]

            if week > 0 and taskID > 0 then
                if not tempTaskList[week] then
                    tempTaskList[week] = {}
                end

                local tempTaskData = {
                    seasonIndexID = v[self.id],
                    week = week,
                    taskID = taskID
                }
                table.insert(tempTaskList[week], tempTaskData)
            end
        end
    end
    return tempTaskList
end

return TrafficPermitSeasonTaskTable
