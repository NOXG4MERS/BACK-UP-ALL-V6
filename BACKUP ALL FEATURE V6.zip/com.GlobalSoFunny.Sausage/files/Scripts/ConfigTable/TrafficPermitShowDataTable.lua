local TrafficPermitShowDataTable = class({}, Assets.req("Scripts.ConfigTable.Base.TrafficPermitShowDataTableBase"))
-- 通过 Id 得到内容
function TrafficPermitShowDataTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TrafficPermitShowDataTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TrafficPermitShowDataTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TrafficPermitShowDataTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TrafficPermitShowDataTable:getSeasonShowWarData(argSeasonTable, argNowTime)
    if not argSeasonTable then
        argSeasonTable = {}
    end
    if not argNowTime then
        argNowTime = 0
    end
    local list = {}

    for season, seasonTable in pairs(argSeasonTable) do
        if season ~= -1 then
            local seasonId = seasonTable.id
            for k, v in pairs(self.List0) do
                local tempSeasonId = v[self.traffic_permit_season_id]
                local tempSeasonInfo
                if tempSeasonId == seasonId then
                    tempSeasonInfo = seasonTable
                end
    
                if tempSeasonInfo then
                    if tempSeasonInfo.startTime <= argNowTime then
                        if not list[tempSeasonId] then
                            list[tempSeasonId] = {}
                        end
                        table.insert(list[tempSeasonId], v[self.show_data_item])
                    end
                end
            end
        end
    end

    for k, v in pairs(self.List0) do
        local tempSeasonId = v[self.traffic_permit_season_id]
        if 234881026 == tempSeasonId then
            if not list[tempSeasonId] then
                list[tempSeasonId] = {}
            end
            table.insert(list[tempSeasonId], v[self.show_data_item])
        else
            local tempSeasonId = v[self.traffic_permit_season_id]
            for season, seasonTable in pairs(argSeasonTable) do
                local seasonId = seasonTable.id
                if tempSeasonId == seasonId then
                    local tempSeasonInfo = seasonTable
                    if tempSeasonInfo and tempSeasonInfo.startTime <= argNowTime then
                        if not list[234881026] then
                            list[234881026] = {}
                        end
                        table.insert(list[234881026], v[self.show_data_item])
                    end
                end
            end
        end
    end

    return list
end

function TrafficPermitShowDataTable:getSeasonIdByDataId(argDataId)
    local list = {}
    local id = self:GetIdByFieldIndex(self.show_data_item, argDataId)

    if id then
        return self:GetSingleValue(id, self.traffic_permit_season_id)
    end
    return -1
end

return TrafficPermitShowDataTable
