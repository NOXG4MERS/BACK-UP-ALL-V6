local TrafficPermitTable = class({}, Assets.req("Scripts.ConfigTable.Base.TrafficPermitTableBase"))
-- 通过 Id 得到内容
function TrafficPermitTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function TrafficPermitTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function TrafficPermitTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function TrafficPermitTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
function TrafficPermitTable:getSeason(id)
    return self:GetSingleValue(id, self.season)
end

function TrafficPermitTable:itemID(id)
    return self:GetSingleValue(id, self.traffic_permit_item)
end

function TrafficPermitTable:getSeasonItemData(argID)
    local tempData = {}
    local ids = self:GetIdsByFieldIndex(self.traffic_permit_season_id, argID)

    for i = 1, #ids do
        tempData[#tempData + 1] = {
            ItemID = self:GetSingleValue(ids[i], self.traffic_permit_item),
            ItemType = self:GetSingleValue(ids[i], self.traffic_permit_type)
        }
    end
    return tempData
end

function TrafficPermitTable:GetAllItemForTimeDic()
    local list = {}
    for k, v in pairs(self.List0) do
        list[v[self.id]] = v[self.traffic_permit_season_id]
    end

    return list
end

function TrafficPermitTable:GetTrafficPermitItem(id, itemType)
    local items = self.List2[id]
    if items then
        for k, v in pairs(items) do
            local item = self:GetValueById(v)
            if item[self.traffic_permit_type] == itemType then
                return item[self.traffic_permit_item]
            end
        end
    end
    return nil
end

function TrafficPermitTable:GetTrafficpermitIds(argSeasonId)
    local freeTrafficPermitId = 0
    local basicTrafficPermitId = 0
    local seniorTrafficPermitId = 0
    for _, v in pairs(self.List0) do
        if argSeasonId == v[self.traffic_permit_season_id] then
            if v[self.traffic_permit_type] == ConfigTable.SysDictTable:getValueBySign(ConfigTable.SysDictTable.free, "traffic_permit_type") then
                freeTrafficPermitId = v[self.id]
            elseif v[self.traffic_permit_type] == ConfigTable.SysDictTable:getValueBySign(ConfigTable.SysDictTable.pay_basic, "traffic_permit_type") then
                basicTrafficPermitId = v[self.id]
            elseif v[self.traffic_permit_type] == ConfigTable.SysDictTable:getValueBySign(ConfigTable.SysDictTable.pay_luxury, "traffic_permit_type") then
                seniorTrafficPermitId = v[self.id]
            end
        end
    end

    return freeTrafficPermitId, basicTrafficPermitId, seniorTrafficPermitId
end

return TrafficPermitTable
