local WarGradeTable = class({}, Assets.req("Scripts.ConfigTable.Base.WarGradeTableBase"))
-- 通过 Id 得到内容
function WarGradeTable:GetValueById(id)
    if self.List0[id] then
        return self.List0[id]
    end
    return nil
end

-- 通过 Id，字段 得到内容
function WarGradeTable:GetSingleValue(id, fieldIndex)
    local value = self:GetValueById(id)
    if value and value[fieldIndex] then
        return value[fieldIndex]
    end
    return nil
end

-- 通过 字段 得到 Id
function WarGradeTable:GetIdByFieldIndex(fieldIndex, value)
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            return k
        end
    end
    return nil
end

-- 通过 字段 得到 Ids
function WarGradeTable:GetIdsByFieldIndex(fieldIndex, value)
    local idList = {}
    for k, v in pairs(self.List0) do
        if v[fieldIndex] == value then
            idList[#idList + 1] = k
        end
    end
    return idList
end
--------------------------------------------自动生成--------------------------------------------
local MAX = 0
local MaxSign = ""
function WarGradeTable:getMaxScore()
    local tempMax = 0
    for k, v in pairs(self.List0) do
        local max = v[self.max]
        if tempMax < max then
            tempMax = max
            MaxSign = v[self.sign]
        end
    end
    return tempMax
end

function WarGradeTable:getSignByScoce(argScore)
    if MAX == 0 then
        MAX = self:getMaxScore()
    end
    if argScore > MAX then
        return MaxSign
    end

    for k, v in pairs(self.List0) do
        local min = v[self.min]
        local max = v[self.max]
        if min <= argScore and argScore <= max then
            return v[self.sign]
        end
    end
    return "B"
end

return WarGradeTable
